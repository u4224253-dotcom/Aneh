package com.cfwan.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.Surface
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class IslandService : Service() {

    companion object {
        const val ACTION_TEST = "com.cfwan.app.TEST"
        const val ACTION_REFRESH = "com.cfwan.app.REFRESH"
        const val ACTION_TOGGLE_PIN = "com.cfwan.app.TOGGLE_PIN"
        const val ACTION_COLORS = "com.cfwan.app.COLORS"   // warna island diubah dari aplikasi

        const val PREFS = "cfwan_prefs"
        const val KEY_PIN = "pin"     // true = island tampil terus (tidak hilang), false = disembunyikan
        const val KEY_SIDE = "side"   // true = saat landscape island pindah ke sisi kamera
        const val KEY_GLOW = "glow"       // true = gradasi warna di bawah island (seperti kapsul Lyrics)
        const val KEY_HUE = "hue"         // 0..360
        const val KEY_SPREAD = "spread"   // 0..90
        const val KEY_SH_THICK = "sh_thick"   // ketebalan shadow 0..100
        const val KEY_SH_INT = "sh_int"       // intensitas shadow 0..100
        const val KEY_GLOW_INT = "glow_int"   // intensitas warna 0..100

        @Volatile
        var running = false

        private const val CHANNEL_ID = "cfwan_service"
        private const val NOTIF_ID = 1
        private const val SHOW_MS = 3500L
        /** Jarak dari tepi layar (dp). 0 = menempel di tepi seperti notch. */
        private const val EDGE_OFFSET_DP = 0
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private var island: IslandView? = null
    private val dismissRunnable = Runnable { hideIsland() }

    private fun isPinned() = prefs.getBoolean(KEY_PIN, true)

    // Rotasi layar (termasuk landscape kiri <-> kanan)
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) { relayout() }
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        startAsForeground()

        (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
            .registerDisplayListener(displayListener, handler)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TEST -> showIsland()
            ACTION_COLORS -> island?.reloadColors()
            ACTION_TOGGLE_PIN -> {
                prefs.edit().putBoolean(KEY_PIN, !isPinned()).apply()
                applyState()
            }
            ACTION_REFRESH -> {
                relayout()
                applyState()
            }
            else -> if (isPinned()) showIsland()   // service baru nyala / restart / boot
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(dismissRunnable)
        (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
            .unregisterDisplayListener(displayListener)
        removeIslandNow()
        super.onDestroy()
    }

    // ---- Island -----------------------------------------------------------------

    /** Aktif -> island tampil terus. Nonaktif -> island hilang. */
    private fun applyState() {
        if (isPinned()) showIsland() else hideIsland()
        updateNotification()
    }

    private fun showIsland() {
        if (!Settings.canDrawOverlays(this)) return
        handler.removeCallbacks(dismissRunnable)

        val side = currentSide()
        val view = island ?: IslandView(this).also {
            it.side = side
            island = it
            wm.addView(it, layoutParams(side))
        }
        view.show()

        // Mode tampil terus: tidak dijadwalkan menutup (hanya tes 3,5 detik yang menutup sendiri)
        if (!isPinned()) handler.postDelayed(dismissRunnable, SHOW_MS)
    }

    private fun hideIsland() {
        handler.removeCallbacks(dismissRunnable)
        val view = island ?: return
        view.hide { if (island === view) removeIslandNow() }
    }

    private fun removeIslandNow() {
        island?.let { runCatching { wm.removeView(it) } }
        island = null
    }

    /** Dipanggil saat layar berputar atau pengaturan mode samping berubah. */
    private fun relayout() {
        val view = island ?: return
        val side = currentSide()
        view.side = side
        runCatching { wm.updateViewLayout(view, layoutParams(side)) }
    }

    @Suppress("DEPRECATION")
    private fun currentSide(): Side {
        if (!prefs.getBoolean(KEY_SIDE, true)) return Side.TOP
        return when (wm.defaultDisplay.rotation) {
            Surface.ROTATION_90 -> Side.LEFT     // ujung atas HP ada di kiri layar
            Surface.ROTATION_270 -> Side.RIGHT   // ujung atas HP ada di kanan layar
            else -> Side.TOP
        }
    }

    private fun layoutParams(side: Side): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // Bisa disentuh (ketuk akor kiri/kanan); tidak mengambil fokus keyboard
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        val off = (EDGE_OFFSET_DP * resources.displayMetrics.density).toInt()
        when (side) {
            Side.TOP -> {
                lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                lp.x = 0
                lp.y = off
            }
            Side.LEFT -> {
                lp.gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
                lp.x = off
                lp.y = 0
            }
            Side.RIGHT -> {
                lp.gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                lp.x = off
                lp.y = 0
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // SHORT_EDGES: portrait -> atas/bawah, landscape -> kiri/kanan (tempat kamera berada)
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    // ---- Notifikasi foreground -----------------------------------------------------

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val toggle = PendingIntent.getForegroundService(
            this, 1, Intent(this, IslandService::class.java).setAction(ACTION_TOGGLE_PIN),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val pinned = isPinned()
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_chord)
            .setContentTitle("CfWan aktif")
            .setContentText(if (pinned) "Island tampil" else "Island disembunyikan")
            .setContentIntent(open)
            .addAction(0, if (pinned) "Sembunyikan island" else "Tampilkan island", toggle)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    private fun updateNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification())
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "CfWan", NotificationManager.IMPORTANCE_MIN)
        )
        val notif = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }
}
