package com.cfwan.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()
        val prefs = getSharedPreferences(IslandService.PREFS, Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#03040A"))
            setPadding(px(24), px(96), px(24), px(24))
        }

        root.addView(TextView(this).apply {
            text = "CfWan"
            setTextColor(Color.parseColor("#ECEFF7"))
            textSize = 26f
        })
        status = TextView(this).apply {
            setTextColor(Color.parseColor("#8C94A8"))
            textSize = 14f
            setPadding(0, px(8), 0, px(24))
        }
        root.addView(status)

        fun button(label: String, onClick: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                isAllCaps = false
                setOnClickListener { onClick() }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = px(8) })
        }

        fun toggle(label: String, key: String, default: Boolean, onChanged: (Boolean) -> Unit) {
            root.addView(Switch(this).apply {
                text = label
                setTextColor(Color.parseColor("#ECEFF7"))
                isChecked = prefs.getBoolean(key, default)
                setPadding(0, px(8), 0, px(8))
                setOnCheckedChangeListener { _, checked ->
                    prefs.edit().putBoolean(key, checked).apply()
                    onChanged(checked)
                }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }

        fun sendToService(action: String) {
            ContextCompat.startForegroundService(
                this, Intent(this, IslandService::class.java).setAction(action)
            )
        }

        button("1. Izinkan tampil di atas aplikasi lain") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("2. Aktifkan layanan") {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            ContextCompat.startForegroundService(this, Intent(this, IslandService::class.java))
            refresh()
        }

        toggle("Tampilkan island (tetap, tidak hilang)", IslandService.KEY_PIN, true) { checked ->
            // Menyalakan island otomatis menyalakan layanan; mematikannya hanya
            // memberi tahu layanan kalau memang sedang berjalan.
            if (checked || IslandService.running) sendToService(IslandService.ACTION_REFRESH)
        }
        toggle("Mode samping saat landscape", IslandService.KEY_SIDE, true) {
            if (IslandService.running) sendToService(IslandService.ACTION_REFRESH)
        }

        button("Tes island 3,5 detik") { sendToService(IslandService.ACTION_TEST) }
        button("Matikan layanan") {
            stopService(Intent(this, IslandService::class.java))
            refresh()
        }

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ok = Settings.canDrawOverlays(this)
        status.text = if (ok) "Izin overlay: aktif. Island menampilkan tiga akor gitar."
        else "Izin overlay belum diberikan."
    }
}
