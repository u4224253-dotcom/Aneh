package com.cfwan.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()
        val prefs = getSharedPreferences(IslandService.PREFS, Context.MODE_PRIVATE)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#03040A"))
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#03040A"))
            setPadding(px(24), px(72), px(24), px(32))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "CfWan"
            setTextColor(Color.parseColor("#ECEFF7"))
            textSize = 26f
        })
        status = TextView(this).apply {
            setTextColor(Color.parseColor("#8C94A8"))
            textSize = 14f
            setPadding(0, px(8), 0, px(24))
        }
        root.addView(status)

        fun button(label: String, onClick: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                isAllCaps = false
                setOnClickListener { onClick() }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = px(8) })
        }

        fun toggle(label: String, key: String, default: Boolean, onChanged: (Boolean) -> Unit) {
            root.addView(Switch(this).apply {
                text = label
                setTextColor(Color.parseColor("#ECEFF7"))
                isChecked = prefs.getBoolean(key, default)
                setPadding(0, px(8), 0, px(8))
                setOnCheckedChangeListener { _, checked ->
                    prefs.edit().putBoolean(key, checked).apply()
                    onChanged(checked)
                }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }

        fun sendToService(action: String) {
            ContextCompat.startForegroundService(
                this, Intent(this, IslandService::class.java).setAction(action)
            )
        }

        button("1. Izinkan tampil di atas aplikasi lain") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("2. Aktifkan layanan") {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            ContextCompat.startForegroundService(this, Intent(this, IslandService::class.java))
            refresh()
        }

        toggle("Tampilkan island (tetap, tidak hilang)", IslandService.KEY_PIN, true) { checked ->
            // Menyalakan island otomatis menyalakan layanan; mematikannya hanya
            // memberi tahu layanan kalau memang sedang berjalan.
            if (checked || IslandService.running) sendToService(IslandService.ACTION_REFRESH)
        }
        toggle("Mode samping saat landscape", IslandService.KEY_SIDE, true) {
            if (IslandService.running) sendToService(IslandService.ACTION_REFRESH)
        }

        // ---- Warna island (gradasi bawah seperti kapsul Lyrics) ----
        val preview = IslandPreview(this)
        fun syncPreview() {
            preview.glowOn = prefs.getBoolean(IslandService.KEY_GLOW, true)
            preview.hue = prefs.getInt(IslandService.KEY_HUE, IslandGlow.DEF_HUE)
            preview.spread = prefs.getInt(IslandService.KEY_SPREAD, IslandGlow.DEF_SPREAD)
            preview.invalidate()
        }
        fun pushColors() {
            syncPreview()
            if (IslandService.running) sendToService(IslandService.ACTION_COLORS)
        }

        root.addView(TextView(this).apply {
            text = "Warna island"
            setTextColor(Color.parseColor("#ECEFF7"))
            textSize = 18f
            setPadding(0, px(20), 0, px(8))
        })
        root.addView(preview, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        toggle("Gradasi warna di island", IslandService.KEY_GLOW, true) { pushColors() }

        val sliders = ArrayList<SeekBar>()
        fun slider(label: String, key: String, def: Int, maxValue: Int, rainbow: Boolean) {
            root.addView(TextView(this).apply {
                text = label
                setTextColor(Color.parseColor("#8C94A8"))
                textSize = 14f
                setPadding(0, px(12), 0, px(2))
            })
            val bar = SeekBar(this).apply {
                max = maxValue
                progress = prefs.getInt(key, def).coerceIn(0, maxValue)
                if (rainbow) {
                    val hues = IntArray(7) { IslandGlow.hsl(it * 60f, 0.70f, 0.50f) }
                    val track = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, hues).apply {
                        cornerRadius = px(6).toFloat()
                    }
                    background = InsetDrawable(track, 0, px(14), 0, px(14))
                    progressTintList = ColorStateList.valueOf(Color.TRANSPARENT)
                    progressBackgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
                }
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, value: Int, fromUser: Boolean) {
                        if (!fromUser) return
                        prefs.edit().putInt(key, value).apply()
                        pushColors()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {}
                })
            }
            sliders.add(bar)
            root.addView(bar, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }
        slider("Warna kapsul", IslandService.KEY_HUE, IslandGlow.DEF_HUE, 360, true)
        slider("Sebaran gradasi", IslandService.KEY_SPREAD, IslandGlow.DEF_SPREAD, IslandGlow.MAX_SPREAD, false)

        button("Reset warna") {
            prefs.edit()
                .putInt(IslandService.KEY_HUE, IslandGlow.DEF_HUE)
                .putInt(IslandService.KEY_SPREAD, IslandGlow.DEF_SPREAD)
                .putBoolean(IslandService.KEY_GLOW, true)
                .apply()
            sliders[0].progress = IslandGlow.DEF_HUE
            sliders[1].progress = IslandGlow.DEF_SPREAD
            pushColors()
        }
        syncPreview()

        button("Tes island 3,5 detik") { sendToService(IslandService.ACTION_TEST) }
        button("Matikan layanan") {
            stopService(Intent(this, IslandService::class.java))
            refresh()
        }

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ok = Settings.canDrawOverlays(this)
        status.text = if (ok) "Izin overlay: aktif. Ketuk sisi kiri/kanan island (atau geser) untuk akor sebelumnya/selanjutnya."
        else "Izin overlay belum diberikan."
    }
}

/** Pratinjau island (bentuk dan shadow sama dengan island asli) untuk mengatur warna di aplikasi. */
private class IslandPreview(context: Context) : View(context) {
    var hue = IslandGlow.DEF_HUE
    var spread = IslandGlow.DEF_SPREAD
    var glowOn = true

    private val d = resources.displayMetrics.density
    private val bg = Paint().apply { color = Color.parseColor("#1C202C") }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val path = Path()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), (92 * d).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        val w = 310f * d
        val h = 60f * d
        val r = 19f * d
        val left = (width - w) / 2f
        path.reset()
        path.addRoundRect(
            RectF(left, 0f, left + w, h),
            floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r),
            Path.Direction.CW
        )
        IslandGlow.drawShadow(canvas, path, 0f, 3f * d, d, 1f)
        canvas.drawPath(path, body)
        if (glowOn) {
            canvas.save()
            canvas.clipPath(path)
            IslandGlow.draw(canvas, left, 0f, w, h, IslandGlow.colors(hue, spread), 1f)
            canvas.restore()
        }
    }
}
