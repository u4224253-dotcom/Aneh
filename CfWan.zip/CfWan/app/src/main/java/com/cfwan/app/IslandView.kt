package com.cfwan.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Sisi layar tempat island menempel. TOP = portrait, LEFT/RIGHT = landscape (sisi kamera). */
enum class Side { TOP, LEFT, RIGHT }

/**
 * Mode isi island, sekaligus alur pemakaian: upload lagu -> (analisis) -> preview pemutar -> hasil akor.
 * Dipindah lewat panah kiri/kanan (bukan mesin beneran, baru mock-up tampilan + animasinya).
 */
enum class IslandMode { UPLOAD, PLAYER, CHORD }

/**
 * Island CfWan, 3 mode yang dipindah lewat panah kiri/kanan (akor <-> pemutar <-> upload), semuanya
 * dalam satu alur: 1) Upload file audio lalu dianalisis (animasi air naik + cahaya muter di tepi
 * island, bukan akor masih demo/dummy, belum terhubung mesin deteksi beneran), 2) Preview pemutar
 * (judul lagu, play/pause, progres) memakai elemen dari mode Lirik di HTML Nusa, 3) Hasil akor
 * (carousel yang sudah ada) baru terisi setelah analisis "selesai".
 * Ketuk/geser badan island = maju-mundur isi di dalam mode aktif (akor berikutnya, seek pemutar,
 * atau mulai/ulang upload). Transisi antar mode pakai slide + fade biasa (bukan blur) supaya ringan.
 * TOP: melebar horizontal di tepi atas. LEFT/RIGHT: berdiri di sisi layar saat landscape.
 */
class IslandView(context: Context) : View(context) {

    var side: Side = Side.TOP
        set(value) {
            if (field != value) {
                field = value
                requestLayout()
                invalidate()
            }
        }

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
    private fun withAlpha(color: Int, a: Float): Int =
        Color.argb((255f * a).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
    private fun lighten(color: Int, amt: Float = 0.35f): Int = Color.rgb(
        (Color.red(color) + (255 - Color.red(color)) * amt).toInt().coerceIn(0, 255),
        (Color.green(color) + (255 - Color.green(color)) * amt).toInt().coerceIn(0, 255),
        (Color.blue(color) + (255 - Color.blue(color)) * amt).toInt().coerceIn(0, 255)
    )

    // ---- Ukuran mode TOP (dp) ----
    private val fullW = 310f
    private val fullH = 60f
    private val fullR = 19f
    private val fullE = 13f
    private val startW = 120f
    private val startH = 28f
    private val startR = 12f
    private val startE = 8f

    // ---- Ukuran mode samping (dp): D = kedalaman dari tepi layar, L = panjang sepanjang tepi ----
    private val sFullD = 88f
    private val sFullL = 150f
    private val sFullR = 22f
    private val sFullE = 14f
    private val sStartD = 28f
    private val sStartL = 100f
    private val sStartR = 12f
    private val sStartE = 8f

    // ---- Ukuran badan per mode: upload ringkas, pemutar agak lebar, akor seperti semula ----
    private fun modeFullW(m: IslandMode) = when (m) {
        IslandMode.UPLOAD -> 230f
        IslandMode.PLAYER -> 330f
        IslandMode.CHORD -> fullW
    }
    private fun modeFullH(m: IslandMode) = when (m) {
        IslandMode.UPLOAD -> 86f
        IslandMode.PLAYER -> 116f
        IslandMode.CHORD -> fullH
    }
    private fun modeFullL(m: IslandMode) = when (m) {
        IslandMode.UPLOAD -> 130f
        IslandMode.PLAYER -> 190f
        IslandMode.CHORD -> sFullL
    }

    // ---- Carousel akor (hasil "analisis", demo) ----
    private val chords = listOf("C", "G", "Am", "F", "Dm", "E7", "A", "Em", "D", "Bm")
    private val shapes = chords.map { GuitarChords.pick(it) }
    private val glyph = ChordGlyphPainter(d)
    private var idx = 0          // akor yang sedang di tengah
    private var slide = 0f       // -1..1: progres bergeser (positif = ke akor berikutnya, negatif = ke sebelumnya)

    // ---- Mode Upload & Analyzer (demo, belum mesin beneran) ----
    private enum class UploadState { IDLE, ANALYZING, DONE }
    private val demoFileName = "Paper Sky.mp3"
    private val demoArtist = "Lumen Coast - Summer Flows"
    private var uploadState = UploadState.IDLE
    private var uploadProgress = 0f      // 0..1
    private var uploadFileName = ""
    private var uploadAnim: ValueAnimator? = null
    private var waveTime = 0f            // fase animasi gelombang & cahaya muter, jalan terus selama analisis
    private var waveRunning = false
    private val waveRunnable = object : Runnable {
        override fun run() {
            waveTime += 0.16f
            invalidate()
            if (waveRunning) postDelayed(this, 32L)
        }
    }

    // ---- Mode Pemutar (preview, demo) ----
    private var playerTitle = "Belum ada file"
    private var playerArtist = "Upload dulu di island pertama"
    private var isPlaying = false
    private var playerProgress = 0f      // 0..1
    private var playerAnim: ValueAnimator? = null
    private val playerDurationMs = 20000L

    // ---- Mode isi island & transisi pindah mode ----
    private var modeIdx = 0           // mode yang sedang/baru saja dituju
    private var modeAnimFrom = 0      // mode asal transisi (dipakai untuk fade-out + geser keluar)
    private var modeAnimDir = 1
    private var modeAnimT = 1f        // 0..1: 0 = baru mulai pindah mode, 1 = sudah settle di modeIdx
    private var modeAnim: ValueAnimator? = null

    private val autoMs = 2400L     // jeda geser otomatis (carousel akor)
    private val resumeMs = 6000L   // jeda geser otomatis setelah disentuh manual
    private var autoOn = false
    private var stepAnim: ValueAnimator? = null
    private val autoRunnable = object : Runnable {
        override fun run() {
            if (IslandMode.values()[modeIdx] == IslandMode.CHORD) step(1)
            postDelayed(this, autoMs)
        }
    }

    // ---- Sentuhan ----
    private val bodyBounds = RectF()
    private val leftArrowBounds = RectF()
    private val rightArrowBounds = RectF()
    private val playPauseBounds = RectF()
    private var downX = 0f
    private var downY = 0f
    private var downInside = false
    private var downArrowDirection = 0

    // ---- Warna gradasi (diatur dari aplikasi) ----
    private val prefs = context.getSharedPreferences(IslandService.PREFS, Context.MODE_PRIVATE)
    private var glowOn = true
    private var glowColors = IslandGlow.colors(IslandGlow.DEF_HUE, IslandGlow.DEF_SPREAD)
    private var glowIntensity = 1f
    private var shRadiusDp = IslandGlow.shadowRadiusDp(IslandGlow.DEF_SH_THICK)
    private var shIntensity = IslandGlow.DEF_SH_INT

    init { reloadColors() }

    /** Baca ulang pengaturan warna dari preferensi (dipanggil saat user mengubah warna di aplikasi). */
    fun reloadColors() {
        glowOn = prefs.getBoolean(IslandService.KEY_GLOW, true)
        glowColors = IslandGlow.colors(
            prefs.getInt(IslandService.KEY_HUE, IslandGlow.DEF_HUE).coerceIn(0, 360),
            prefs.getInt(IslandService.KEY_SPREAD, IslandGlow.DEF_SPREAD).coerceIn(0, IslandGlow.MAX_SPREAD)
        )
        glowIntensity = prefs.getInt(IslandService.KEY_GLOW_INT, IslandGlow.DEF_GLOW_INT).coerceIn(0, 100) / 100f
        shRadiusDp = IslandGlow.shadowRadiusDp(prefs.getInt(IslandService.KEY_SH_THICK, IslandGlow.DEF_SH_THICK))
        shIntensity = prefs.getInt(IslandService.KEY_SH_INT, IslandGlow.DEF_SH_INT).coerceIn(0, 100)
        invalidate()
    }

    private var p = 0f           // progres buka-tutup (boleh >1 karena overshoot)
    private var expandAnim: ValueAnimator? = null

    private val path = Path()
    private val wavePath = Path()
    private val playTrianglePath = Path()
    private val edgeMatrix = Matrix()
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val arrowBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val arrowLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = dp(2.4f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val artPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (side == Side.TOP) {
            val maxW = IslandMode.values().maxOf { modeFullW(it) }
            val maxH = IslandMode.values().maxOf { modeFullH(it) }
            setMeasuredDimension(
                dp(maxW + 2 * fullE + 32f).toInt(),
                dp(maxH + 22f).toInt()
            )
        } else {
            val maxL = IslandMode.values().maxOf { modeFullL(it) }
            setMeasuredDimension(
                dp(sFullD + 24f).toInt(),
                dp(maxL + 2 * sFullE + 32f).toInt()
            )
        }
    }

    // ---- Animasi buka/tutup & carousel akor -----------------------------------------

    fun show() {
        expandAnim?.cancel()
        expandAnim = ValueAnimator.ofFloat(p, 1f).apply {
            duration = 620
            interpolator = OvershootInterpolator(1.1f)
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
            start()
        }
        startCarousel()
    }

    fun hide(onEnd: () -> Unit) {
        expandAnim?.cancel()
        expandAnim = ValueAnimator.ofFloat(p, 0f).apply {
            duration = 380
            interpolator = AccelerateInterpolator(1.4f)
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) { cancelled = true }
                override fun onAnimationEnd(animation: Animator) { if (!cancelled) onEnd() }
            })
            start()
        }
    }

    private fun startCarousel() {
        if (autoOn) return
        autoOn = true
        postDelayed(autoRunnable, autoMs)
    }

    /** Geser carousel akor satu langkah: [dir] = 1 maju (akor selanjutnya), -1 mundur (akor sebelumnya). */
    fun step(dir: Int) {
        stepAnim?.end()   // selesaikan geseran sebelumnya dulu supaya ketukan beruntun tidak hilang
        stepAnim = ValueAnimator.ofFloat(0f, dir.toFloat()).apply {
            duration = 320
            interpolator = DecelerateInterpolator(2f)
            addUpdateListener { slide = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    idx = ((idx + dir) % chords.size + chords.size) % chords.size
                    slide = 0f
                    invalidate()
                }
            })
            start()
        }
    }

    /** Geser manual akor dari sentuhan; geser otomatis ditunda dulu. */
    private fun manualStep(dir: Int) {
        step(dir)
        if (autoOn) {
            removeCallbacks(autoRunnable)
            postDelayed(autoRunnable, resumeMs)
        }
    }

    // ---- Upload & Analyzer -----------------------------------------------------------

    /** Ketuk badan island mode Upload: mulai "pilih file" (demo) kalau masih kosong, atau ulang kalau sudah selesai. */
    private fun handleUploadTap() {
        when (uploadState) {
            UploadState.IDLE -> startAnalyzing()
            UploadState.DONE -> resetUpload()
            UploadState.ANALYZING -> {}
        }
    }

    private fun resetUpload() {
        uploadAnim?.cancel()
        waveRunning = false
        removeCallbacks(waveRunnable)
        uploadState = UploadState.IDLE
        uploadProgress = 0f
        uploadFileName = ""
        playerTitle = "Belum ada file"
        playerArtist = "Upload dulu di island pertama"
        isPlaying = false
        playerProgress = 0f
        playerAnim?.cancel()
        invalidate()
    }

    /** Mock "menganalisis" audio jadi akor: progres 0->100% + animasi gelombang & cahaya muter (bukan blur). */
    private fun startAnalyzing() {
        uploadState = UploadState.ANALYZING
        uploadProgress = 0f
        uploadFileName = demoFileName
        uploadAnim?.cancel()
        uploadAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 3400
            interpolator = LinearInterpolator()
            addUpdateListener { uploadProgress = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    uploadState = UploadState.DONE
                    waveRunning = false
                    removeCallbacks(waveRunnable)
                    // "Hasil" siap: isi mode Pemutar & buka mode Akor
                    playerTitle = "Paper Sky"
                    playerArtist = demoArtist
                    playerProgress = 0f
                    isPlaying = true
                    updatePlayerAnimState()
                    invalidate()
                }
            })
            start()
        }
        waveRunning = true
        postDelayed(waveRunnable, 32L)
    }

    // ---- Pemutar (preview) -------------------------------------------------------------

    private fun updatePlayerAnimState() {
        playerAnim?.cancel()
        if (!isPlaying) return
        val remaining = ((1f - playerProgress) * playerDurationMs).toLong().coerceAtLeast(200L)
        playerAnim = ValueAnimator.ofFloat(playerProgress, 1f).apply {
            duration = remaining
            interpolator = LinearInterpolator()
            addUpdateListener { playerProgress = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    if (playerProgress >= 0.999f) {
                        playerProgress = 0f
                        if (isPlaying) updatePlayerAnimState()
                    }
                }
            })
            start()
        }
    }

    private fun togglePlayPause() {
        if (playerTitle == "Belum ada file") return   // belum ada lagu buat diputar
        isPlaying = !isPlaying
        updatePlayerAnimState()
        invalidate()
    }

    /** Geser manual posisi pemutar (demo): [dir] = 1 maju ~10%, -1 mundur ~10%. */
    private fun manualSeek(dir: Int) {
        if (playerTitle == "Belum ada file") return
        playerProgress = (playerProgress + dir * 0.1f).coerceIn(0f, 1f)
        if (isPlaying) updatePlayerAnimState()
        invalidate()
    }

    /**
     * Pindah mode (upload <-> pemutar <-> akor) satu langkah: [dir] = 1 mode berikutnya, -1 sebelumnya.
     * Isi mode lama memudar sambil bergeser keluar, isi mode baru masuk dari sisi berlawanan sambil
     * memudar masuk; badan island ikut melebar/menyempit mengikuti ukuran mode baru. Semua lewat
     * alpha + translate saja (tanpa blur) supaya ringan digambar terus-menerus di overlay.
     */
    private fun switchMode(dir: Int) {
        val n = IslandMode.values().size
        val newIdx = ((modeIdx + dir) % n + n) % n
        if (newIdx == modeIdx) return
        modeAnim?.cancel()
        modeAnimFrom = modeIdx
        modeAnimDir = dir
        modeIdx = newIdx
        modeAnimT = 0f
        modeAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 460
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { modeAnimT = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    /** Pindah mode manual dari ketukan panah; geser otomatis carousel akor ditunda dulu. */
    private fun manualSwitchMode(dir: Int) {
        switchMode(dir)
        if (autoOn) {
            removeCallbacks(autoRunnable)
            postDelayed(autoRunnable, resumeMs)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downArrowDirection = when {
                    p > 0.5f && side == Side.TOP && leftArrowBounds.contains(e.x, e.y) -> -1
                    p > 0.5f && side == Side.TOP && rightArrowBounds.contains(e.x, e.y) -> 1
                    else -> 0
                }
                downInside = downArrowDirection != 0 ||
                    (p > 0.5f && bodyBounds.contains(e.x, e.y))
                downX = e.x
                downY = e.y
                return downInside
            }
            MotionEvent.ACTION_UP -> {
                if (!downInside) return false
                downInside = false
                val arrowDirection = downArrowDirection
                downArrowDirection = 0
                if (arrowDirection != 0) {
                    // Panah kiri/kanan = pindah MODE (upload -> pemutar -> akor), bukan menggeser isi carousel.
                    val arrowBounds = if (arrowDirection < 0) leftArrowBounds else rightArrowBounds
                    if (arrowBounds.contains(e.x, e.y)) manualSwitchMode(arrowDirection)
                    return true
                }
                val mode = IslandMode.values()[modeIdx]
                if (mode == IslandMode.PLAYER && playPauseBounds.contains(e.x, e.y)) {
                    togglePlayPause()
                    return true
                }
                if (mode == IslandMode.UPLOAD) {
                    handleUploadTap()
                    return true
                }
                val horizontal = side == Side.TOP
                val moved = if (horizontal) e.x - downX else e.y - downY
                val dir = if (abs(moved) > dp(24f)) {
                    if (moved < 0) 1 else -1                       // geser ke kiri/atas = maju
                } else {
                    val frac = if (horizontal) (e.x - bodyBounds.left) / bodyBounds.width()
                               else (e.y - bodyBounds.top) / bodyBounds.height()
                    if (frac < 0.5f) -1 else 1                      // ketuk kiri/atas = mundur, kanan/bawah = maju
                }
                // Ketuk/geser badan island = maju-mundur isi di DALAM mode yang sedang aktif.
                when (mode) {
                    IslandMode.CHORD -> manualStep(dir)
                    IslandMode.PLAYER -> manualSeek(dir)
                    IslandMode.UPLOAD -> {}
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                val was = downInside
                downInside = false
                downArrowDirection = 0
                return was
            }
        }
        return downInside
    }

    override fun onDetachedFromWindow() {
        expandAnim?.cancel()
        removeCallbacks(autoRunnable)
        autoOn = false
        stepAnim?.cancel()
        modeAnim?.cancel()
        uploadAnim?.cancel()
        playerAnim?.cancel()
        waveRunning = false
        removeCallbacks(waveRunnable)
        super.onDetachedFromWindow()
    }

    // ---- Bentuk ---------------------------------------------------------------------

    /**
     * Badan hitam: sisi atas rata, dua sudut bawah membulat, "telinga" cekung di kiri-kanan.
     * Koordinat lokal: x sepanjang tepi, y = kedalaman dari tepi. Lebar total = totalW.
     */
    private fun buildShape(totalW: Float, h: Float, r: Float, e: Float) {
        val w = totalW
        path.reset()
        path.moveTo(0f, 0f)
        path.lineTo(w, 0f)
        path.arcTo(RectF(w - e, 0f, w + e, 2 * e), 270f, -90f)              // telinga kanan
        path.lineTo(w - e, h - r)
        path.arcTo(RectF(w - e - 2 * r, h - 2 * r, w - e, h), 0f, 90f)      // sudut kanan bawah
        path.lineTo(e + r, h)
        path.arcTo(RectF(e, h - 2 * r, e + 2 * r, h), 90f, 90f)             // sudut kiri bawah
        path.lineTo(e, e)
        path.arcTo(RectF(-e, 0f, e, 2 * e), 0f, -90f)                       // telinga kiri
        path.close()
    }

    // ---- Gambar ---------------------------------------------------------------------

    override fun onDraw(canvas: Canvas) {
        if (side == Side.TOP) drawTop(canvas) else drawSide(canvas)
    }

    private fun drawTop(canvas: Canvas) {
        val vw = width.toFloat()

        val curMode = IslandMode.values()[modeIdx]
        val fromMode = IslandMode.values()[modeAnimFrom]
        val fullWNow = lerp(modeFullW(fromMode), modeFullW(curMode), modeAnimT)
        val fullHNow = lerp(modeFullH(fromMode), modeFullH(curMode), modeAnimT)

        val wDp = lerp(startW, fullWNow, p).coerceIn(0f, fullWNow + 10f)
        val hDp = lerp(startH, fullHNow, p).coerceAtLeast(0f)
        val ePx = dp(lerp(startE, fullE, p).coerceAtLeast(0f))
        val bodyW = dp(wDp)
        val bodyH = dp(hDp)
        val rPx = dp(lerp(startR, fullR, p).coerceAtLeast(0f)).coerceAtMost(minOf(bodyH, bodyW) / 2f)

        val totalW = bodyW + 2 * ePx
        buildShape(totalW, bodyH, rPx, ePx)
        path.offset((vw - totalW) / 2f, 0f)
        path.computeBounds(bodyBounds, true)
        IslandGlow.drawShadow(canvas, path, 0f, dp(shRadiusDp * 0.4f), d, p, shRadiusDp, shIntensity)
        canvas.drawPath(path, bodyPaint)

        val a = ((p - 0.5f) / 0.4f).coerceIn(0f, 1f)
        if (a <= 0f) { playPauseBounds.setEmpty(); return }

        canvas.save()
        canvas.clipPath(path)
        if (glowOn) {
            IslandGlow.draw(canvas, bodyBounds.left, bodyBounds.top, bodyBounds.width(), bodyBounds.height(), glowColors, a * glowIntensity)
        }
        val arrowY = bodyBounds.centerY()
        val arrowOffset = dp(fullE + 22f)
        val arrowHitRadius = dp(14f)
        val leftArrowX = bodyBounds.left + arrowOffset
        val rightArrowX = bodyBounds.right - arrowOffset
        leftArrowBounds.set(
            leftArrowX - arrowHitRadius, arrowY - arrowHitRadius,
            leftArrowX + arrowHitRadius, arrowY + arrowHitRadius
        )
        rightArrowBounds.set(
            rightArrowX - arrowHitRadius, arrowY - arrowHitRadius,
            rightArrowX + arrowHitRadius, arrowY + arrowHitRadius
        )

        val contentCy = dp(fullHNow) / 2f
        layoutTouchTargets(curMode, vw / 2f, contentCy)

        val dirF = modeAnimDir.toFloat()
        val slideDist = dp(60f)
        val offFrom = -dirF * slideDist * modeAnimT
        val offTo = dirF * slideDist * (1f - modeAnimT)
        drawModeContent(canvas, fromMode, vw / 2f, contentCy, true, offFrom, 76f, 140f, a * (1f - modeAnimT))
        drawModeContent(canvas, curMode, vw / 2f, contentCy, true, offTo, 76f, 140f, a * modeAnimT)
        drawArrow(canvas, leftArrowX, arrowY, true, a)
        drawArrow(canvas, rightArrowX, arrowY, false, a)
        canvas.restore()
    }

    private fun drawSide(canvas: Canvas) {
        leftArrowBounds.setEmpty()
        rightArrowBounds.setEmpty()
        playPauseBounds.setEmpty()
        val vw = width.toFloat()
        val vh = height.toFloat()
        val left = side == Side.LEFT

        val curMode = IslandMode.values()[modeIdx]
        val fromMode = IslandMode.values()[modeAnimFrom]
        val fullLNow = lerp(modeFullL(fromMode), modeFullL(curMode), modeAnimT)

        val depthDp = lerp(sStartD, sFullD, p).coerceIn(0f, sFullD + 8f)
        val lenDp = lerp(sStartL, fullLNow, p).coerceIn(0f, fullLNow + 10f)
        val ePx = dp(lerp(sStartE, sFullE, p).coerceAtLeast(0f))
        val depth = dp(depthDp)
        val len = dp(lenDp)
        val rPx = dp(lerp(sStartR, sFullR, p).coerceAtLeast(0f)).coerceAtMost(minOf(depth, len) / 2f)

        val totalLen = len + 2 * ePx
        val startAlong = (vh - totalLen) / 2f

        buildShape(totalLen, depth, rPx, ePx)
        // Lokal (x sepanjang tepi, y kedalaman) -> layar. Bentuk simetris, jadi transpose = rotasi.
        if (left) {
            edgeMatrix.setValues(floatArrayOf(0f, 1f, 0f, 1f, 0f, startAlong, 0f, 0f, 1f))
        } else {
            edgeMatrix.setValues(floatArrayOf(0f, -1f, vw, 1f, 0f, startAlong, 0f, 0f, 1f))
        }
        path.transform(edgeMatrix)
        path.computeBounds(bodyBounds, true)
        IslandGlow.drawShadow(canvas, path, dp(shRadiusDp * 0.4f) * (if (left) 1f else -1f), 0f, d, p, shRadiusDp, shIntensity)
        canvas.drawPath(path, bodyPaint)

        val a = ((p - 0.5f) / 0.4f).coerceIn(0f, 1f)
        if (a <= 0f) return

        canvas.save()
        canvas.clipPath(path)
        if (glowOn) {
            // Gradasi digambar di koordinat lokal (x sepanjang tepi, y = kedalaman) supaya "bawah" = sisi jauh dari tepi layar
            canvas.save()
            canvas.concat(edgeMatrix)
            IslandGlow.draw(canvas, 0f, 0f, totalLen, depth, glowColors, a * glowIntensity)
            canvas.restore()
        }
        val boxW = dp(sFullD)
        // geser 6dp menjauhi tepi layar (kamera ada di tepi ini)
        val shift = dp(6f) * (if (left) 1f else -1f)
        val cx = (if (left) 0f else vw - boxW) + boxW / 2f + shift
        val dirF = modeAnimDir.toFloat()
        val slideDist = dp(40f)
        val offFrom = -dirF * slideDist * modeAnimT
        val offTo = dirF * slideDist * (1f - modeAnimT)
        drawModeContent(canvas, fromMode, cx, vh / 2f, false, offFrom, 52f, 80f, a * (1f - modeAnimT))
        drawModeContent(canvas, curMode, cx, vh / 2f, false, offTo, 52f, 80f, a * modeAnimT)
        canvas.restore()
    }

    /** Panah bulat kecil mengikuti ikon Focus Timer pada HTML. */
    private fun drawArrow(canvas: Canvas, cx: Float, cy: Float, left: Boolean, alpha: Float) {
        if (alpha <= 0f) return

        arrowBgPaint.alpha = (72f * alpha).toInt().coerceIn(0, 255)
        arrowLinePaint.alpha = (255f * alpha).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, dp(11f), arrowBgPaint)

        val scale = dp(0.9f)
        val outerX = if (left) 6.5f else 3.5f
        val innerX = if (left) 3f else 7f
        val topY = 1.5f
        val midY = 5f
        val bottomY = 8.5f
        canvas.drawLine(
            cx + (outerX - 5f) * scale, cy + (topY - 5f) * scale,
            cx + (innerX - 5f) * scale, cy + (midY - 5f) * scale,
            arrowLinePaint
        )
        canvas.drawLine(
            cx + (innerX - 5f) * scale, cy + (midY - 5f) * scale,
            cx + (outerX - 5f) * scale, cy + (bottomY - 5f) * scale,
            arrowLinePaint
        )
    }

    /** Set area sentuh khusus per mode (dihitung di posisi akhir, tidak ikut bergeser saat transisi). */
    private fun layoutTouchTargets(mode: IslandMode, cx: Float, cy: Float) {
        if (mode == IslandMode.PLAYER) {
            val r = dp(13f)
            val ctrlY = cy + dp(28f)
            playPauseBounds.set(cx - r, ctrlY - r, cx + r, ctrlY + r)
        } else {
            playPauseBounds.setEmpty()
        }
    }

    /**
     * Menggambar isi satu mode (upload, pemutar, atau akor), digeser [alongOffset] sepanjang tepi
     * ([horizontal] = sumbu x untuk TOP, sumbu y untuk samping) dan diredupkan oleh [alpha].
     * Dipanggil dua kali saat transisi (mode asal + mode tujuan) untuk efek slide + fade.
     */
    private fun drawModeContent(
        canvas: Canvas, mode: IslandMode, cx: Float, cy: Float, horizontal: Boolean,
        alongOffset: Float, gap1: Float, gap2: Float, alpha: Float
    ) {
        if (alpha <= 0.002f) return
        canvas.save()
        if (horizontal) canvas.translate(alongOffset, 0f) else canvas.translate(0f, alongOffset)
        when (mode) {
            IslandMode.UPLOAD -> drawUpload(canvas, cx, cy, alpha)
            IslandMode.PLAYER -> drawPlayer(canvas, cx, cy, alpha)
            IslandMode.CHORD ->
                if (uploadState == UploadState.DONE) drawCarousel(canvas, cx, cy, horizontal, gap1, gap2, alpha)
                else drawChordPlaceholder(canvas, cx, cy, alpha)
        }
        canvas.restore()
    }

    // ---- Mode: Upload & Analyzer ------------------------------------------------------

    private fun drawUpload(canvas: Canvas, cx: Float, cy: Float, alpha: Float) {
        if (alpha <= 0.002f) return
        when (uploadState) {
            UploadState.IDLE -> drawUploadIdle(canvas, cx, cy, alpha)
            UploadState.ANALYZING, UploadState.DONE -> {
                drawWaveFill(canvas, alpha)
                drawSwirlAccents(canvas, alpha)
                drawUploadLabel(canvas, cx, cy, alpha)
            }
        }
    }

    private fun drawUploadIdle(canvas: Canvas, cx: Float, cy: Float, alpha: Float) {
        val ay = cy - dp(10f)
        arrowBgPaint.alpha = (90f * alpha).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, ay, dp(15f), arrowBgPaint)
        arrowLinePaint.alpha = (255f * alpha).toInt().coerceIn(0, 255)
        canvas.drawLine(cx, ay + dp(7f), cx, ay - dp(7f), arrowLinePaint)
        canvas.drawLine(cx - dp(6f), ay - dp(1f), cx, ay - dp(7f), arrowLinePaint)
        canvas.drawLine(cx + dp(6f), ay - dp(1f), cx, ay - dp(7f), arrowLinePaint)
        textPaint.textSize = dp(12.5f)
        textPaint.color = withAlpha(Color.WHITE, alpha)
        canvas.drawText("Tap untuk upload audio", cx, cy + dp(24f), textPaint)
    }

    /** Isian "air" naik dari bawah ke atas mengikuti progres analisis, bergelombang halus (bukan blur). */
    private fun drawWaveFill(canvas: Canvas, alpha: Float) {
        val progress = uploadProgress.coerceIn(0f, 1f)
        if (progress <= 0.001f) return
        val b = bodyBounds
        if (b.width() <= 0f || b.height() <= 0f) return
        val waveAmp = dp(4f)
        val waveLen = dp(34f)
        val fillTop = b.bottom - b.height() * progress
        val base = glowColors.getOrElse(1) { Color.rgb(60, 140, 255) }

        wavePath.reset()
        wavePath.moveTo(b.left, b.bottom)
        wavePath.lineTo(b.left, fillTop)
        var x = b.left
        while (x <= b.right) {
            val y = fillTop + sin((x - b.left) / waveLen * (2 * Math.PI).toFloat() + waveTime).toFloat() * waveAmp
            wavePath.lineTo(x, y)
            x += dp(6f)
        }
        wavePath.lineTo(b.right, fillTop)
        wavePath.lineTo(b.right, b.bottom)
        wavePath.close()

        wavePaint.shader = LinearGradient(
            0f, b.top, 0f, b.bottom,
            withAlpha(lighten(base, 0.2f), 0.8f * alpha), withAlpha(base, 0.5f * alpha),
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(wavePath, wavePaint)
        wavePaint.shader = null
    }

    /** Beberapa titik cahaya yang muter pelan di tepi dalam island, mengiringi gelombang. */
    private fun drawSwirlAccents(canvas: Canvas, alpha: Float) {
        val b = bodyBounds
        val rx = b.width() / 2f - dp(10f)
        val ry = b.height() / 2f - dp(6f)
        if (rx <= 0f || ry <= 0f) return
        val cx = b.centerX()
        val cy = b.centerY()
        val base = glowColors.getOrElse(2) { Color.rgb(90, 180, 255) }
        dotPaint.color = withAlpha(lighten(base, 0.3f), 0.9f * alpha)
        val n = 3
        for (i in 0 until n) {
            val t = waveTime * 0.6f + i * (2f * Math.PI.toFloat() / n)
            val x = cx + rx * cos(t)
            val y = cy + ry * sin(t)
            canvas.drawCircle(x, y, dp(2.6f), dotPaint)
        }
    }

    private fun drawUploadLabel(canvas: Canvas, cx: Float, cy: Float, alpha: Float) {
        val pct = (uploadProgress * 100).toInt()
        val stateText = when (uploadState) {
            UploadState.ANALYZING -> "Menganalisis... $pct%"
            UploadState.DONE -> "Selesai ✓  geser panah ke hasil akor"
            else -> ""
        }
        textPaint.textSize = dp(12.5f)
        textPaint.color = withAlpha(Color.WHITE, alpha)
        canvas.drawText(uploadFileName, cx, cy - dp(6f), textPaint)
        textPaint.textSize = dp(10.5f)
        textPaint.color = withAlpha(Color.WHITE, alpha * 0.8f)
        canvas.drawText(stateText, cx, cy + dp(12f), textPaint)
    }

    // ---- Mode: Pemutar (preview) -------------------------------------------------------

    private fun drawPlayer(canvas: Canvas, cx: Float, cy: Float, alpha: Float) {
        if (alpha <= 0.002f) return
        val artCx = cx - dp(96f)
        val rowY = cy - dp(28f)
        val artR = dp(15f)
        val base = glowColors.getOrElse(0) { Color.rgb(90, 150, 255) }

        artPaint.shader = LinearGradient(
            artCx - artR, rowY - artR, artCx + artR, rowY + artR,
            withAlpha(base, 0.95f * alpha), withAlpha(lighten(base), 0.95f * alpha),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(artCx - artR, rowY - artR, artCx + artR, rowY + artR, dp(6f), dp(6f), artPaint)
        artPaint.shader = null

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = dp(13.5f)
        textPaint.color = withAlpha(Color.WHITE, alpha)
        canvas.drawText(playerTitle, artCx + artR + dp(10f), rowY - dp(1f), textPaint)
        textPaint.textSize = dp(10.5f)
        textPaint.color = withAlpha(Color.WHITE, alpha * 0.6f)
        canvas.drawText(playerArtist, artCx + artR + dp(10f), rowY + dp(13f), textPaint)
        textPaint.textAlign = Paint.Align.CENTER

        val barHalf = dp(118f)
        val barLeft = cx - barHalf
        val barRight = cx + barHalf
        val barH = dp(3.5f)
        trackPaint.color = withAlpha(Color.WHITE, 0.18f * alpha)
        canvas.drawRoundRect(barLeft, cy - barH / 2f, barRight, cy + barH / 2f, barH / 2f, barH / 2f, trackPaint)
        val fillRight = barLeft + (barRight - barLeft) * playerProgress.coerceIn(0f, 1f)
        if (fillRight > barLeft) {
            trackPaint.color = withAlpha(Color.WHITE, 0.95f * alpha)
            canvas.drawRoundRect(barLeft, cy - barH / 2f, fillRight, cy + barH / 2f, barH / 2f, barH / 2f, trackPaint)
        }

        val ctrlY = cy + dp(28f)
        drawPrevNext(canvas, cx - dp(30f), ctrlY, true, alpha)
        drawPrevNext(canvas, cx + dp(30f), ctrlY, false, alpha)
        drawPlayPause(canvas, cx, ctrlY, alpha)
    }

    private fun drawPrevNext(canvas: Canvas, cx: Float, cy: Float, isPrev: Boolean, alpha: Float) {
        arrowLinePaint.alpha = (200f * alpha).toInt().coerceIn(0, 255)
        val s = dp(5f)
        if (isPrev) {
            canvas.drawLine(cx + s, cy - s, cx - s, cy, arrowLinePaint)
            canvas.drawLine(cx - s, cy, cx + s, cy + s, arrowLinePaint)
        } else {
            canvas.drawLine(cx - s, cy - s, cx + s, cy, arrowLinePaint)
            canvas.drawLine(cx + s, cy, cx - s, cy + s, arrowLinePaint)
        }
    }

    private fun drawPlayPause(canvas: Canvas, cx: Float, cy: Float, alpha: Float) {
        val r = dp(13f)
        arrowBgPaint.alpha = (140f * alpha).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, r, arrowBgPaint)
        if (isPlaying) {
            arrowLinePaint.alpha = (255f * alpha).toInt().coerceIn(0, 255)
            canvas.drawLine(cx - dp(3f), cy - dp(5f), cx - dp(3f), cy + dp(5f), arrowLinePaint)
            canvas.drawLine(cx + dp(3f), cy - dp(5f), cx + dp(3f), cy + dp(5f), arrowLinePaint)
        } else {
            playTrianglePath.reset()
            playTrianglePath.moveTo(cx - dp(4.5f), cy - dp(6f))
            playTrianglePath.lineTo(cx - dp(4.5f), cy + dp(6f))
            playTrianglePath.lineTo(cx + dp(6f), cy)
            playTrianglePath.close()
            dotPaint.color = withAlpha(Color.WHITE, alpha)
            canvas.drawPath(playTrianglePath, dotPaint)
        }
    }

    // ---- Mode: Akor (hasil) ------------------------------------------------------------

    /** Ditampilkan di island Akor selama belum ada hasil (belum upload/analisis). */
    private fun drawChordPlaceholder(canvas: Canvas, cx: Float, cy: Float, alpha: Float) {
        textPaint.textSize = dp(12.5f)
        textPaint.color = withAlpha(Color.WHITE, 0.55f * alpha)
        canvas.drawText("Belum ada hasil akor", cx, cy - dp(4f), textPaint)
        textPaint.textSize = dp(10.5f)
        textPaint.color = withAlpha(Color.WHITE, 0.35f * alpha)
        canvas.drawText("Upload & analisis dulu di island pertama", cx, cy + dp(12f), textPaint)
    }

    /**
     * Tiga akor sekaligus: tengah (skala 1, terang), dua tetangga (skala 0,72, redup 40%).
     * [slide] (-1..1) menggeser semuanya satu langkah maju/mundur; akor yang keluar memudar, yang masuk muncul dari tepi.
     * [horizontal] true = sejajar kiri-kanan (portrait), false = atas-bawah (landscape samping).
     */
    private fun drawCarousel(
        canvas: Canvas, cx: Float, cy: Float, horizontal: Boolean,
        gap1: Float, gap2: Float, openAlpha: Float
    ) {
        val n = chords.size
        val items = ArrayList<FloatArray>(4)   // [j, r]
        for (j in -2..2) {
            val r = j - slide
            if (abs(r) < 2f) items.add(floatArrayOf(j.toFloat(), r))
        }
        items.sortByDescending { abs(it[1]) }   // yang paling jauh digambar dulu, tengah paling akhir

        for (item in items) {
            val j = item[0].toInt()
            val r = item[1]
            val ar = abs(r)
            val off = (if (ar <= 1f) ar * gap1 else gap1 + (ar - 1f) * (gap2 - gap1)) * (if (r < 0) -1f else 1f)
            val k = if (ar <= 1f) lerp(1f, 0.72f, ar) else lerp(0.72f, 0.6f, ar - 1f)
            val al = (if (ar <= 1f) lerp(1f, 0.4f, ar) else lerp(0.4f, 0f, ar - 1f)) * openAlpha

            val i = ((idx + j) % n + n) % n
            val x = if (horizontal) cx + dp(off) else cx
            val y = if (horizontal) cy else cy + dp(off)
            glyph.draw(canvas, chords[i], shapes[i], x, y, k, al)
        }
    }
}
