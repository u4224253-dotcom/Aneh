package com.cfwan.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.abs

/** Sisi layar tempat island menempel. TOP = portrait, LEFT/RIGHT = landscape (sisi kamera). */
enum class Side { TOP, LEFT, RIGHT }

/** Mode isi island: akor gitar (carousel) atau lirik lagu (bergulir). Dipindah lewat panah kiri/kanan. */
enum class IslandMode { CHORD, LYRICS }

/**
 * Island CfWan: tiga akor gitar. Akor tengah besar, kiri-kanan lebih kecil dan redup,
 * lalu bergantian bergeser (demo dulu, belum terhubung ke deteksi akor).
 * Ada juga mode Lirik: tiga baris lirik bergulir vertikal, baris tengah menyala (demo juga).
 * Panah kiri/kanan = pindah MODE (akor <-> lirik); mengetuk/menggeser badan island =
 * maju-mundur isi di dalam mode yang sedang aktif (akor berikutnya, atau baris lirik berikutnya).
 * Transisi antar mode pakai slide + fade biasa (bukan blur, supaya tetap ringan).
 * TOP: melebar horizontal di tepi atas. LEFT/RIGHT: berdiri di sisi layar saat landscape,
 * akor tersusun vertikal dan isinya tetap tegak terbaca.
 */
class IslandView(context: Context) : View(context) {

    var side: Side = Side.TOP
        set(value) {
            if (field != value) {
                field = value
                requestLayout()
                invalidate()
            }
        }

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    // ---- Ukuran mode TOP (dp) ----
    private val fullW = 310f
    private val fullH = 60f
    private val fullR = 19f
    private val fullE = 13f
    private val startW = 120f
    private val startH = 28f
    private val startR = 12f
    private val startE = 8f

    // ---- Ukuran mode samping (dp): D = kedalaman dari tepi layar, L = panjang sepanjang tepi ----
    private val sFullD = 88f
    private val sFullL = 150f
    private val sFullR = 22f
    private val sFullE = 14f
    private val sStartD = 28f
    private val sStartL = 100f
    private val sStartR = 12f
    private val sStartE = 8f

    // ---- Mode lirik butuh sedikit lebih lebar/panjang supaya tiga baris teks muat nyaman ----
    private val lyricsExtraW = 80f
    private val lyricsExtraH = 6f
    private val lyricsExtraL = 40f
    private fun modeFullW(m: IslandMode) = if (m == IslandMode.LYRICS) fullW + lyricsExtraW else fullW
    private fun modeFullH(m: IslandMode) = if (m == IslandMode.LYRICS) fullH + lyricsExtraH else fullH
    private fun modeFullL(m: IslandMode) = if (m == IslandMode.LYRICS) sFullL + lyricsExtraL else sFullL

    // ---- Carousel akor ----
    private val chords = listOf("C", "G", "Am", "F", "Dm", "E7", "A", "Em", "D", "Bm")
    private val shapes = chords.map { GuitarChords.pick(it) }
    private val glyph = ChordGlyphPainter(d)
    private var idx = 0          // akor yang sedang di tengah
    private var slide = 0f       // -1..1: progres bergeser (positif = ke akor berikutnya, negatif = ke sebelumnya)

    // ---- Lirik (demo): tiga baris, tengah menyala, bergulir vertikal ----
    private val lyricLines = listOf(
        "Pagi melipat cahaya kota",
        "jadi burung kertas di malam ini",
        "andai bisa ku di sampingmu",
        "kuberi semua musimku",
        "setiap panas, setiap hujan",
        "memanggil namamu"
    )
    private var lyricIdx = 0
    private var lyricSlide = 0f
    private var lyricStepAnim: ValueAnimator? = null
    private val lyricPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    // ---- Mode isi island & transisi pindah mode ----
    private var modeIdx = 0           // mode yang sedang/baru saja dituju
    private var modeAnimFrom = 0      // mode asal transisi (dipakai untuk fade-out + geser keluar)
    private var modeAnimDir = 1
    private var modeAnimT = 1f        // 0..1: 0 = baru mulai pindah mode, 1 = sudah settle di modeIdx
    private var modeAnim: ValueAnimator? = null

    private val autoMs = 2400L     // jeda geser otomatis
    private val resumeMs = 6000L   // jeda geser otomatis setelah disentuh manual
    private var autoOn = false
    private var stepAnim: ValueAnimator? = null
    private val autoRunnable = object : Runnable {
        override fun run() {
            if (IslandMode.values()[modeIdx] == IslandMode.CHORD) step(1) else lyricStep(1)
            postDelayed(this, autoMs)
        }
    }

    // ---- Sentuhan ----
    private val bodyBounds = RectF()
    private val leftArrowBounds = RectF()
    private val rightArrowBounds = RectF()
    private var downX = 0f
    private var downY = 0f
    private var downInside = false
    private var downArrowDirection = 0

    // ---- Warna gradasi (diatur dari aplikasi) ----
    private val prefs = context.getSharedPreferences(IslandService.PREFS, Context.MODE_PRIVATE)
    private var glowOn = true
    private var glowColors = IslandGlow.colors(IslandGlow.DEF_HUE, IslandGlow.DEF_SPREAD)
    private var glowIntensity = 1f
    private var shRadiusDp = IslandGlow.shadowRadiusDp(IslandGlow.DEF_SH_THICK)
    private var shIntensity = IslandGlow.DEF_SH_INT

    init { reloadColors() }

    /** Baca ulang pengaturan warna dari preferensi (dipanggil saat user mengubah warna di aplikasi). */
    fun reloadColors() {
        glowOn = prefs.getBoolean(IslandService.KEY_GLOW, true)
        glowColors = IslandGlow.colors(
            prefs.getInt(IslandService.KEY_HUE, IslandGlow.DEF_HUE).coerceIn(0, 360),
            prefs.getInt(IslandService.KEY_SPREAD, IslandGlow.DEF_SPREAD).coerceIn(0, IslandGlow.MAX_SPREAD)
        )
        glowIntensity = prefs.getInt(IslandService.KEY_GLOW_INT, IslandGlow.DEF_GLOW_INT).coerceIn(0, 100) / 100f
        shRadiusDp = IslandGlow.shadowRadiusDp(prefs.getInt(IslandService.KEY_SH_THICK, IslandGlow.DEF_SH_THICK))
        shIntensity = prefs.getInt(IslandService.KEY_SH_INT, IslandGlow.DEF_SH_INT).coerceIn(0, 100)
        invalidate()
    }

    private var p = 0f           // progres buka-tutup (boleh >1 karena overshoot)
    private var expandAnim: ValueAnimator? = null

    private val path = Path()
    private val edgeMatrix = Matrix()
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val arrowBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val arrowLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = dp(2.4f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (side == Side.TOP) {
            val maxW = maxOf(fullW, modeFullW(IslandMode.LYRICS))
            val maxH = maxOf(fullH, modeFullH(IslandMode.LYRICS))
            setMeasuredDimension(
                dp(maxW + 2 * fullE + 32f).toInt(),
                dp(maxH + 22f).toInt()
            )
        } else {
            val maxL = maxOf(sFullL, modeFullL(IslandMode.LYRICS))
            setMeasuredDimension(
                dp(sFullD + 24f).toInt(),
                dp(maxL + 2 * sFullE + 32f).toInt()
            )
        }
    }

    // ---- Animasi -------------------------------------------------------------------

    fun show() {
        expandAnim?.cancel()
        expandAnim = ValueAnimator.ofFloat(p, 1f).apply {
            duration = 620
            interpolator = OvershootInterpolator(1.1f)
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
            start()
        }
        startCarousel()
    }

    fun hide(onEnd: () -> Unit) {
        expandAnim?.cancel()
        expandAnim = ValueAnimator.ofFloat(p, 0f).apply {
            duration = 380
            interpolator = AccelerateInterpolator(1.4f)
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) { cancelled = true }
                override fun onAnimationEnd(animation: Animator) { if (!cancelled) onEnd() }
            })
            start()
        }
    }

    private fun startCarousel() {
        if (autoOn) return
        autoOn = true
        postDelayed(autoRunnable, autoMs)
    }

    /** Geser carousel akor satu langkah: [dir] = 1 maju (akor selanjutnya), -1 mundur (akor sebelumnya). */
    fun step(dir: Int) {
        stepAnim?.end()   // selesaikan geseran sebelumnya dulu supaya ketukan beruntun tidak hilang
        stepAnim = ValueAnimator.ofFloat(0f, dir.toFloat()).apply {
            duration = 320
            interpolator = DecelerateInterpolator(2f)
            addUpdateListener { slide = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    idx = ((idx + dir) % chords.size + chords.size) % chords.size
                    slide = 0f
                    invalidate()
                }
            })
            start()
        }
    }

    /** Geser manual akor dari sentuhan; geser otomatis ditunda dulu. */
    private fun manualStep(dir: Int) {
        step(dir)
        if (autoOn) {
            removeCallbacks(autoRunnable)
            postDelayed(autoRunnable, resumeMs)
        }
    }

    /** Geser carousel lirik satu baris: [dir] = 1 baris berikutnya, -1 baris sebelumnya. */
    fun lyricStep(dir: Int) {
        lyricStepAnim?.end()
        lyricStepAnim = ValueAnimator.ofFloat(0f, dir.toFloat()).apply {
            duration = 340
            interpolator = DecelerateInterpolator(2f)
            addUpdateListener { lyricSlide = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    lyricIdx = ((lyricIdx + dir) % lyricLines.size + lyricLines.size) % lyricLines.size
                    lyricSlide = 0f
                    invalidate()
                }
            })
            start()
        }
    }

    /** Geser manual lirik dari sentuhan; geser otomatis ditunda dulu. */
    private fun manualLyricStep(dir: Int) {
        lyricStep(dir)
        if (autoOn) {
            removeCallbacks(autoRunnable)
            postDelayed(autoRunnable, resumeMs)
        }
    }

    /**
     * Pindah mode (akor <-> lirik) satu langkah: [dir] = 1 mode berikutnya, -1 mode sebelumnya.
     * Isi mode lama memudar sambil bergeser keluar, isi mode baru masuk dari sisi berlawanan sambil
     * memudar masuk; badan island ikut melebar/menyempit mengikuti ukuran mode baru. Semua lewat
     * alpha + translate saja (tanpa blur) supaya ringan digambar terus-menerus di overlay.
     */
    private fun switchMode(dir: Int) {
        val n = IslandMode.values().size
        val newIdx = ((modeIdx + dir) % n + n) % n
        if (newIdx == modeIdx) return
        modeAnim?.cancel()
        modeAnimFrom = modeIdx
        modeAnimDir = dir
        modeIdx = newIdx
        modeAnimT = 0f
        modeAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 460
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { modeAnimT = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    /** Pindah mode manual dari ketukan panah; geser otomatis ditunda dulu. */
    private fun manualSwitchMode(dir: Int) {
        switchMode(dir)
        if (autoOn) {
            removeCallbacks(autoRunnable)
            postDelayed(autoRunnable, resumeMs)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downArrowDirection = when {
                    p > 0.5f && side == Side.TOP && leftArrowBounds.contains(e.x, e.y) -> -1
                    p > 0.5f && side == Side.TOP && rightArrowBounds.contains(e.x, e.y) -> 1
                    else -> 0
                }
                downInside = downArrowDirection != 0 ||
                    (p > 0.5f && bodyBounds.contains(e.x, e.y))
                downX = e.x
                downY = e.y
                return downInside
            }
            MotionEvent.ACTION_UP -> {
                if (!downInside) return false
                downInside = false
                val arrowDirection = downArrowDirection
                downArrowDirection = 0
                if (arrowDirection != 0) {
                    // Panah kiri/kanan = pindah MODE (akor <-> lirik), bukan menggeser isi carousel.
                    val arrowBounds = if (arrowDirection < 0) leftArrowBounds else rightArrowBounds
                    if (arrowBounds.contains(e.x, e.y)) manualSwitchMode(arrowDirection)
                    return true
                }
                val horizontal = side == Side.TOP
                val moved = if (horizontal) e.x - downX else e.y - downY
                val dir = if (abs(moved) > dp(24f)) {
                    if (moved < 0) 1 else -1                       // geser ke kiri/atas = maju
                } else {
                    val frac = if (horizontal) (e.x - bodyBounds.left) / bodyBounds.width()
                               else (e.y - bodyBounds.top) / bodyBounds.height()
                    if (frac < 0.5f) -1 else 1                      // ketuk kiri/atas = mundur, kanan/bawah = maju
                }
                // Ketuk/geser badan island = maju-mundur isi di DALAM mode yang sedang aktif.
                if (IslandMode.values()[modeIdx] == IslandMode.CHORD) manualStep(dir) else manualLyricStep(dir)
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                val was = downInside
                downInside = false
                downArrowDirection = 0
                return was
            }
        }
        return downInside
    }

    override fun onDetachedFromWindow() {
        expandAnim?.cancel()
        removeCallbacks(autoRunnable)
        autoOn = false
        stepAnim?.cancel()
        lyricStepAnim?.cancel()
        modeAnim?.cancel()
        super.onDetachedFromWindow()
    }

    // ---- Bentuk ---------------------------------------------------------------------

    /**
     * Badan hitam: sisi atas rata, dua sudut bawah membulat, "telinga" cekung di kiri-kanan.
     * Koordinat lokal: x sepanjang tepi, y = kedalaman dari tepi. Lebar total = totalW.
     */
    private fun buildShape(totalW: Float, h: Float, r: Float, e: Float) {
        val w = totalW
        path.reset()
        path.moveTo(0f, 0f)
        path.lineTo(w, 0f)
        path.arcTo(RectF(w - e, 0f, w + e, 2 * e), 270f, -90f)              // telinga kanan
        path.lineTo(w - e, h - r)
        path.arcTo(RectF(w - e - 2 * r, h - 2 * r, w - e, h), 0f, 90f)      // sudut kanan bawah
        path.lineTo(e + r, h)
        path.arcTo(RectF(e, h - 2 * r, e + 2 * r, h), 90f, 90f)             // sudut kiri bawah
        path.lineTo(e, e)
        path.arcTo(RectF(-e, 0f, e, 2 * e), 0f, -90f)                       // telinga kiri
        path.close()
    }

    // ---- Gambar ---------------------------------------------------------------------

    override fun onDraw(canvas: Canvas) {
        if (side == Side.TOP) drawTop(canvas) else drawSide(canvas)
    }

    private fun drawTop(canvas: Canvas) {
        val vw = width.toFloat()

        val curMode = IslandMode.values()[modeIdx]
        val fromMode = IslandMode.values()[modeAnimFrom]
        val fullWNow = lerp(modeFullW(fromMode), modeFullW(curMode), modeAnimT)
        val fullHNow = lerp(modeFullH(fromMode), modeFullH(curMode), modeAnimT)

        val wDp = lerp(startW, fullWNow, p).coerceIn(0f, fullWNow + 10f)
        val hDp = lerp(startH, fullHNow, p).coerceAtLeast(0f)
        val ePx = dp(lerp(startE, fullE, p).coerceAtLeast(0f))
        val bodyW = dp(wDp)
        val bodyH = dp(hDp)
        val rPx = dp(lerp(startR, fullR, p).coerceAtLeast(0f)).coerceAtMost(minOf(bodyH, bodyW) / 2f)

        val totalW = bodyW + 2 * ePx
        buildShape(totalW, bodyH, rPx, ePx)
        path.offset((vw - totalW) / 2f, 0f)
        path.computeBounds(bodyBounds, true)
        IslandGlow.drawShadow(canvas, path, 0f, dp(shRadiusDp * 0.4f), d, p, shRadiusDp, shIntensity)
        canvas.drawPath(path, bodyPaint)

        val a = ((p - 0.5f) / 0.4f).coerceIn(0f, 1f)
        if (a <= 0f) return

        canvas.save()
        canvas.clipPath(path)
        if (glowOn) {
            IslandGlow.draw(canvas, bodyBounds.left, bodyBounds.top, bodyBounds.width(), bodyBounds.height(), glowColors, a * glowIntensity)
        }
        val arrowY = bodyBounds.centerY()
        val arrowOffset = dp(fullE + 22f)
        val arrowHitRadius = dp(14f)
        val leftArrowX = bodyBounds.left + arrowOffset
        val rightArrowX = bodyBounds.right - arrowOffset
        leftArrowBounds.set(
            leftArrowX - arrowHitRadius, arrowY - arrowHitRadius,
            leftArrowX + arrowHitRadius, arrowY + arrowHitRadius
        )
        rightArrowBounds.set(
            rightArrowX - arrowHitRadius, arrowY - arrowHitRadius,
            rightArrowX + arrowHitRadius, arrowY + arrowHitRadius
        )

        val contentCy = dp(fullHNow) / 2f
        val dirF = modeAnimDir.toFloat()
        val slideDist = dp(60f)
        val offFrom = -dirF * slideDist * modeAnimT
        val offTo = dirF * slideDist * (1f - modeAnimT)
        drawModeContent(canvas, fromMode, vw / 2f, contentCy, true, offFrom, 76f, 140f, a * (1f - modeAnimT))
        drawModeContent(canvas, curMode, vw / 2f, contentCy, true, offTo, 76f, 140f, a * modeAnimT)
        drawArrow(canvas, leftArrowX, arrowY, true, a)
        drawArrow(canvas, rightArrowX, arrowY, false, a)
        canvas.restore()
    }

    private fun drawSide(canvas: Canvas) {
        leftArrowBounds.setEmpty()
        rightArrowBounds.setEmpty()
        val vw = width.toFloat()
        val vh = height.toFloat()
        val left = side == Side.LEFT

        val curMode = IslandMode.values()[modeIdx]
        val fromMode = IslandMode.values()[modeAnimFrom]
        val fullLNow = lerp(modeFullL(fromMode), modeFullL(curMode), modeAnimT)

        val depthDp = lerp(sStartD, sFullD, p).coerceIn(0f, sFullD + 8f)
        val lenDp = lerp(sStartL, fullLNow, p).coerceIn(0f, fullLNow + 10f)
        val ePx = dp(lerp(sStartE, sFullE, p).coerceAtLeast(0f))
        val depth = dp(depthDp)
        val len = dp(lenDp)
        val rPx = dp(lerp(sStartR, sFullR, p).coerceAtLeast(0f)).coerceAtMost(minOf(depth, len) / 2f)

        val totalLen = len + 2 * ePx
        val startAlong = (vh - totalLen) / 2f

        buildShape(totalLen, depth, rPx, ePx)
        // Lokal (x sepanjang tepi, y kedalaman) -> layar. Bentuk simetris, jadi transpose = rotasi.
        if (left) {
            edgeMatrix.setValues(floatArrayOf(0f, 1f, 0f, 1f, 0f, startAlong, 0f, 0f, 1f))
        } else {
            edgeMatrix.setValues(floatArrayOf(0f, -1f, vw, 1f, 0f, startAlong, 0f, 0f, 1f))
        }
        path.transform(edgeMatrix)
        path.computeBounds(bodyBounds, true)
        IslandGlow.drawShadow(canvas, path, dp(shRadiusDp * 0.4f) * (if (left) 1f else -1f), 0f, d, p, shRadiusDp, shIntensity)
        canvas.drawPath(path, bodyPaint)

        val a = ((p - 0.5f) / 0.4f).coerceIn(0f, 1f)
        if (a <= 0f) return

        canvas.save()
        canvas.clipPath(path)
        if (glowOn) {
            // Gradasi digambar di koordinat lokal (x sepanjang tepi, y = kedalaman) supaya "bawah" = sisi jauh dari tepi layar
            canvas.save()
            canvas.concat(edgeMatrix)
            IslandGlow.draw(canvas, 0f, 0f, totalLen, depth, glowColors, a * glowIntensity)
            canvas.restore()
        }
        val boxW = dp(sFullD)
        // geser 6dp menjauhi tepi layar (kamera ada di tepi ini)
        val shift = dp(6f) * (if (left) 1f else -1f)
        val cx = (if (left) 0f else vw - boxW) + boxW / 2f + shift
        val dirF = modeAnimDir.toFloat()
        val slideDist = dp(40f)
        val offFrom = -dirF * slideDist * modeAnimT
        val offTo = dirF * slideDist * (1f - modeAnimT)
        drawModeContent(canvas, fromMode, cx, vh / 2f, false, offFrom, 52f, 80f, a * (1f - modeAnimT))
        drawModeContent(canvas, curMode, cx, vh / 2f, false, offTo, 52f, 80f, a * modeAnimT)
        canvas.restore()
    }

    /** Panah bulat kecil mengikuti ikon Focus Timer pada HTML. */
    private fun drawArrow(canvas: Canvas, cx: Float, cy: Float, left: Boolean, alpha: Float) {
        if (alpha <= 0f) return

        arrowBgPaint.alpha = (72f * alpha).toInt().coerceIn(0, 255)
        arrowLinePaint.alpha = (255f * alpha).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, dp(11f), arrowBgPaint)

        val scale = dp(0.9f)
        val outerX = if (left) 6.5f else 3.5f
        val innerX = if (left) 3f else 7f
        val topY = 1.5f
        val midY = 5f
        val bottomY = 8.5f
        canvas.drawLine(
            cx + (outerX - 5f) * scale, cy + (topY - 5f) * scale,
            cx + (innerX - 5f) * scale, cy + (midY - 5f) * scale,
            arrowLinePaint
        )
        canvas.drawLine(
            cx + (innerX - 5f) * scale, cy + (midY - 5f) * scale,
            cx + (outerX - 5f) * scale, cy + (bottomY - 5f) * scale,
            arrowLinePaint
        )
    }

    /**
     * Menggambar isi satu mode (akor atau lirik), digeser [alongOffset] sepanjang tepi
     * ([horizontal] = sumbu x untuk TOP, sumbu y untuk samping) dan diredupkan oleh [alpha].
     * Dipanggil dua kali saat transisi (mode asal + mode tujuan) untuk efek slide + fade.
     */
    private fun drawModeContent(
        canvas: Canvas, mode: IslandMode, cx: Float, cy: Float, horizontal: Boolean,
        alongOffset: Float, gap1: Float, gap2: Float, alpha: Float
    ) {
        if (alpha <= 0.002f) return
        canvas.save()
        if (horizontal) canvas.translate(alongOffset, 0f) else canvas.translate(0f, alongOffset)
        when (mode) {
            IslandMode.CHORD -> drawCarousel(canvas, cx, cy, horizontal, gap1, gap2, alpha)
            IslandMode.LYRICS -> drawLyrics(canvas, cx, cy, alpha)
        }
        canvas.restore()
    }

    /**
     * Tiga akor sekaligus: tengah (skala 1, terang), dua tetangga (skala 0,72, redup 40%).
     * [slide] (-1..1) menggeser semuanya satu langkah maju/mundur; akor yang keluar memudar, yang masuk muncul dari tepi.
     * [horizontal] true = sejajar kiri-kanan (portrait), false = atas-bawah (landscape samping).
     */
    private fun drawCarousel(
        canvas: Canvas, cx: Float, cy: Float, horizontal: Boolean,
        gap1: Float, gap2: Float, openAlpha: Float
    ) {
        val n = chords.size
        val items = ArrayList<FloatArray>(4)   // [j, r]
        for (j in -2..2) {
            val r = j - slide
            if (abs(r) < 2f) items.add(floatArrayOf(j.toFloat(), r))
        }
        items.sortByDescending { abs(it[1]) }   // yang paling jauh digambar dulu, tengah paling akhir

        for (item in items) {
            val j = item[0].toInt()
            val r = item[1]
            val ar = abs(r)
            val off = (if (ar <= 1f) ar * gap1 else gap1 + (ar - 1f) * (gap2 - gap1)) * (if (r < 0) -1f else 1f)
            val k = if (ar <= 1f) lerp(1f, 0.72f, ar) else lerp(0.72f, 0.6f, ar - 1f)
            val al = (if (ar <= 1f) lerp(1f, 0.4f, ar) else lerp(0.4f, 0f, ar - 1f)) * openAlpha

            val i = ((idx + j) % n + n) % n
            val x = if (horizontal) cx + dp(off) else cx
            val y = if (horizontal) cy else cy + dp(off)
            glyph.draw(canvas, chords[i], shapes[i], x, y, k, al)
        }
    }

    /**
     * Tiga baris lirik sekaligus, bergulir vertikal: baris tengah terang & sedikit lebih besar,
     * baris atas/bawah redup. [lyricSlide] (-1..1) menggeser satu baris maju/mundur, baris yang
     * keluar memudar ke atas/bawah, baris berikutnya masuk dari arah berlawanan.
     */
    private fun drawLyrics(canvas: Canvas, cx: Float, cy: Float, alpha: Float) {
        if (alpha <= 0.002f) return
        val n = lyricLines.size
        val lineGap = dp(19f)
        for (j in -1..1) {
            val r = j - lyricSlide
            if (abs(r) >= 1.6f) continue
            val i = ((lyricIdx + j) % n + n) % n
            val on = (1f - abs(r)).coerceIn(0f, 1f)
            val off = r * lineGap
            lyricPaint.textSize = dp(lerp(12f, 15f, on))
            lyricPaint.color = Color.argb(
                (255 * (lerp(0.3f, 1f, on) * alpha)).toInt().coerceIn(0, 255),
                255, 255, 255
            )
            canvas.drawText(lyricLines[i], cx, cy + off + lyricPaint.textSize * 0.32f, lyricPaint)
        }
    }
}
