package com.cfwan.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator

/**
 * Notch / "island" untuk CfWan.
 * Ukuran (dp) disalin dari versi web: 310 x 60, radius 19, telinga 13.
 */
class IslandView(context: Context) : View(context) {

    /** Persentase baterai 0..100 */
    var level: Int = 70

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    // Bentuk akhir (sama dengan web)
    private val fullW = 310f
    private val fullH = 60f
    private val fullR = 19f
    private val fullE = 13f

    // Bentuk awal (notch tertutup)
    private val startW = 120f
    private val startH = 28f
    private val startR = 12f
    private val startE = 8f

    private var p = 0f      // progres buka-tutup (boleh >1 karena overshoot)
    private var arc = 0f    // progres cincin baterai 0..1

    private var expandAnim: ValueAnimator? = null
    private var arcAnim: ValueAnimator? = null

    private val green = Color.parseColor("#33E07A")
    private val path = Path()
    private val bolt = Path()

    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = dp(5f); color = green
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = dp(5f); strokeCap = Paint.Cap.ROUND; color = green
    }
    private val boltPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = dp(15f)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = dp(11.5f)
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private val pctPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = dp(24f); textAlign = Paint.Align.RIGHT
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    init {
        // Petir: path "M6 0 0 8h4l-1 6 6-8H5z" pada viewBox 10x14
        bolt.moveTo(6f, 0f); bolt.lineTo(0f, 8f); bolt.lineTo(4f, 8f)
        bolt.lineTo(3f, 14f); bolt.lineTo(9f, 6f); bolt.lineTo(5f, 6f); bolt.close()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            dp(fullW + 2 * fullE + 24f).toInt(),
            dp(fullH + 8f).toInt()
        )
    }

    fun show() {
        expandAnim?.cancel()
        arcAnim?.cancel()
        arc = 0f

        expandAnim = ValueAnimator.ofFloat(p, 1f).apply {
            duration = 620
            interpolator = OvershootInterpolator(1.1f)
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
            start()
        }
        arcAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            startDelay = 350
            interpolator = DecelerateInterpolator(2f)
            addUpdateListener { arc = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun hide(onEnd: () -> Unit) {
        expandAnim?.cancel()
        expandAnim = ValueAnimator.ofFloat(p, 0f).apply {
            duration = 380
            interpolator = AccelerateInterpolator(1.4f)
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) { cancelled = true }
                override fun onAnimationEnd(animation: Animator) { if (!cancelled) onEnd() }
            })
            start()
        }
    }

    override fun onDetachedFromWindow() {
        expandAnim?.cancel()
        arcAnim?.cancel()
        super.onDetachedFromWindow()
    }

    /** Badan hitam rata di atas, sudut bawah membulat, "telinga" cekung di kiri-kanan. */
    private fun buildShape(totalW: Float, h: Float, r: Float, e: Float) {
        val w = totalW
        path.reset()
        path.moveTo(0f, 0f)
        path.lineTo(w, 0f)
        path.arcTo(RectF(w - e, 0f, w + e, 2 * e), 270f, -90f)              // telinga kanan
        path.lineTo(w - e, h - r)
        path.arcTo(RectF(w - e - 2 * r, h - 2 * r, w - e, h), 0f, 90f)      // sudut kanan bawah
        path.lineTo(e + r, h)
        path.arcTo(RectF(e, h - 2 * r, e + 2 * r, h), 90f, 90f)             // sudut kiri bawah
        path.lineTo(e, e)
        path.arcTo(RectF(-e, 0f, e, 2 * e), 0f, -90f)                       // telinga kiri
        path.close()
    }

    private fun textCenterY(paint: Paint, cy: Float): Float {
        val fm = paint.fontMetrics
        return cy - (fm.ascent + fm.descent) / 2f
    }

    override fun onDraw(canvas: Canvas) {
        val vw = width.toFloat()

        val wDp = lerp(startW, fullW, p).coerceAtMost(fullW + 10f)
        val hDp = lerp(startH, fullH, p).coerceAtLeast(0f)
        var rPx = dp(lerp(startR, fullR, p).coerceAtLeast(0f))
        val ePx = dp(lerp(startE, fullE, p).coerceAtLeast(0f))
        val bodyW = dp(wDp)
        val bodyH = dp(hDp)
        rPx = rPx.coerceAtMost(minOf(bodyH, bodyW) / 2f)

        val totalW = bodyW + 2 * ePx
        val left = (vw - totalW) / 2f

        canvas.save()
        canvas.translate(left, 0f)
        buildShape(totalW, bodyH, rPx, ePx)
        canvas.drawPath(path, bodyPaint)
        canvas.clipPath(path)
        canvas.restore()

        // Isi muncul setelah badan hampir penuh
        val a = ((p - 0.5f) / 0.4f).coerceIn(0f, 1f)
        if (a <= 0f) return

        canvas.save()
        canvas.translate(left, 0f)
        canvas.clipPath(path)
        canvas.translate(-left, 0f)
        // Titik asal konten = pojok kiri badan ukuran penuh
        canvas.translate((vw - dp(fullW)) / 2f, 0f)

        // Cincin baterai: pusat (35,30), r 11, tebal 5
        val cx = dp(35f); val cy = dp(30f); val rr = dp(11f)
        val oval = RectF(cx - rr, cy - rr, cx + rr, cy + rr)
        trackPaint.alpha = (255 * 0.28f * a).toInt()
        canvas.drawArc(oval, 0f, 360f, false, trackPaint)
        arcPaint.alpha = (255 * a).toInt()
        val sweep = 360f * level.coerceIn(0, 100) / 100f * arc.coerceIn(0f, 1f)
        if (sweep > 0f) canvas.drawArc(oval, -90f, sweep, false, arcPaint)

        // Petir 11 x 13 di tengah cincin
        boltPaint.alpha = (255 * a).toInt()
        canvas.save()
        canvas.translate(cx - dp(5.5f), cy - dp(6.5f))
        canvas.scale(dp(11f) / 10f, dp(13f) / 14f)
        canvas.drawPath(bolt, boltPaint)
        canvas.restore()

        // Teks
        titlePaint.alpha = (255 * a).toInt()
        canvas.drawText("Charging", dp(64f), textCenterY(titlePaint, dp(22f)), titlePaint)
        subPaint.alpha = (255 * 0.5f * a).toInt()
        canvas.drawText("Charger connected", dp(64f), textCenterY(subPaint, dp(40f)), subPaint)
        pctPaint.alpha = (255 * a).toInt()
        canvas.drawText("$level%", dp(fullW - 22f), textCenterY(pctPaint, dp(30f)), pctPaint)

        canvas.restore()
    }
}
