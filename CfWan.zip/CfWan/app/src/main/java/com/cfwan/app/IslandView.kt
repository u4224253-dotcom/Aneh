package com.cfwan.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.abs

/** Sisi layar tempat island menempel. TOP = portrait, LEFT/RIGHT = landscape (sisi kamera). */
enum class Side { TOP, LEFT, RIGHT }

/**
 * Island CfWan: tiga akor gitar. Akor tengah besar, kiri-kanan lebih kecil dan redup,
 * lalu bergantian bergeser (demo dulu, belum terhubung ke deteksi akor).
 * TOP: melebar horizontal di tepi atas. LEFT/RIGHT: berdiri di sisi layar saat landscape,
 * akor tersusun vertikal dan isinya tetap tegak terbaca.
 */
class IslandView(context: Context) : View(context) {

    var side: Side = Side.TOP
        set(value) {
            if (field != value) {
                field = value
                requestLayout()
                invalidate()
            }
        }

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    // ---- Ukuran mode TOP (dp) ----
    private val fullW = 300f
    private val fullH = 122f
    private val fullR = 30f
    private val fullE = 16f
    private val startW = 120f
    private val startH = 28f
    private val startR = 12f
    private val startE = 8f

    // ---- Ukuran mode samping (dp): D = kedalaman dari tepi layar, L = panjang sepanjang tepi ----
    private val sFullD = 104f
    private val sFullL = 250f
    private val sFullR = 26f
    private val sFullE = 14f
    private val sStartD = 28f
    private val sStartL = 100f
    private val sStartR = 12f
    private val sStartE = 8f

    // ---- Carousel akor ----
    private val chords = listOf("C", "G", "Am", "F", "Dm", "E7", "A", "Em", "D", "Bm")
    private val shapes = chords.map { GuitarChords.pick(it) }
    private val glyph = ChordGlyphPainter(d)
    private var idx = 0          // akor yang sedang di tengah
    private var slide = 0f       // 0..1: progres bergeser ke akor berikutnya
    private val cycleMs = 2400L
    private val holdFrac = 0.78f // sisanya dipakai untuk bergeser

    private var p = 0f           // progres buka-tutup (boleh >1 karena overshoot)
    private var expandAnim: ValueAnimator? = null
    private var carouselAnim: ValueAnimator? = null

    private val path = Path()
    private val edgeMatrix = Matrix()
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (side == Side.TOP) {
            setMeasuredDimension(
                dp(fullW + 2 * fullE + 24f).toInt(),
                dp(fullH + 8f).toInt()
            )
        } else {
            setMeasuredDimension(
                dp(sFullD + 10f).toInt(),
                dp(sFullL + 2 * sFullE + 24f).toInt()
            )
        }
    }

    // ---- Animasi -------------------------------------------------------------------

    fun show() {
        expandAnim?.cancel()
        expandAnim = ValueAnimator.ofFloat(p, 1f).apply {
            duration = 620
            interpolator = OvershootInterpolator(1.1f)
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
            start()
        }
        startCarousel()
    }

    fun hide(onEnd: () -> Unit) {
        expandAnim?.cancel()
        expandAnim = ValueAnimator.ofFloat(p, 0f).apply {
            duration = 380
            interpolator = AccelerateInterpolator(1.4f)
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) { cancelled = true }
                override fun onAnimationEnd(animation: Animator) { if (!cancelled) onEnd() }
            })
            start()
        }
    }

    private fun startCarousel() {
        if (carouselAnim?.isRunning == true) return
        carouselAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = cycleMs
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                val t = it.animatedValue as Float
                val s = if (t < holdFrac) 0f else {
                    val u = ((t - holdFrac) / (1f - holdFrac)).coerceIn(0f, 1f)
                    1f - (1f - u) * (1f - u) * (1f - u)   // easeOutCubic
                }
                if (s != slide) { slide = s; invalidate() }
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationRepeat(animation: Animator) {
                    idx = (idx + 1) % chords.size
                    slide = 0f
                }
            })
            start()
        }
    }

    override fun onDetachedFromWindow() {
        expandAnim?.cancel()
        carouselAnim?.cancel()
        super.onDetachedFromWindow()
    }

    // ---- Bentuk ---------------------------------------------------------------------

    /**
     * Badan hitam: sisi atas rata, dua sudut bawah membulat, "telinga" cekung di kiri-kanan.
     * Koordinat lokal: x sepanjang tepi, y = kedalaman dari tepi. Lebar total = totalW.
     */
    private fun buildShape(totalW: Float, h: Float, r: Float, e: Float) {
        val w = totalW
        path.reset()
        path.moveTo(0f, 0f)
        path.lineTo(w, 0f)
        path.arcTo(RectF(w - e, 0f, w + e, 2 * e), 270f, -90f)              // telinga kanan
        path.lineTo(w - e, h - r)
        path.arcTo(RectF(w - e - 2 * r, h - 2 * r, w - e, h), 0f, 90f)      // sudut kanan bawah
        path.lineTo(e + r, h)
        path.arcTo(RectF(e, h - 2 * r, e + 2 * r, h), 90f, 90f)             // sudut kiri bawah
        path.lineTo(e, e)
        path.arcTo(RectF(-e, 0f, e, 2 * e), 0f, -90f)                       // telinga kiri
        path.close()
    }

    // ---- Gambar ---------------------------------------------------------------------

    override fun onDraw(canvas: Canvas) {
        if (side == Side.TOP) drawTop(canvas) else drawSide(canvas)
    }

    private fun drawTop(canvas: Canvas) {
        val vw = width.toFloat()

        val wDp = lerp(startW, fullW, p).coerceIn(0f, fullW + 10f)
        val hDp = lerp(startH, fullH, p).coerceAtLeast(0f)
        val ePx = dp(lerp(startE, fullE, p).coerceAtLeast(0f))
        val bodyW = dp(wDp)
        val bodyH = dp(hDp)
        val rPx = dp(lerp(startR, fullR, p).coerceAtLeast(0f)).coerceAtMost(minOf(bodyH, bodyW) / 2f)

        val totalW = bodyW + 2 * ePx
        buildShape(totalW, bodyH, rPx, ePx)
        path.offset((vw - totalW) / 2f, 0f)
        canvas.drawPath(path, bodyPaint)

        val a = ((p - 0.5f) / 0.4f).coerceIn(0f, 1f)
        if (a <= 0f) return

        canvas.save()
        canvas.clipPath(path)
        // turun 8dp supaya tidak tertutup kamera punch-hole di tengah atas
        drawCarousel(canvas, vw / 2f, dp(fullH) / 2f + dp(8f), true, 92f, 140f, a)
        canvas.restore()
    }

    private fun drawSide(canvas: Canvas) {
        val vw = width.toFloat()
        val vh = height.toFloat()
        val left = side == Side.LEFT

        val depthDp = lerp(sStartD, sFullD, p).coerceIn(0f, sFullD + 8f)
        val lenDp = lerp(sStartL, sFullL, p).coerceIn(0f, sFullL + 10f)
        val ePx = dp(lerp(sStartE, sFullE, p).coerceAtLeast(0f))
        val depth = dp(depthDp)
        val len = dp(lenDp)
        val rPx = dp(lerp(sStartR, sFullR, p).coerceAtLeast(0f)).coerceAtMost(minOf(depth, len) / 2f)

        val totalLen = len + 2 * ePx
        val startAlong = (vh - totalLen) / 2f

        buildShape(totalLen, depth, rPx, ePx)
        // Lokal (x sepanjang tepi, y kedalaman) -> layar. Bentuk simetris, jadi transpose = rotasi.
        if (left) {
            edgeMatrix.setValues(floatArrayOf(0f, 1f, 0f, 1f, 0f, startAlong, 0f, 0f, 1f))
        } else {
            edgeMatrix.setValues(floatArrayOf(0f, -1f, vw, 1f, 0f, startAlong, 0f, 0f, 1f))
        }
        path.transform(edgeMatrix)
        canvas.drawPath(path, bodyPaint)

        val a = ((p - 0.5f) / 0.4f).coerceIn(0f, 1f)
        if (a <= 0f) return

        canvas.save()
        canvas.clipPath(path)
        val boxW = dp(sFullD)
        // geser 12dp menjauhi tepi layar (kamera ada di tepi ini)
        val shift = dp(12f) * (if (left) 1f else -1f)
        val cx = (if (left) 0f else vw - boxW) + boxW / 2f + shift
        drawCarousel(canvas, cx, vh / 2f, false, 84f, 125f, a)
        canvas.restore()
    }

    /**
     * Tiga akor sekaligus: tengah (skala 1, terang), dua tetangga (skala 0,72, redup 40%).
     * [slide] menggeser semuanya satu langkah; akor yang keluar memudar, yang masuk muncul dari tepi.
     * [horizontal] true = sejajar kiri-kanan (portrait), false = atas-bawah (landscape samping).
     */
    private fun drawCarousel(
        canvas: Canvas, cx: Float, cy: Float, horizontal: Boolean,
        gap1: Float, gap2: Float, openAlpha: Float
    ) {
        val n = chords.size
        val items = ArrayList<FloatArray>(4)   // [j, r]
        for (j in -1..2) {
            val r = j - slide
            if (abs(r) < 2f) items.add(floatArrayOf(j.toFloat(), r))
        }
        items.sortByDescending { abs(it[1]) }   // yang paling jauh digambar dulu, tengah paling akhir

        for (item in items) {
            val j = item[0].toInt()
            val r = item[1]
            val ar = abs(r)
            val off = (if (ar <= 1f) ar * gap1 else gap1 + (ar - 1f) * (gap2 - gap1)) * (if (r < 0) -1f else 1f)
            val k = if (ar <= 1f) lerp(1f, 0.72f, ar) else lerp(0.72f, 0.6f, ar - 1f)
            val al = (if (ar <= 1f) lerp(1f, 0.4f, ar) else lerp(0.4f, 0f, ar - 1f)) * openAlpha

            val i = ((idx + j) % n + n) % n
            val x = if (horizontal) cx + dp(off) else cx
            val y = if (horizontal) cy else cy + dp(off)
            glyph.draw(canvas, chords[i], shapes[i], x, y, k, al)
        }
    }
}
