package com.cfwan.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.abs

/** Sisi layar tempat island menempel. TOP = portrait, LEFT/RIGHT = landscape (sisi kamera). */
enum class Side { TOP, LEFT, RIGHT }

/**
 * Island CfWan: tiga akor gitar. Akor tengah besar, kiri-kanan lebih kecil dan redup,
 * lalu bergantian bergeser (demo dulu, belum terhubung ke deteksi akor).
 * Bisa dikontrol manual: ketuk sisi kiri = akor sebelumnya, sisi kanan = akor selanjutnya
 * (atau geser). Setelah disentuh, geser otomatis berhenti sebentar lalu lanjut lagi.
 * TOP: melebar horizontal di tepi atas. LEFT/RIGHT: berdiri di sisi layar saat landscape,
 * akor tersusun vertikal dan isinya tetap tegak terbaca.
 */
class IslandView(context: Context) : View(context) {

    var side: Side = Side.TOP
        set(value) {
            if (field != value) {
                field = value
                requestLayout()
                invalidate()
            }
        }

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    // ---- Ukuran mode TOP (dp) ----
    private val fullW = 310f
    private val fullH = 60f
    private val fullR = 19f
    private val fullE = 13f
    private val startW = 120f
    private val startH = 28f
    private val startR = 12f
    private val startE = 8f

    // ---- Ukuran mode samping (dp): D = kedalaman dari tepi layar, L = panjang sepanjang tepi ----
    private val sFullD = 88f
    private val sFullL = 150f
    private val sFullR = 22f
    private val sFullE = 14f
    private val sStartD = 28f
    private val sStartL = 100f
    private val sStartR = 12f
    private val sStartE = 8f

    // ---- Carousel akor ----
    private val chords = listOf("C", "G", "Am", "F", "Dm", "E7", "A", "Em", "D", "Bm")
    private val shapes = chords.map { GuitarChords.pick(it) }
    private val glyph = ChordGlyphPainter(d)
    private var idx = 0          // akor yang sedang di tengah
    private var slide = 0f       // -1..1: progres bergeser (positif = ke akor berikutnya, negatif = ke sebelumnya)
    private val autoMs = 2400L     // jeda geser otomatis
    private val resumeMs = 6000L   // jeda geser otomatis setelah disentuh manual
    private var autoOn = false
    private var stepAnim: ValueAnimator? = null
    private val autoRunnable = object : Runnable {
        override fun run() {
            step(1)
            postDelayed(this, autoMs)
        }
    }

    // ---- Sentuhan ----
    private val bodyBounds = RectF()
    private val leftArrowBounds = RectF()
    private val rightArrowBounds = RectF()
    private var downX = 0f
    private var downY = 0f
    private var downInside = false
    private var downArrowDirection = 0

    // ---- Warna gradasi (diatur dari aplikasi) ----
    private val prefs = context.getSharedPreferences(IslandService.PREFS, Context.MODE_PRIVATE)
    private var glowOn = true
    private var glowColors = IslandGlow.colors(IslandGlow.DEF_HUE, IslandGlow.DEF_SPREAD)
    private var glowIntensity = 1f
    private var shRadiusDp = IslandGlow.shadowRadiusDp(IslandGlow.DEF_SH_THICK)
    private var shIntensity = IslandGlow.DEF_SH_INT

    init { reloadColors() }

    /** Baca ulang pengaturan warna dari preferensi (dipanggil saat user mengubah warna di aplikasi). */
    fun reloadColors() {
        glowOn = prefs.getBoolean(IslandService.KEY_GLOW, true)
        glowColors = IslandGlow.colors(
            prefs.getInt(IslandService.KEY_HUE, IslandGlow.DEF_HUE).coerceIn(0, 360),
            prefs.getInt(IslandService.KEY_SPREAD, IslandGlow.DEF_SPREAD).coerceIn(0, IslandGlow.MAX_SPREAD)
        )
        glowIntensity = prefs.getInt(IslandService.KEY_GLOW_INT, IslandGlow.DEF_GLOW_INT).coerceIn(0, 100) / 100f
        shRadiusDp = IslandGlow.shadowRadiusDp(prefs.getInt(IslandService.KEY_SH_THICK, IslandGlow.DEF_SH_THICK))
        shIntensity = prefs.getInt(IslandService.KEY_SH_INT, IslandGlow.DEF_SH_INT).coerceIn(0, 100)
        invalidate()
    }

    private var p = 0f           // progres buka-tutup (boleh >1 karena overshoot)
    private var expandAnim: ValueAnimator? = null

    private val path = Path()
    private val edgeMatrix = Matrix()
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val arrowBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val arrowLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = dp(2.4f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (side == Side.TOP) {
            setMeasuredDimension(
                dp(fullW + 2 * fullE + 32f).toInt(),
                dp(fullH + 22f).toInt()
            )
        } else {
            setMeasuredDimension(
                dp(sFullD + 24f).toInt(),
                dp(sFullL + 2 * sFullE + 32f).toInt()
            )
        }
    }

    // ---- Animasi -------------------------------------------------------------------

    fun show() {
        expandAnim?.cancel()
        expandAnim = ValueAnimator.ofFloat(p, 1f).apply {
            duration = 620
            interpolator = OvershootInterpolator(1.1f)
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
            start()
        }
        startCarousel()
    }

    fun hide(onEnd: () -> Unit) {
        expandAnim?.cancel()
        expandAnim = ValueAnimator.ofFloat(p, 0f).apply {
            duration = 380
            interpolator = AccelerateInterpolator(1.4f)
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) { cancelled = true }
                override fun onAnimationEnd(animation: Animator) { if (!cancelled) onEnd() }
            })
            start()
        }
    }

    private fun startCarousel() {
        if (autoOn) return
        autoOn = true
        postDelayed(autoRunnable, autoMs)
    }

    /** Geser carousel satu akor: [dir] = 1 maju (akor selanjutnya), -1 mundur (akor sebelumnya). */
    fun step(dir: Int) {
        stepAnim?.end()   // selesaikan geseran sebelumnya dulu supaya ketukan beruntun tidak hilang
        stepAnim = ValueAnimator.ofFloat(0f, dir.toFloat()).apply {
            duration = 320
            interpolator = DecelerateInterpolator(2f)
            addUpdateListener { slide = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    idx = ((idx + dir) % chords.size + chords.size) % chords.size
                    slide = 0f
                    invalidate()
                }
            })
            start()
        }
    }

    /** Geser manual dari sentuhan; geser otomatis ditunda dulu. */
    private fun manualStep(dir: Int) {
        step(dir)
        if (autoOn) {
            removeCallbacks(autoRunnable)
            postDelayed(autoRunnable, resumeMs)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downArrowDirection = when {
                    p > 0.5f && side == Side.TOP && leftArrowBounds.contains(e.x, e.y) -> -1
                    p > 0.5f && side == Side.TOP && rightArrowBounds.contains(e.x, e.y) -> 1
                    else -> 0
                }
                downInside = downArrowDirection != 0 ||
                    (p > 0.5f && bodyBounds.contains(e.x, e.y))
                downX = e.x
                downY = e.y
                return downInside
            }
            MotionEvent.ACTION_UP -> {
                if (!downInside) return false
                downInside = false
                val arrowDirection = downArrowDirection
                downArrowDirection = 0
                if (arrowDirection != 0) {
                    val arrowBounds = if (arrowDirection < 0) leftArrowBounds else rightArrowBounds
                    if (arrowBounds.contains(e.x, e.y)) manualStep(arrowDirection)
                    return true
                }
                val horizontal = side == Side.TOP
                val moved = if (horizontal) e.x - downX else e.y - downY
                val dir = if (abs(moved) > dp(24f)) {
                    if (moved < 0) 1 else -1                       // geser ke kiri/atas = maju
                } else {
                    val frac = if (horizontal) (e.x - bodyBounds.left) / bodyBounds.width()
                               else (e.y - bodyBounds.top) / bodyBounds.height()
                    if (frac < 0.5f) -1 else 1                      // ketuk kiri/atas = mundur, kanan/bawah = maju
                }
                manualStep(dir)
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                val was = downInside
                downInside = false
                downArrowDirection = 0
                return was
            }
        }
        return downInside
    }

    override fun onDetachedFromWindow() {
        expandAnim?.cancel()
        removeCallbacks(autoRunnable)
        autoOn = false
        stepAnim?.cancel()
        super.onDetachedFromWindow()
    }

    // ---- Bentuk ---------------------------------------------------------------------

    /**
     * Badan hitam: sisi atas rata, dua sudut bawah membulat, "telinga" cekung di kiri-kanan.
     * Koordinat lokal: x sepanjang tepi, y = kedalaman dari tepi. Lebar total = totalW.
     */
    private fun buildShape(totalW: Float, h: Float, r: Float, e: Float) {
        val w = totalW
        path.reset()
        path.moveTo(0f, 0f)
        path.lineTo(w, 0f)
        path.arcTo(RectF(w - e, 0f, w + e, 2 * e), 270f, -90f)              // telinga kanan
        path.lineTo(w - e, h - r)
        path.arcTo(RectF(w - e - 2 * r, h - 2 * r, w - e, h), 0f, 90f)      // sudut kanan bawah
        path.lineTo(e + r, h)
        path.arcTo(RectF(e, h - 2 * r, e + 2 * r, h), 90f, 90f)             // sudut kiri bawah
        path.lineTo(e, e)
        path.arcTo(RectF(-e, 0f, e, 2 * e), 0f, -90f)                       // telinga kiri
        path.close()
    }

    // ---- Gambar ---------------------------------------------------------------------

    override fun onDraw(canvas: Canvas) {
        if (side == Side.TOP) drawTop(canvas) else drawSide(canvas)
    }

    private fun drawTop(canvas: Canvas) {
        val vw = width.toFloat()

        val wDp = lerp(startW, fullW, p).coerceIn(0f, fullW + 10f)
        val hDp = lerp(startH, fullH, p).coerceAtLeast(0f)
        val ePx = dp(lerp(startE, fullE, p).coerceAtLeast(0f))
        val bodyW = dp(wDp)
        val bodyH = dp(hDp)
        val rPx = dp(lerp(startR, fullR, p).coerceAtLeast(0f)).coerceAtMost(minOf(bodyH, bodyW) / 2f)

        val totalW = bodyW + 2 * ePx
        buildShape(totalW, bodyH, rPx, ePx)
        path.offset((vw - totalW) / 2f, 0f)
        path.computeBounds(bodyBounds, true)
        IslandGlow.drawShadow(canvas, path, 0f, dp(shRadiusDp * 0.4f), d, p, shRadiusDp, shIntensity)
        canvas.drawPath(path, bodyPaint)

        val a = ((p - 0.5f) / 0.4f).coerceIn(0f, 1f)
        if (a <= 0f) return

        canvas.save()
        canvas.clipPath(path)
        if (glowOn) {
            IslandGlow.draw(canvas, bodyBounds.left, bodyBounds.top, bodyBounds.width(), bodyBounds.height(), glowColors, a * glowIntensity)
        }
        val arrowY = bodyBounds.centerY()
        val arrowOffset = dp(fullE + 22f)
        val arrowHitRadius = dp(14f)
        val leftArrowX = bodyBounds.left + arrowOffset
        val rightArrowX = bodyBounds.right - arrowOffset
        leftArrowBounds.set(
            leftArrowX - arrowHitRadius, arrowY - arrowHitRadius,
            leftArrowX + arrowHitRadius, arrowY + arrowHitRadius
        )
        rightArrowBounds.set(
            rightArrowX - arrowHitRadius, arrowY - arrowHitRadius,
            rightArrowX + arrowHitRadius, arrowY + arrowHitRadius
        )

        drawCarousel(canvas, vw / 2f, dp(fullH) / 2f, true, 76f, 140f, a)
        drawArrow(canvas, leftArrowX, arrowY, true, a)
        drawArrow(canvas, rightArrowX, arrowY, false, a)
        canvas.restore()
    }

    private fun drawSide(canvas: Canvas) {
        leftArrowBounds.setEmpty()
        rightArrowBounds.setEmpty()
        val vw = width.toFloat()
        val vh = height.toFloat()
        val left = side == Side.LEFT

        val depthDp = lerp(sStartD, sFullD, p).coerceIn(0f, sFullD + 8f)
        val lenDp = lerp(sStartL, sFullL, p).coerceIn(0f, sFullL + 10f)
        val ePx = dp(lerp(sStartE, sFullE, p).coerceAtLeast(0f))
        val depth = dp(depthDp)
        val len = dp(lenDp)
        val rPx = dp(lerp(sStartR, sFullR, p).coerceAtLeast(0f)).coerceAtMost(minOf(depth, len) / 2f)

        val totalLen = len + 2 * ePx
        val startAlong = (vh - totalLen) / 2f

        buildShape(totalLen, depth, rPx, ePx)
        // Lokal (x sepanjang tepi, y kedalaman) -> layar. Bentuk simetris, jadi transpose = rotasi.
        if (left) {
            edgeMatrix.setValues(floatArrayOf(0f, 1f, 0f, 1f, 0f, startAlong, 0f, 0f, 1f))
        } else {
            edgeMatrix.setValues(floatArrayOf(0f, -1f, vw, 1f, 0f, startAlong, 0f, 0f, 1f))
        }
        path.transform(edgeMatrix)
        path.computeBounds(bodyBounds, true)
        IslandGlow.drawShadow(canvas, path, dp(shRadiusDp * 0.4f) * (if (left) 1f else -1f), 0f, d, p, shRadiusDp, shIntensity)
        canvas.drawPath(path, bodyPaint)

        val a = ((p - 0.5f) / 0.4f).coerceIn(0f, 1f)
        if (a <= 0f) return

        canvas.save()
        canvas.clipPath(path)
        if (glowOn) {
            // Gradasi digambar di koordinat lokal (x sepanjang tepi, y = kedalaman) supaya "bawah" = sisi jauh dari tepi layar
            canvas.save()
            canvas.concat(edgeMatrix)
            IslandGlow.draw(canvas, 0f, 0f, totalLen, depth, glowColors, a * glowIntensity)
            canvas.restore()
        }
        val boxW = dp(sFullD)
        // geser 6dp menjauhi tepi layar (kamera ada di tepi ini)
        val shift = dp(6f) * (if (left) 1f else -1f)
        val cx = (if (left) 0f else vw - boxW) + boxW / 2f + shift
        drawCarousel(canvas, cx, vh / 2f, false, 52f, 80f, a)
        canvas.restore()
    }

    /** Panah bulat kecil mengikuti ikon Focus Timer pada HTML. */
    private fun drawArrow(canvas: Canvas, cx: Float, cy: Float, left: Boolean, alpha: Float) {
        if (alpha <= 0f) return

        arrowBgPaint.alpha = (72f * alpha).toInt().coerceIn(0, 255)
        arrowLinePaint.alpha = (255f * alpha).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, dp(11f), arrowBgPaint)

        val scale = dp(0.9f)
        val outerX = if (left) 6.5f else 3.5f
        val innerX = if (left) 3f else 7f
        val topY = 1.5f
        val midY = 5f
        val bottomY = 8.5f
        canvas.drawLine(
            cx + (outerX - 5f) * scale, cy + (topY - 5f) * scale,
            cx + (innerX - 5f) * scale, cy + (midY - 5f) * scale,
            arrowLinePaint
        )
        canvas.drawLine(
            cx + (innerX - 5f) * scale, cy + (midY - 5f) * scale,
            cx + (outerX - 5f) * scale, cy + (bottomY - 5f) * scale,
            arrowLinePaint
        )
    }

    /**
     * Tiga akor sekaligus: tengah (skala 1, terang), dua tetangga (skala 0,72, redup 40%).
     * [slide] (-1..1) menggeser semuanya satu langkah maju/mundur; akor yang keluar memudar, yang masuk muncul dari tepi.
     * [horizontal] true = sejajar kiri-kanan (portrait), false = atas-bawah (landscape samping).
     */
    private fun drawCarousel(
        canvas: Canvas, cx: Float, cy: Float, horizontal: Boolean,
        gap1: Float, gap2: Float, openAlpha: Float
    ) {
        val n = chords.size
        val items = ArrayList<FloatArray>(4)   // [j, r]
        for (j in -2..2) {
            val r = j - slide
            if (abs(r) < 2f) items.add(floatArrayOf(j.toFloat(), r))
        }
        items.sortByDescending { abs(it[1]) }   // yang paling jauh digambar dulu, tengah paling akhir

        for (item in items) {
            val j = item[0].toInt()
            val r = item[1]
            val ar = abs(r)
            val off = (if (ar <= 1f) ar * gap1 else gap1 + (ar - 1f) * (gap2 - gap1)) * (if (r < 0) -1f else 1f)
            val k = if (ar <= 1f) lerp(1f, 0.72f, ar) else lerp(0.72f, 0.6f, ar - 1f)
            val al = (if (ar <= 1f) lerp(1f, 0.4f, ar) else lerp(0.4f, 0f, ar - 1f)) * openAlpha

            val i = ((idx + j) % n + n) % n
            val x = if (horizontal) cx + dp(off) else cx
            val y = if (horizontal) cy else cy + dp(off)
            glyph.draw(canvas, chords[i], shapes[i], x, y, k, al)
        }
    }
}
