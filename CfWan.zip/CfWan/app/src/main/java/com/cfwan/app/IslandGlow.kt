package com.cfwan.app

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Gradasi warna di bagian bawah island (sama dengan kapsul Lyrics di HTML) + shadow.
 *
 * HTML:  .ambient { background: linear-gradient(90deg, g1, g2 50%, g3); height: 82%; opacity: .95;
 *                   mask: linear-gradient(to top, #000, rgba(0,0,0,.55) 30%, rgba(0,0,0,.12) 70%, transparent) }
 *        g1 = hsl(hue-spread 61% 45%), g2 = hsl(hue 61% 53%), g3 = hsl(hue+spread 60% 41%)
 */
internal object IslandGlow {
    const val DEF_HUE = 214      // sama dengan nilai awal slider "Capsule color" di HTML
    const val DEF_SPREAD = 0     // sama dengan nilai awal slider "Gradient spread" di HTML
    const val MAX_SPREAD = 90

    private const val GLOW_HEIGHT = 0.82f
    private const val GLOW_OPACITY = 0.95f

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val maskPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.FILL_AND_STROKE
        strokeJoin = Paint.Join.ROUND
    }

    private val maskColors = intArrayOf(
        Color.argb(255, 0, 0, 0), Color.argb(140, 0, 0, 0), Color.argb(31, 0, 0, 0), Color.argb(0, 0, 0, 0)
    )
    private val maskStops = floatArrayOf(0f, 0.30f, 0.70f, 1f)
    private val colorStops = floatArrayOf(0f, 0.5f, 1f)

    fun hsl(h: Float, s: Float, l: Float): Int {
        val hh = ((h % 360f) + 360f) % 360f
        val c = (1f - abs(2f * l - 1f)) * s
        val hp = hh / 60f
        val x = c * (1f - abs(hp % 2f - 1f))
        val m = l - c / 2f
        val (r, g, b) = when (hp.toInt()) {
            0 -> Triple(c, x, 0f)
            1 -> Triple(x, c, 0f)
            2 -> Triple(0f, c, x)
            3 -> Triple(0f, x, c)
            4 -> Triple(x, 0f, c)
            else -> Triple(c, 0f, x)
        }
        return Color.rgb(((r + m) * 255f).roundToInt(), ((g + m) * 255f).roundToInt(), ((b + m) * 255f).roundToInt())
    }

    /** [g1, g2, g3] dari hue (0..360) dan spread (0..90), rumus sama dengan paint() di HTML. */
    fun colors(hue: Int, spread: Int): IntArray = intArrayOf(
        hsl((hue - spread).toFloat(), 0.61f, 0.45f),
        hsl(hue.toFloat(), 0.61f, 0.53f),
        hsl((hue + spread).toFloat(), 0.60f, 0.41f)
    )

    /**
     * Gambar gradasi di kotak (left, top, w, h). "Bawah" = sisi bawah kotak pada koordinat kanvas saat ini.
     * Panggil di dalam clip bentuk island. [alpha] 0..1 untuk fade saat island membuka.
     */
    fun draw(canvas: Canvas, left: Float, top: Float, w: Float, h: Float, colors: IntArray, alpha: Float) {
        if (alpha <= 0f || w <= 0f || h <= 0f) return
        val gh = h * GLOW_HEIGHT
        val gTop = top + h - gh
        val right = left + w
        val bottom = top + h

        val layer = canvas.saveLayer(left, gTop, right, bottom, null)
        fillPaint.shader = LinearGradient(left, 0f, right, 0f, colors, colorStops, Shader.TileMode.CLAMP)
        fillPaint.alpha = (255f * GLOW_OPACITY * alpha.coerceIn(0f, 1f)).toInt()
        canvas.drawRect(left, gTop, right, bottom, fillPaint)

        maskPaint.shader = LinearGradient(0f, bottom, 0f, gTop, maskColors, maskStops, Shader.TileMode.CLAMP)
        canvas.drawRect(left, gTop, right, bottom, maskPaint)
        canvas.restoreToCount(layer)
        fillPaint.shader = null
        maskPaint.shader = null
    }

    /**
     * Shadow lembut di belakang badan island (tanpa BlurMaskFilter, jadi aman di hardware canvas):
     * beberapa lapis bentuk yang makin melebar dan tipis. [dx],[dy] = geser menjauhi tepi layar.
     */
    fun drawShadow(canvas: Canvas, path: Path, dx: Float, dy: Float, density: Float, alpha: Float) {
        if (alpha <= 0f) return
        val layers = 8
        canvas.save()
        canvas.translate(dx, dy)
        for (i in layers downTo 1) {
            shadowPaint.strokeWidth = 2f * i * 1.1f * density
            shadowPaint.alpha = (255f * 0.085f * alpha.coerceIn(0f, 1f)).toInt()
            canvas.drawPath(path, shadowPaint)
        }
        canvas.restore()
    }
}
