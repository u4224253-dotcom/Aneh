# Chord Finder Island (native Android)

Port bertahap dari `chord-finder-island-mockup.html` ke Kotlin + Jetpack Compose.

Status: **Mode 1 — Upload** (island 420 x 96). Mode berikutnya: Analisis, Selesai, Preview, Akor.

Build: push ke GitHub (branch `main`), buka tab Actions > Build APK. APK debug ada di Artifacts.
Taruh isi folder ini di root repo (folder `.github/` harus di root).
