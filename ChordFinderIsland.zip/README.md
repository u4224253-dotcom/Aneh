# Chord Finder Island (native Android)

Port bertahap dari `chord-finder-island-mockup.html` ke Kotlin + Jetpack Compose.

Status: **Mode 1 — Upload / Analisis / Selesai** dan **Mode 2 — Preview** (island 420 x 96) sudah selesai. Mode berikutnya: Akor.

Pindah mode: panah kiri/kanan di island, atau geser ke samping di island.
Preview: sampul, judul + info file, mundur/maju 10 dtk, play/pause, waktu, progres (ketuk atau geser untuk melompat), equalizer.

Build: push ke GitHub (branch `main`), buka tab Actions > Build APK. APK debug ada di Artifacts.
Taruh isi folder ini di root repo (folder `.github/` harus di root).
