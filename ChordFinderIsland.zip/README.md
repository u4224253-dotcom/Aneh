# Chord Finder Island (native Android)

Port bertahap dari `chord-finder-island-mockup.html` ke Kotlin + Jetpack Compose.

Status: **Mode 1 — Upload / Analisis / Selesai** dan **Mode 2 — Preview** (island 420 x 96) sudah selesai. Mode berikutnya: Akor.

Pindah mode: panah kiri/kanan di island, atau geser ke samping di island.
Preview: sampul, judul + info file, mundur/maju 10 dtk, play/pause, waktu, progres (ketuk atau geser untuk melompat), equalizer.

Build: push ke GitHub (branch `main`), buka tab Actions > Build APK. APK debug ada di Artifacts.
Taruh isi folder ini di root repo (folder `.github/` harus di root).

## Island di luar aplikasi (overlay)

Tombol **Bawa island keluar** (di bawah island) memindahkan island ke jendela overlay yang dijalankan service foreground
(`IslandService`). Island menempel di tepi atas layar dan tetap ada walau aplikasi ditutup atau di-swipe dari recent.

- Pertama kali: izinkan **Tampil di atas aplikasi lain**, lalu kembali ke aplikasi (island otomatis muncul).
- Menutup: tombol **Tutup island di luar app** atau aksi **Tutup island** di notifikasi.
- Dari overlay, "pilih file" membuka `PickerActivity` (tembus pandang) lalu kembali ke app yang sedang dibuka.
- Island di dalam app dan island overlay punya state sendiri-sendiri; saat overlay dinyalakan, island di dalam app disembunyikan dan di-reset.
