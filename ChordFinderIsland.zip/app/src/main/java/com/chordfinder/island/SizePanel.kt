package com.chordfinder.island

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

/** Panel kustom ukuran island di halaman aplikasi (desain flat: warna solid, garis tipis). */
@Composable
fun SizePanel(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val shape = RoundedCornerShape(16.dp)
    val sp15 = with(LocalDensity.current) { 15.dp.toSp() }
    Column(
        modifier
            .clip(shape)
            .background(Color(0x6105060C))
            .border(1.dp, Color.White.copy(alpha = .22f), shape)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            BasicText(
                "Tampilan island",
                modifier = Modifier.weight(1f),
                style = TextStyle(color = Color.White, fontSize = sp15, fontWeight = FontWeight.SemiBold),
            )
            BasicText(
                "Atur ulang",
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null, role = Role.Button,
                    ) { IslandSettings.reset(ctx) }
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                style = TextStyle(color = Color.White.copy(alpha = .75f), fontSize = with(LocalDensity.current) { 13.dp.toSp() }),
            )
        }
        SizeRow("Ukuran", IslandSettings.scale, IslandSettings.MIN, IslandSettings.MAX, { IslandSettings.scale = it; IslandSettings.changed() }) { IslandSettings.save(ctx) }
        SizeRow("Intensitas cahaya", IslandSettings.intensity, IslandSettings.MIN_I, IslandSettings.MAX_I, { IslandSettings.intensity = it; IslandSettings.changed() }) { IslandSettings.save(ctx) }
        BasicText(
            "Berlaku di semua mode kecuali Resting.",
            style = TextStyle(color = Color.White.copy(alpha = .55f), fontSize = with(LocalDensity.current) { 12.dp.toSp() }),
        )
    }
}

@Composable
private fun SizeRow(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit, onDone: () -> Unit) {
    val fs = with(LocalDensity.current) { 13.dp.toSp() }
    Column {
        Row(Modifier.fillMaxWidth()) {
            BasicText(label, Modifier.weight(1f), style = TextStyle(color = Color.White.copy(alpha = .85f), fontSize = fs))
            BasicText("${(value * 100f).roundToInt()}%", style = TextStyle(color = Color.White, fontSize = fs, fontWeight = FontWeight.SemiBold))
        }
        FlatSlider(value, min, max, onChange, onDone)
    }
}

/** Slider flat: jalur tipis, isian putih solid, bulatan putih. Sentuh atau geser di mana saja pada jalur. */
@Composable
private fun FlatSlider(value: Float, min: Float, max: Float, onChange: (Float) -> Unit, onDone: () -> Unit) {
    var w by remember { mutableFloatStateOf(1f) }
    val dens = LocalDensity.current.density
    val r = 9f * dens
    Box(
        Modifier
            .fillMaxWidth()
            .height(30.dp)
            .onSizeChanged { w = it.width.toFloat() }
            .pointerInput(min, max) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    fun at(x: Float) = onChange(min + (max - min) * ((x - r) / (w - 2f * r).coerceAtLeast(1f)).coerceIn(0f, 1f))
                    at(down.position.x)
                    down.consume()
                    do {
                        val ev = awaitPointerEvent()
                        val c = ev.changes.firstOrNull { it.id == down.id }
                        if (c != null) { at(c.position.x); c.consume() }
                    } while (ev.changes.any { it.pressed })
                    onDone()
                }
            },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val frac = ((value - min) / (max - min)).coerceIn(0f, 1f)
            val cy = size.height / 2f
            val x = r + frac * (size.width - 2f * r)
            val tw = 3f * dens
            drawLine(Color.White.copy(alpha = .25f), Offset(r, cy), Offset(size.width - r, cy), tw, StrokeCap.Round)
            drawLine(Color.White, Offset(r, cy), Offset(x, cy), tw, StrokeCap.Round)
            drawCircle(Color.White, r, Offset(x, cy))
        }
    }
}
