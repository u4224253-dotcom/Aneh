package com.chordfinder.island;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.ViewTreeLifecycleOwner;
import androidx.lifecycle.ViewTreeViewModelStoreOwner;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.SavedStateRegistryController;
import androidx.savedstate.SavedStateRegistryOwner;
import androidx.savedstate.ViewTreeSavedStateRegistryOwner;

/**
 * Compose butuh LifecycleOwner, ViewModelStoreOwner, dan SavedStateRegistryOwner di pohon view.
 * Di Activity semuanya sudah ada; di Service (jendela overlay) kita sediakan sendiri.
 * Ditulis dengan Java supaya cocok dengan semua versi AndroidX (getter, bukan properti Kotlin).
 */
public final class OverlayOwner implements LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private final LifecycleRegistry lifecycleRegistry = new LifecycleRegistry(this);
    private final ViewModelStore store = new ViewModelStore();
    private final SavedStateRegistryController controller = SavedStateRegistryController.create(this);

    @NonNull
    @Override
    public Lifecycle getLifecycle() {
        return lifecycleRegistry;
    }

    @NonNull
    @Override
    public ViewModelStore getViewModelStore() {
        return store;
    }

    @NonNull
    @Override
    public SavedStateRegistry getSavedStateRegistry() {
        return controller.getSavedStateRegistry();
    }

    /** Panggil sekali sebelum view dipasang ke WindowManager. */
    public void create() {
        controller.performAttach();
        controller.performRestore(null);
        lifecycleRegistry.setCurrentState(Lifecycle.State.CREATED);
    }

    public void resume() {
        lifecycleRegistry.setCurrentState(Lifecycle.State.RESUMED);
    }

    public void destroy() {
        lifecycleRegistry.setCurrentState(Lifecycle.State.DESTROYED);
        store.clear();
    }

    /** Pasang pemilik ini di view akar (ComposeView) jendela overlay. */
    public void attachTo(@NonNull View view) {
        ViewTreeLifecycleOwner.set(view, this);
        ViewTreeViewModelStoreOwner.set(view, this);
        ViewTreeSavedStateRegistryOwner.set(view, this);
    }
}
