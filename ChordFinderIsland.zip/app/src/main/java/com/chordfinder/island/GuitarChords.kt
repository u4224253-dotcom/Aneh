package com.chordfinder.island

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface

/*
 * Akor gitar diambil dari LayKit (ChordCard.kt): objek GuitarChords dan bentuk diagramnya.
 * Satu bentuk per akor: akor terbuka bila ada, kalau tidak bentuk E, kalau tidak bentuk A.
 */

// Bentuk akor gitar (satu bentuk per akor: terbuka bila ada, kalau tidak bentuk E, kalau tidak bentuk A)
// ---------------------------------------------------------------------------------------------

/** [frets]: 6 senar (E A D G B e), nilai relatif terhadap [baseFret]; -1 = tidak dimainkan, 0 = senar terbuka. */
internal class ChordShape(val frets: IntArray, val baseFret: Int, val barre: Int)

internal object GuitarChords {
    private const val X = -1

    private class Q(val e: IntArray?, val a: IntArray)

    // Offset fret dari posisi barre. Kunci = akhiran seperti yang dihasilkan chordName().
    private val QUAL: Map<String, Q> = mapOf(
        "" to Q(intArrayOf(0, 2, 2, 1, 0, 0), intArrayOf(X, 0, 2, 2, 2, 0)),
        "m" to Q(intArrayOf(0, 2, 2, 0, 0, 0), intArrayOf(X, 0, 2, 2, 1, 0)),
        "7" to Q(intArrayOf(0, 2, 0, 1, 0, 0), intArrayOf(X, 0, 2, 0, 2, 0)),
        "maj7" to Q(intArrayOf(0, 2, 1, 1, 0, 0), intArrayOf(X, 0, 2, 1, 2, 0)),
        "m7" to Q(intArrayOf(0, 2, 0, 0, 0, 0), intArrayOf(X, 0, 2, 0, 1, 0)),
        "sus4" to Q(intArrayOf(0, 2, 2, 2, 0, 0), intArrayOf(X, 0, 2, 2, 3, 0)),
        "7sus4" to Q(intArrayOf(0, 2, 0, 2, 0, 0), intArrayOf(X, 0, 2, 0, 3, 0)),
        "sus2" to Q(null, intArrayOf(X, 0, 2, 2, 0, 0)),
        "6" to Q(intArrayOf(0, 2, 2, 1, 2, 0), intArrayOf(X, 0, 2, 2, 2, 2)),
        "m6" to Q(intArrayOf(0, 2, 2, 0, 2, 0), intArrayOf(X, 0, 2, 2, 1, 2)),
        "mM7" to Q(intArrayOf(0, 2, 1, 0, 0, 0), intArrayOf(X, 0, 2, 1, 1, 0)),
        "dim" to Q(null, intArrayOf(X, 0, 1, 2, 1, X)),
        "dim7" to Q(null, intArrayOf(X, 0, 1, 2, 1, 2)),
        "aug" to Q(null, intArrayOf(X, 0, 3, 2, 2, 1)),
        "m7\u266D5" to Q(null, intArrayOf(X, 0, 1, 0, 1, X)),
    )

    // Akor terbuka: "indeksNada|akhiran" -> fret absolut
    private val OPEN: Map<String, IntArray> = mapOf(
        "0|" to intArrayOf(X, 3, 2, 0, 1, 0), "0|7" to intArrayOf(X, 3, 2, 3, 1, 0), "0|maj7" to intArrayOf(X, 3, 2, 0, 0, 0),
        "2|" to intArrayOf(X, X, 0, 2, 3, 2), "2|m" to intArrayOf(X, X, 0, 2, 3, 1),
        "2|7" to intArrayOf(X, X, 0, 2, 1, 2), "2|maj7" to intArrayOf(X, X, 0, 2, 2, 2),
        "7|" to intArrayOf(3, 2, 0, 0, 0, 3), "7|7" to intArrayOf(3, 2, 0, 0, 0, 1), "7|maj7" to intArrayOf(3, 2, 0, 0, 0, 2),
    )

    // Akor ekstensi yang tidak punya bentuk sendiri memakai bentuk yang paling dekat (nama di island tetap nama aslinya).
    private val SIMPLER = mapOf("9" to "7", "11" to "7", "13" to "7", "m9" to "m7", "maj9" to "maj7")

    private val BASE = mapOf('C' to 0, 'D' to 2, 'E' to 4, 'F' to 5, 'G' to 7, 'A' to 9, 'B' to 11)

    private fun build(frets: IntArray, b: Int): ChordShape {
        val pos = frets.filter { it > 0 }
        val m = pos.minOrNull() ?: 1
        val base = if ((pos.maxOrNull() ?: 0) <= 4) 1 else m
        val rel = IntArray(6) { val v = frets[it]; if (v > 0) v - base + 1 else v }
        return ChordShape(rel, base, if (b > 0) b - base + 1 else 0)
    }

    private fun shape(tpl: IntArray, b: Int) = build(IntArray(6) { if (tpl[it] == X) X else tpl[it] + b }, b)

    /** Nama seperti "A", "Am", "D♭maj7", "F#m7" (penulisan "Amaj"/"Amin" juga diterima); null untuk "–" atau nama yang tidak dikenal. */
    fun pick(name: String): ChordShape? {
        if (name.isEmpty()) return null
        var root = BASE[name[0]] ?: return null
        var i = 1
        if (i < name.length) {
            when (name[i]) {
                '#' -> { root += 1; i++ }
                '\u266D', 'b' -> { root -= 1; i++ }
            }
        }
        root = (root + 12) % 12
        var suffix = name.substring(i).substringBefore('/')   // "Am/G" -> bentuk Am
        if (suffix == "maj") suffix = ""
        // penulisan minor di island: "min", "min7", "minmaj7" ... -> kunci bentuk: "m", "m7", "mM7"
        if (suffix == "minmaj7") suffix = "mM7" else if (suffix.startsWith("min")) suffix = "m" + suffix.substring(3)
        suffix = SIMPLER[suffix] ?: suffix
        val q = QUAL[suffix] ?: return null
        OPEN["$root|$suffix"]?.let { return build(it, 0) }
        return if (q.e != null) shape(q.e, (root - 4 + 12) % 12) else shape(q.a, (root - 9 + 12) % 12)
    }
}

/**
 * Menggambar diagram akor gitar (kisi, pelana, barre, tanda x / o, titik jari) dengan nama akor
 * di sebelah kanannya, langsung ke Canvas. Port dari ChordDiagramView LayKit, koordinat diagram 58 x 68.
 * Ukuran disesuaikan agar muat di island 60dp: diagram tengah setinggi ~50dp.
 * [k] = faktor skala (1 = ukuran tengah), [alpha] = 0..1. Diagram + nama dipusatkan di (cx, cy).
 */
internal class ChordGlyphPainter(var d: Float) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val names = arrayOf("E", "A", "D", "G", "B", "E")
    private val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.LEFT
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    fun draw(cv: Canvas, name: String, sh: ChordShape?, cx: Float, cy: Float, k: Float, alpha: Float) {
        if (alpha <= 0f) return
        val color = Color.argb((255 * alpha).toInt().coerceIn(0, 255), 255, 255, 255)
        val sc = d * 1.08f * k            // 1 unit diagram = 1,08dp -> tinggi 68 unit = ~73dp (island 96dp)
        val gap = d * 7f * k

        namePaint.color = color
        namePaint.textSize = d * 20f * k
        var textW = namePaint.measureText(name)
        val maxW = d * 50f * k                       // nama lebih lebar dari ini dikecilkan (min. 8dp)
        if (textW > maxW) {
            namePaint.textSize = maxOf(d * 20f * k * maxW / textW, d * 8f * k)
            textW = namePaint.measureText(name)
        }
        val diagW = if (sh != null) 58f * sc else 0f
        val total = diagW + (if (sh != null) gap else 0f) + textW
        val left = cx - total / 2f
        val top = cy - 34f * sc

        if (sh != null) {
            val s = 7f; val f = 12f; val w = 35f; val h = 48f
            fun rowY(r: Int) = (r - 1) * f + f / 2f

            cv.save()
            cv.translate(left, top)
            cv.scale(sc, sc)
            cv.translate(14f, 13f)

            p.color = color
            p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
            p.style = Paint.Style.STROKE
            p.strokeWidth = 0.6f
            for (i in 1..3) cv.drawLine(0f, i * f, w, i * f, p)
            for (i in 1..4) cv.drawLine(i * s, 0f, i * s, h, p)
            cv.drawRoundRect(0f, 0f, w, h, 3f, 3f, p)

            if (sh.baseFret == 1) {
                p.strokeWidth = 1.8f
                cv.drawLine(3f, 0f, w - 3f, 0f, p)
            } else {
                p.style = Paint.Style.FILL; p.textSize = 4f; p.textAlign = Paint.Align.LEFT
                cv.drawText("${sh.baseFret}fr", -12f, 8f, p)
            }

            p.style = Paint.Style.FILL; p.textSize = 4.8f; p.textAlign = Paint.Align.CENTER
            for (i in 0..5) cv.drawText(names[i], i * s, 53f, p)

            if (sh.barre > 0) {
                val idx = (0..5).filter { sh.frets[it] == sh.barre }
                if (idx.size > 1) {
                    val a = idx.first(); val z = idx.last(); val y = rowY(sh.barre)
                    cv.drawRoundRect(a * s - 3.4f, y - 3.4f, z * s + 3.4f, y + 3.4f, 3.4f, 3.4f, p)
                }
            }

            for (i in 0..5) {
                val x = i * s
                val fr = sh.frets[i]
                when {
                    fr == -1 -> {
                        p.style = Paint.Style.STROKE; p.strokeWidth = 1.1f
                        cv.drawLine(x - 2.2f, -7.4f, x + 2.2f, -3f, p)
                        cv.drawLine(x + 2.2f, -7.4f, x - 2.2f, -3f, p)
                    }
                    fr == 0 -> {
                        p.style = Paint.Style.STROKE; p.strokeWidth = 1f
                        cv.drawCircle(x, -5.2f, 2.2f, p)
                    }
                    else -> {
                        p.style = Paint.Style.FILL
                        cv.drawCircle(x, rowY(fr), 3.4f, p)
                    }
                }
            }
            cv.restore()
        }

        val fm = namePaint.fontMetrics
        val nameX = left + diagW + (if (sh != null) gap else 0f)
        cv.drawText(name, nameX, cy - (fm.ascent + fm.descent) / 2f, namePaint)
    }
}
