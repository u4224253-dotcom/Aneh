package com.chordfinder.island

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Fase mode 1: Upload, Analisis, Selesai (sama dengan data-s up / an / done di HTML). */
enum class Phase { UP, AN, DONE }

/** Lama animasi analisis (AN.T di HTML). */
const val ANALYZE_SECONDS = 7.5f

private val STAGES = listOf(
    0f to "Membaca audio…",
    .2f to "Memisahkan nada…",
    .52f to "Mendeteksi akor…",
    .9f to "Merapikan hasil…",
)

fun stageOf(p: Float): String = STAGES.last { p >= it.first }.second

/** Sama seperti fmt() di HTML: detik menjadi mm:ss. */
fun fmtTime(sec: Float): String {
    val s = max(0, sec.roundToInt())
    return (s / 60).toString().padStart(2, '0') + ":" + (s % 60).toString().padStart(2, '0')
}

/**
 * Alur mode 1 (port dari accept / analyze / finish / reset di HTML):
 * file diterima, cahaya naik + tegukan, tunggu 750 ms, analisis 7,5 detik (kurva ease), lalu selesai.
 */
class AnalyzeFlow(private val scope: CoroutineScope, private val glow: GlowController) {
    var phase by mutableStateOf(Phase.UP); private set
    var progress by mutableFloatStateOf(0f); private set
    var name by mutableStateOf("audio"); private set
    private var job: Job? = null

    fun accept(info: PickedAudio) {
        name = info.name
        glow.drop()
        job?.cancel()
        job = scope.launch { delay(750); analyze() }
    }

    fun again() {
        job?.cancel()
        job = scope.launch { analyze() }
    }

    fun reset() {
        job?.cancel(); job = null
        glow.reset()
        phase = Phase.UP
    }

    private suspend fun analyze() {
        phase = Phase.AN; progress = 0f
        glow.waterStart()
        val t0 = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val q = min(1f, (now - t0) / 1_000_000_000f / ANALYZE_SECONDS)
            val p = (-(cos(PI * q) - 1.0) / 2.0).toFloat()   // ease sinus
            progress = p
            glow.waterLevel(p)
            if (q >= 1f) break
        }
        delay(380)
        glow.waterStop()
        phase = Phase.DONE
    }
}
