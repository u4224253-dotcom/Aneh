package com.chordfinder.island

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.scale
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

/** Garis tepi island terbuka: dari ujung telinga kiri atas, turun, lewat bawah, naik ke ujung telinga kanan atas (tanpa garis atas). */
private fun edgeLine(left: Float, w: Float, h: Float, e: Float, r: Float): Path {
    val bl = left; val br = left + w
    return Path().apply {
        moveTo(bl - e, 0f)
        arcTo(Rect(bl - 2f * e, 0f, bl, 2f * e), -90f, 90f, false)
        lineTo(bl, h - r)
        arcTo(Rect(bl, h - 2f * r, bl + 2f * r, h), 180f, -90f, false)
        lineTo(br - r, h)
        arcTo(Rect(br - 2f * r, h - 2f * r, br, h), 90f, -90f, false)
        lineTo(br, e)
        arcTo(Rect(br, 0f, br + 2f * e, 2f * e), 180f, 90f, false)
    }
}

private val C_CYAN = intArrayOf(25, 184, 255)
private val C_INDIGO = intArrayOf(45, 91, 255)
private val C_VIOLET = intArrayOf(123, 75, 255)

private fun cometColor(t: Float, a: Float): Color {
    val x = t.coerceIn(0f, 1f)
    val (p, q, k) = if (x < .5f) Triple(C_CYAN, C_INDIGO, x * 2f) else Triple(C_INDIGO, C_VIOLET, (x - .5f) * 2f)
    return rgba(
        (p[0] + (q[0] - p[0]) * k).toInt(), (p[1] + (q[1] - p[1]) * k).toInt(), (p[2] + (q[2] - p[2]) * k).toInt(),
        a,
    )
}

/**
 * Hiasan tepi island (semua mode): komet warna maskot tipis yang sesekali lewat menyusuri tepi,
 * muncul lalu hilang di waktu acak, arah acak, ujung (kepala) dan ekor meruncing tajam.
 * Dipakai di Layer(bleed = true) supaya ikut sampai ke lengkungan atas.
 * [w] = lebar island yang sedang tampil (Tok.W atau Tok.W2 tergantung mode), supaya komet menyusuri
 * siluet yang benar saat island sedang menciut/melebar mengikuti isi mode.
 */
@Composable
fun AmbientEdge(w: Float = Tok.W) {
    val line = remember(w) { edgeLine(Tok.E, w, Tok.H, Tok.E, Tok.R) }
    val sil = remember(w) { islandPath(Tok.E, w, Tok.H, Tok.E, Tok.R) }
    val measure = remember(w) { PathMeasure().also { it.setPath(line, false) } }
    val total = remember(w) { measure.length }

    val prog = remember { Animatable(0f) }
    var dir by remember { mutableFloatStateOf(1f) }
    var len by remember { mutableFloatStateOf(120f) }
    var amp by remember { mutableFloatStateOf(1f) }

    LaunchedEffect(Unit) {
        delay(Random.nextLong(1200, 3500))
        while (true) {
            dir = if (Random.nextBoolean()) 1f else -1f
            len = 90f + Random.nextFloat() * 90f
            amp = .6f + Random.nextFloat() * .4f
            prog.snapTo(0f)
            prog.animateTo(1f, tween(Random.nextInt(1500, 2600), easing = Tok.EaseInOut))
            delay(Random.nextLong(1800, 7000))   // jeda acak sebelum muncul lagi
        }
    }

    Canvas(Modifier.fillMaxSize()) {
        val p = prog.value
        val k = 1f   // dulu ikut IslandSettings.intensity; sekarang slider itu dipakai utk opasitas card utama, bukan efek ini
        if (p <= 0f || p >= 1f || k <= .01f) return@Canvas
        val head = p * (total + len)       // posisi kepala di sepanjang garis (boleh melewati ujung)
        val n = 36
        scale(density, density, Offset.Zero) {
            clipPath(sil) {
                // ambient light tipis: cahaya lembut di dalam island yang ikut berjalan bersama komet
                val env = sin(PI.toFloat() * p)                       // pelan muncul, pelan hilang
                val dc = (head - len * .35f).coerceIn(0f, total)
                val sc = if (dir > 0f) dc else total - dc
                val c = measure.getPosition(sc)
                val r = 62f
                drawCircle(
                    brush = androidx.compose.ui.graphics.Brush.radialGradient(
                        0f to cometColor(.75f, .20f * amp * env * k),
                        .5f to cometColor(.6f, .07f * amp * env * k),
                        1f to cometColor(.5f, 0f),
                        center = c, radius = r,
                    ),
                    radius = r, center = c,
                )
                for (i in 0 until n) {
                    val t0 = i / n.toFloat(); val t1 = (i + 1) / n.toFloat()
                    val d0 = head - len + t0 * len; val d1 = head - len + t1 * len
                    if (d1 < 0f || d0 > total) continue
                    val a0 = d0.coerceIn(0f, total); val a1 = d1.coerceIn(0f, total)
                    val s0 = if (dir > 0f) a0 else total - a0
                    val s1 = if (dir > 0f) a1 else total - a1
                    val tm = (t0 + t1) / 2f
                    // lebar: runcing di kepala dan ekor, tebal sedikit ke arah kepala (garis dalam 0..1,6 dp)
                    val taper = sin(PI.toFloat() * tm.pow(1.5f)).coerceAtLeast(0f)
                    val width = 3.2f * taper
                    if (width < .05f) continue
                    drawLine(
                        cometColor(tm, amp * k * taper.pow(.6f)),
                        measure.getPosition(s0), measure.getPosition(s1),
                        strokeWidth = width, cap = StrokeCap.Round,
                    )
                }
            }
        }
    }
}
