package com.chordfinder.island

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Seluruh state satu island: cahaya, alur analisis, pemutar, halaman (mode) yang tampil.
 * Dipakai dua tempat: layar aplikasi (MainActivity) dan jendela overlay (IslandService).
 */
class IslandState(private val ctx: Context, private val scope: CoroutineScope) {
    val glow = GlowController()
    val flow = AnalyzeFlow(scope, glow)
    val player = PlayerController(ctx)

    /** Mode yang tampil: 1 = Upload/Analisis/Selesai, 2 = Preview, 3 = Akor. */
    var page by mutableIntStateOf(1)
    var hover by mutableStateOf(false)

    /**
     * Mode Resting: island menciut jadi pil kecil bermata. Defaultnya aktif saat island muncul.
     * [page] dan fase analisis tidak disentuh, jadi [wake] otomatis kembali ke mode terakhir.
     */
    var resting by mutableStateOf(true)
    var msg by mutableStateOf(MSG_DEFAULT)

    fun go(n: Int) { page = n.coerceIn(1, 3) }

    /** Ketuk area kosong di mode mana pun: masuk mode Resting. */
    fun rest() { hover = false; glow.hot(false); resting = true }

    /**
     * Hook khusus overlay: dipanggil sebelum keluar dari Resting. Hook harus membesarkan jendela dulu,
     * lalu memanggil `go` setelah jendela siap, supaya animasi membuka tidak terpotong jendela yang masih kecil.
     */
    var beforeWake: ((go: () -> Unit) -> Unit)? = null

    /** Ketuk island Resting: buka lagi mode yang tadi (pertama kali = mode Upload). */
    fun wake() {
        val hook = beforeWake
        if (hook == null) resting = false else hook { resting = false }
    }

    /** reset() di HTML: batalkan analisis, hentikan pemutar, kembali ke mode Upload. */
    fun resetAll() { flow.reset(); player.clear(); page = 1 }

    fun notAudio() {
        scope.launch { msg = MSG_BAD; delay(1800); msg = MSG_DEFAULT }
    }

    /** Terima file; false kalau bukan audio. */
    fun accept(uri: Uri): Boolean {
        val info = readAudio(ctx, uri) ?: return false
        player.load(info)
        flow.accept(info)
        return true
    }

    fun release() { player.release() }
}

/** Jembatan untuk PickerActivity (dibuka dari overlay) supaya file yang dipilih sampai ke island overlay. */
object IslandBridge {
    @Volatile var state: IslandState? = null
}
