package com.chordfinder.island

import android.graphics.BlurMaskFilter
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas

/**
 * Mode Resting (.l-pet di HTML): island menciut jadi pil 150 x 30 dp, ada cahaya gradien
 * (--glow: cyan, indigo 55%, violet) yang naik dari bawah, dan sepasang mata putih yang berkedip.
 * Dipakai di tengah cangkang yang sedang berubah ukuran, jadi semua ukuran mengikuti ruang yang ada.
 */
private val GLOW_CYAN = Color(0xFF19B8FF)
private val GLOW_INDIGO = Color(0xFF2D5BFF)
private val GLOW_VIOLET = Color(0xFF7B4BFF)

private const val EYE_W = 8.4f
private const val EYE_H = 12.4f
private const val EYE_GAP = 15f

/** box-shadow CSS (blur) ke radius BlurMaskFilter: sigma = blur / 2, radius = (sigma - .5) / .57735. */
private fun cssBlur(blurPx: Float): Float = ((blurPx / 2f - .5f) / .57735f).coerceAtLeast(.1f)

@Composable
fun RestingMode() {
    // blink 4.2 dtk: 0-92% terbuka, 95% hampir menutup (scaleY .1), 100% terbuka lagi
    val blink by rememberInfiniteTransition(label = "blink").animateFloat(
        initialValue = 1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 4200
                1f at 0 using LinearEasing
                1f at 3864 using LinearEasing
                .1f at 3990 using LinearEasing
                1f at 4200 using LinearEasing
            },
            repeatMode = RepeatMode.Restart,
        ),
        label = "blinkV",
    )

    Canvas(Modifier.fillMaxSize().graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }) {
        drawAmbient()
        drawEyes(blink)
    }
}

/** .ambient: tinggi 90 persen dari bawah, gradien --glow, di-mask memudar ke atas. */
private fun DrawScope.drawAmbient() {
    val h = size.height * .9f
    val top = size.height - h
    val area = Size(size.width, h)
    drawRect(
        brush = Brush.horizontalGradient(
            0f to GLOW_CYAN, .55f to GLOW_INDIGO, 1f to GLOW_VIOLET,
            startX = 0f, endX = size.width,
        ),
        topLeft = Offset(0f, top), size = area,
    )
    // mask: to top, #000 0%, .55 30%, .12 70%, transparan 100%  ->  dari atas: 0, .12, .55, 1
    drawRect(
        brush = Brush.verticalGradient(
            0f to Color.Black.copy(alpha = 0f),
            .30f to Color.Black.copy(alpha = .12f),
            .70f to Color.Black.copy(alpha = .55f),
            1f to Color.Black,
            startY = top, endY = size.height,
        ),
        topLeft = Offset(0f, top), size = area,
        blendMode = BlendMode.DstIn,
    )
}

/** Dua mata oval putih 8.4 x 12.4, jarak 15, di tengah; ada cahaya biru (dua lapis box-shadow). */
private fun DrawScope.drawEyes(blink: Float) {
    val d = density
    val ew = EYE_W * d
    val eh = EYE_H * d * blink            // kedip = scaleY dari tengah mata
    val gap = EYE_GAP * d
    val cy = size.height / 2f
    val left = size.width / 2f - gap / 2f - ew
    val right = size.width / 2f + gap / 2f

    drawIntoCanvas { c ->
        val n = c.nativeCanvas
        fun glow(x: Float, spread: Float, blurCss: Float, color: Int) {
            val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                this.color = color
                maskFilter = BlurMaskFilter(cssBlur(blurCss * d), BlurMaskFilter.Blur.NORMAL)
            }
            val s = spread * d
            n.drawOval(x - s, cy - eh / 2f - s, x + ew + s, cy + eh / 2f + s, p)
        }
        for (x in floatArrayOf(left, right)) {
            glow(x, 4f, 14f, android.graphics.Color.argb(71, 80, 140, 255))    // 0 0 14px 4px rgba(80,140,255,.28)
            glow(x, 1f, 6f, android.graphics.Color.argb(153, 120, 190, 255))   // 0 0 6px 1px rgba(120,190,255,.6)
        }
    }
    drawOval(Color.White, topLeft = Offset(left, cy - eh / 2f), size = Size(ew, eh))
    drawOval(Color.White, topLeft = Offset(right, cy - eh / 2f), size = Size(ew, eh))
}
