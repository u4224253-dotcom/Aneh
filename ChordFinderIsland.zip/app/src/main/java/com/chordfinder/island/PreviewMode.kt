package com.chordfinder.island

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.SystemClock
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

const val PL_NAME_EMPTY = "Belum ada audio"
const val PL_SUB_EMPTY = "Upload dulu di mode Upload"
const val PL_SUB_ERROR = "Format ini tidak bisa diputar di perangkat ini"

/** Setelah seek, abaikan pembacaan posisi sebentar supaya progres tidak melompat balik. */
private const val SEEK_QUIET_MS = 400L

/**
 * Pemutar mode 2 (port dari objek P + loadFile / togglePlay / seek / stopPlayer di HTML).
 * Memakai MediaPlayer bawaan Android supaya tidak perlu dependensi tambahan.
 */
class PlayerController(private val ctx: Context) {
    var loaded by mutableStateOf(false); private set
    var name by mutableStateOf(PL_NAME_EMPTY); private set
    var sub by mutableStateOf(PL_SUB_EMPTY); private set
    var t by mutableFloatStateOf(0f); private set
    var dur by mutableFloatStateOf(0f); private set
    var playing by mutableStateOf(false); private set

    private var mp: MediaPlayer? = null
    private var ready = false
    private var lastSeek = 0L

    /** Sama dengan loadFile(): judul, "EXT · x.x MB", lalu siapkan audio. */
    fun load(info: PickedAudio) {
        release()
        loaded = true
        name = info.name
        val ext = info.name.substringAfterLast('.').uppercase(Locale.ROOT).take(5).ifEmpty { "AUDIO" }
        sub = ext + " · " + String.format(Locale.US, "%.1f", info.size / 1048576.0) + " MB"

        val m = MediaPlayer()
        mp = m
        m.setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .build(),
        )
        m.setOnPreparedListener { p ->
            if (mp === p) { dur = maxOf(0, p.duration) / 1000f; ready = true }
        }
        m.setOnCompletionListener { p ->
            if (mp === p) { playing = false; t = 0f; runCatching { p.seekTo(0) } }
        }
        m.setOnErrorListener { p, _, _ ->
            if (mp === p) { playing = false; ready = false; sub = PL_SUB_ERROR }
            true
        }
        runCatching {
            m.setDataSource(ctx, info.uri)
            m.prepareAsync()
        }.onFailure { sub = PL_SUB_ERROR }
    }

    fun toggle() {
        val m = mp ?: return
        if (!ready) return
        if (dur > 0f && t >= dur - .1f) seek(0f)
        if (playing) {
            runCatching { m.pause() }
            playing = false
        } else {
            playing = runCatching { m.start() }.isSuccess
        }
    }

    fun seek(sec: Float) {
        val m = mp ?: return
        if (!ready) return
        t = shCl(sec, 0f, dur)
        lastSeek = SystemClock.uptimeMillis()
        runCatching { m.seekTo((t * 1000f).toLong(), MediaPlayer.SEEK_CLOSEST) }
    }

    /** Dipanggil tiap 250 ms (setInterval di HTML). */
    fun tick() {
        val m = mp ?: return
        if (!ready) return
        if (SystemClock.uptimeMillis() - lastSeek < SEEK_QUIET_MS) return
        runCatching { t = m.currentPosition / 1000f }
    }

    fun pause() {
        if (!playing) return
        runCatching { mp?.pause() }
        playing = false
    }

    /** reset() di HTML: hentikan dan kembalikan teks bawaan. */
    fun clear() {
        release()
        loaded = false
        name = PL_NAME_EMPTY
        sub = PL_SUB_EMPTY
    }

    fun release() {
        val m = mp
        mp = null
        ready = false
        playing = false
        t = 0f
        dur = 0f
        if (m != null) runCatching { m.release() }
    }
}

// ---- Ikon (viewBox 24 x 24, dari mock-up) -----------------------------------------------------

private fun iconPath(d: String): Path = PathParser().parsePathString(d).toPath()

private val ICO_BACK = iconPath("M11 6 3 12l8 6zM21 6l-8 6 8 6z")
private val ICO_FWD = iconPath("m13 6 8 6-8 6zM3 6l8 6-8 6z")
private val ICO_PLAY = iconPath("M7 4.5v15l12-7.5z")
private val ICO_PAUSE = iconPath("M7 5h4v14H7zM13 5h4v14h-4z")

private val PL_DIM = Color.White.copy(alpha = .5f)

// ---- Gradien ala CSS ----------------------------------------------------------------------------

/** linear-gradient(<sudut>deg, ...) di kotak w x h: sudut 0 = ke atas, searah jarum jam. */
private fun cssLinear(angleDeg: Float, w: Float, h: Float, vararg stops: Pair<Float, Color>): Brush {
    val a = Math.toRadians(angleDeg.toDouble())
    val dx = sin(a).toFloat()
    val dy = (-cos(a)).toFloat()
    val len = (abs(w * sin(a)) + abs(h * cos(a))).toFloat()
    val cx = w / 2f
    val cy = h / 2f
    return Brush.linearGradient(
        *stops,
        start = Offset(cx - dx * len / 2f, cy - dy * len / 2f),
        end = Offset(cx + dx * len / 2f, cy + dy * len / 2f),
    )
}

/** .art: sampul 44 x 44 di (44, 8), radius 10: garis diagonal, cakram biru, cincin, garis datar, dasar terang. */
@Composable
private fun CoverArt() {
    Canvas(Modifier.offset(44.dp, 8.dp).size(44.dp).clip(RoundedCornerShape(10.dp))) {
        val d = density
        scale(d, d, Offset.Zero) {
            val s = 44f
            val full = Size(s, s)

            // dasar: linear-gradient(160deg, #eef5ff, #cfe2fb)
            drawRect(cssLinear(160f, s, s, 0f to Color(0xFFEEF5FF), 1f to Color(0xFFCFE2FB)), size = full)

            // repeating-linear-gradient(0deg, rgba(46,127,224,.18) 0 2px, transparent 2px 7px): mulai dari bawah
            val stripe = Color(46, 127, 224).copy(alpha = .18f)
            var k = 0
            while (7f * k < s) {
                drawRect(stripe, topLeft = Offset(0f, s - 7f * k - 2f), size = Size(s, 2f))
                k++
            }

            // radial-gradient(circle at 34% 58%, ...): jari-jari = sudut terjauh (farthest-corner)
            val cx = .34f * s
            val cy = .58f * s
            val rad = maxOf(hypot(cx, cy), hypot(s - cx, cy), hypot(cx, s - cy), hypot(s - cx, s - cy))
            val center = Offset(cx, cy)

            val ringC = Color(0xFF5AA6F2)
            val ring0 = ringC.copy(alpha = 0f)
            drawRect(
                Brush.radialGradient(
                    0f to ring0, .30f to ring0, .31f to ringC, .33f to ringC, .34f to ring0, 1f to ring0,
                    center = center, radius = rad,
                ),
                size = full,
            )

            val disc = Color(0xFF2E7FE0)
            val disc0 = disc.copy(alpha = 0f)
            drawRect(
                Brush.radialGradient(
                    0f to disc, .22f to disc, .23f to disc0, 1f to disc0,
                    center = center, radius = rad,
                ),
                size = full,
            )

            // linear-gradient(115deg, transparent 0 46%, rgba(255,255,255,.75) 46% 48%, transparent 48%)
            val w0 = Color.White.copy(alpha = 0f)
            val w1 = Color.White.copy(alpha = .75f)
            drawRect(
                cssLinear(115f, s, s, 0f to w0, .46f to w0, .46f to w1, .48f to w1, .48f to w0, 1f to w0),
                size = full,
            )
        }
    }
}

/** .bars: 5 batang equalizer 2.2 x 14 dp di (362, 30). Jalan hanya saat memutar; saat jeda membeku (play-state paused). */
@Composable
private fun EqBars(playing: Boolean) {
    var clock by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(playing) {
        if (!playing) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            clock += (now - last) / 1_000_000_000f
            last = now
        }
    }
    Canvas(Modifier.placeAt(362f, 30f).size(19.dp, 14.dp)) {
        val d = density
        val delays = floatArrayOf(0f, .3f, .6f, .15f, .45f)   // animation-delay negatif tiap batang
        for (i in 0 until 5) {
            val ph = ((clock + delays[i]) % 1.8f) / .9f        // .9 dtk per arah, alternate
            val u = if (ph <= 1f) ph else 2f - ph
            val h = (.3f + .7f * Tok.EaseInOut.transform(u)) * 14f * d
            drawRoundRect(
                Color.White,
                topLeft = Offset(i * 4.2f * d, (14f * d - h) / 2f),
                size = Size(2.2f * d, h),
                cornerRadius = CornerRadius(1.1f * d),
            )
        }
    }
}

/** .cbtn: tombol 26 dp, ikon 15 dp putih; saat ditekan mengecil .88 (pegas .2 dtk). */
@Composable
private fun CtlButton(cx: Float, cy: Float, icon: Path, desc: String, enabled: Boolean, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) .88f else 1f, tween(200, easing = Tok.Spring), label = "cb")
    Box(
        Modifier
            .placeAt(cx, cy)
            .size(26.dp)
            .graphicsLayer { alpha = if (enabled) 1f else .35f }
            .semantics { contentDescription = desc }
            .clickable(interactionSource = src, indication = null, enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(15.dp).graphicsLayer { scaleX = sc; scaleY = sc }) {
            val k = size.width / 24f
            scale(k, k, Offset.Zero) { drawPath(icon, Color.White) }
        }
    }
}

/** .prog: 152 x 4 dp di (174, 68), jalur putih 22 persen, isian putih (di-clip bulat seperti overflow hidden). */
@Composable
private fun PlayBar(player: PlayerController, enabled: Boolean) {
    Canvas(
        Modifier
            .placeAt(174f, 68f, 0f, .5f)
            .size(152.dp, 4.dp)
            .graphicsLayer { alpha = if (enabled) 1f else .35f },
    ) {
        val rad = CornerRadius(size.height / 2f)
        drawRoundRect(Color.White.copy(alpha = .22f), cornerRadius = rad)
        val frac = if (player.dur > 0f) shCl(player.t / player.dur) else 0f
        if (frac > 0f) {
            val track = Path().apply {
                addRoundRect(RoundRect(0f, 0f, size.width, size.height, rad))
            }
            clipPath(track) {
                drawRect(Color.White, size = Size(size.width * frac, size.height))
            }
        }
    }
}

/** MODE 2 — Preview audio (420 x 96): sampul + judul di baris atas; kontrol, waktu, dan progres di baris bawah. */
@Composable
fun PreviewMode(player: PlayerController) {
    val loaded = player.loaded

    // tiap 250 ms baca posisi (setInterval 250 di HTML)
    LaunchedEffect(player) {
        while (true) {
            player.tick()
            delay(250)
        }
    }

    // .ambient: cahaya biru dari bawah, menyala (.95) saat ada audio, transisi .6 dtk
    val amb by animateFloatAsState(if (loaded) .95f else 0f, tween(600, easing = Tok.Ease), label = "amb")
    val ambH = Tok.H * .82f
    Canvas(
        Modifier
            .offset(0.dp, (Tok.H - ambH).dp)
            .size(Tok.W.dp, ambH.dp)
            .graphicsLayer { alpha = amb; compositingStrategy = CompositingStrategy.Offscreen },
    ) {
        drawRect(
            Brush.horizontalGradient(
                0f to Color(0xFF2C64B8), .5f to Color(0xFF3A7AD0), 1f to Color(0xFF2A5AA8),
                startX = 0f, endX = size.width,
            ),
        )
        // mask: linear-gradient(to top, #000, rgba(0,0,0,.55) 30%, rgba(0,0,0,.12) 70%, transparent)
        drawRect(
            Brush.verticalGradient(
                0f to Color.Black.copy(alpha = 0f), .30f to Color.Black.copy(alpha = .12f),
                .70f to Color.Black.copy(alpha = .55f), 1f to Color.Black,
                startY = 0f, endY = size.height,
            ),
            blendMode = BlendMode.DstIn,
        )
    }

    CoverArt()
    CText(player.name, 100f, 22f, 14f, weight = FontWeight.SemiBold, ax = 0f, maxW = 244f)
    CText(player.sub, 100f, 39f, 11f, color = PL_DIM, ax = 0f, maxW = 244f)
    EqBars(player.playing)

    CtlButton(57f, 68f, ICO_BACK, "Mundur 10 detik", loaded) { player.seek(player.t - 10f) }
    CtlButton(
        83f, 68f, if (player.playing) ICO_PAUSE else ICO_PLAY,
        if (player.playing) "Jeda" else "Putar", loaded,
    ) { player.toggle() }
    CtlButton(109f, 68f, ICO_FWD, "Maju 10 detik", loaded) { player.seek(player.t + 10f) }

    CText(fmtTime(player.t), 130f, 68f, 12f, ax = 0f)
    PlayBar(player, loaded)
    CText("-" + fmtTime(player.dur - player.t), Tok.W - 44f, 68f, 12f, ax = 1f)

    // .seek: area sentuh 152 x 22 di (174, 57): ketuk atau geser untuk melompat
    Box(
        Modifier
            .offset(174.dp, 57.dp)
            .size(152.dp, 22.dp)
            .pointerInput(loaded) {
                if (!loaded) return@pointerInput
                awaitEachGesture {
                    val down = awaitFirstDown()
                    down.consume()   // supaya tidak dianggap geser pindah mode
                    val w = size.width.toFloat()
                    player.seek(shCl(down.position.x / w) * player.dur)
                    drag(down.id) { change ->
                        change.consume()
                        player.seek(shCl(change.position.x / w) * player.dur)
                    }
                }
            },
    )
}
