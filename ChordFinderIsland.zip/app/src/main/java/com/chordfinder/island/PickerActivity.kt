package com.chordfinder.island

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/**
 * Activity tembus pandang untuk memilih file audio dari island overlay
 * (service tidak bisa membuka pemilih file sendiri). Selesai langsung setelah memilih.
 */
class PickerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                runCatching {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val st = IslandBridge.state
                if (st != null && !st.accept(uri)) st.notAudio()
            }
            finish()
        }
        if (savedInstanceState == null) picker.launch(arrayOf("audio/*", "application/octet-stream"))
    }
}
