package com.chordfinder.island

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue

/**
 * Pengaturan ukuran island (hanya mengecilkan, 50..100 persen), dipakai island di dalam aplikasi dan island overlay.
 * Berlaku di semua mode kecuali Resting. Disimpan di SharedPreferences; keduanya satu proses, jadi state langsung dibagi.
 */
object IslandSettings {
    const val MIN = .5f
    const val MAX = 1f

    /** Ukuran keseluruhan (lebar dan tinggi sekaligus). */
    var scale by mutableFloatStateOf(1f)
    /** Lebar saja. */
    var width by mutableFloatStateOf(1f)
    /** Tinggi saja. */
    var height by mutableFloatStateOf(1f)

    /** Dipanggil tiap nilai berubah (service overlay memakainya untuk mengukur ulang jendela). */
    @Volatile var onChange: (() -> Unit)? = null

    private var loaded = false
    private const val PREFS = "island_size"

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        scale = p.getFloat("scale", 1f).coerceIn(MIN, MAX)
        width = p.getFloat("width", 1f).coerceIn(MIN, MAX)
        height = p.getFloat("height", 1f).coerceIn(MIN, MAX)
    }

    fun changed() { onChange?.invoke() }

    fun save(ctx: Context) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat("scale", scale).putFloat("width", width).putFloat("height", height).apply()
    }

    fun reset(ctx: Context) {
        scale = 1f; width = 1f; height = 1f
        changed(); save(ctx)
    }
}
