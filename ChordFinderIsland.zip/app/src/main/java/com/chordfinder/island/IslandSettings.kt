package com.chordfinder.island

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue

/**
 * Pengaturan tampilan island, dipakai island di dalam aplikasi dan island overlay. Berlaku di semua mode kecuali Resting.
 * Disimpan di SharedPreferences; keduanya satu proses, jadi state langsung dibagi.
 */
object IslandSettings {
    /** Ukuran keseluruhan, hanya mengecilkan (50..100 persen). */
    const val MIN = .5f
    const val MAX = 1f
    /** Opasitas card utama (badan + telinga hitam island), berlaku di semua mode termasuk Resting: 0..150 persen.
     *  Nilai di atas 100 persen dikunci di hitam pekat (alpha 1), karena hitam tidak bisa lebih pekat lagi. */
    const val MIN_I = 0f
    const val MAX_I = 1.5f

    var scale by mutableFloatStateOf(1f)
    var intensity by mutableFloatStateOf(1f)

    /** Dipanggil tiap nilai berubah (service overlay memakainya untuk mengukur ulang jendela). */
    @Volatile var onChange: (() -> Unit)? = null

    private var loaded = false
    private const val PREFS = "island_size"

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        scale = p.getFloat("scale", 1f).coerceIn(MIN, MAX)
        intensity = p.getFloat("intensity", 1f).coerceIn(MIN_I, MAX_I)
    }

    fun changed() { onChange?.invoke() }

    fun save(ctx: Context) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat("scale", scale).putFloat("intensity", intensity).apply()
    }

    fun reset(ctx: Context) {
        scale = 1f; intensity = 1f
        changed(); save(ctx)
    }
}
