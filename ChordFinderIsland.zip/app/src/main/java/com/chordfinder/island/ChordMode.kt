package com.chordfinder.island

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.pow

// Carousel akor (hasil analisis, demo) — sama seperti CfWan: daftar akor, tengah besar, dua tetangga lebih kecil dan redup.
private val CHORDS = listOf("C", "G", "Am", "F", "Dm", "E7", "A", "Em", "D", "Bm")
private val SHAPES = CHORDS.map { GuitarChords.pick(it) }

private const val GAP1 = 76f        // jarak tengah ke tetangga (dp)
private const val GAP2 = 140f       // jarak tengah ke akor yang keluar/masuk (dp)
private const val AUTO_MS = 2400L   // jeda geser otomatis
private const val RESUME_MS = 6000L // jeda geser otomatis setelah disentuh manual

private val Decel4 = Easing { f -> 1f - (1f - f).pow(4) }   // sama dengan DecelerateInterpolator(2f)

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t

/**
 * Mode 3: Akor. Tiga akor sekaligus (tengah skala 1, tetangga skala 0,72 dan redup 40%).
 * Belum ada hasil analisis ([ready] = false) = tulisan placeholder. Geser otomatis tiap 2,4 dtk,
 * ketuk akor di kiri atau kanan untuk geser manual.
 */
@Composable
fun ChordMode(ready: Boolean) {
    if (!ready) {
        CText("Belum ada hasil akor", Tok.W / 2f, 44f, 12.5f, color = androidx.compose.ui.graphics.Color.White.copy(alpha = .55f))
        CText("Upload & analisis dulu di island pertama", Tok.W / 2f, 60f, 10.5f, color = androidx.compose.ui.graphics.Color.White.copy(alpha = .35f))
        return
    }

    val n = CHORDS.size
    val slide = remember { Animatable(0f) }
    var idx by remember { mutableIntStateOf(0) }
    var touched by remember { mutableIntStateOf(0) }
    val steps = remember { Channel<Int>(Channel.UNLIMITED) }

    // Satu geseran selesai dulu baru berikutnya, supaya ketukan beruntun tidak hilang.
    LaunchedEffect(Unit) {
        for (dir in steps) {
            slide.snapTo(0f)
            slide.animateTo(dir.toFloat(), tween(320, easing = Decel4))
            idx = ((idx + dir) % n + n) % n
            slide.snapTo(0f)
        }
    }
    LaunchedEffect(touched) {
        delay(if (touched == 0) AUTO_MS else RESUME_MS)
        while (true) { steps.trySend(1); delay(AUTO_MS) }
    }

    fun manual(dir: Int) { steps.trySend(dir); touched++ }

    val painter = remember { ChordGlyphPainter(1f) }
    Canvas(Modifier.fillMaxSize()) {
        val d = density
        val p = painter.also { it.d = d }
        val cx = size.width / 2f; val cy = size.height / 2f
        val sl = slide.value; val ci = idx
        val items = ArrayList<FloatArray>(4)
        for (j in -2..2) { val r = j - sl; if (abs(r) < 2f) items.add(floatArrayOf(j.toFloat(), r)) }
        items.sortByDescending { abs(it[1]) }   // paling jauh digambar dulu, tengah paling akhir
        drawIntoCanvas { c ->
            for (item in items) {
                val j = item[0].toInt(); val r = item[1]; val ar = abs(r)
                val off = (if (ar <= 1f) ar * GAP1 else GAP1 + (ar - 1f) * (GAP2 - GAP1)) * (if (r < 0) -1f else 1f)
                val k = if (ar <= 1f) lerpF(1f, .72f, ar) else lerpF(.72f, .6f, ar - 1f)
                val al = if (ar <= 1f) lerpF(1f, .4f, ar) else lerpF(.4f, 0f, ar - 1f)
                val i = ((ci + j) % n + n) % n
                p.draw(c.nativeCanvas, CHORDS[i], SHAPES[i], cx + off * d, cy, k, al)
            }
        }
    }

    SideTap(Tok.W / 2f - GAP1) { manual(-1) }
    SideTap(Tok.W / 2f + GAP1) { manual(1) }
}

/** Area ketuk transparan di atas akor tetangga (juga mencegah ketukan itu masuk ke Resting). */
@Composable
private fun SideTap(cx: Float, onClick: () -> Unit) {
    Box(
        Modifier
            .placeAt(cx, Tok.H / 2f)
            .size(60.dp, 64.dp)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
    )
}
