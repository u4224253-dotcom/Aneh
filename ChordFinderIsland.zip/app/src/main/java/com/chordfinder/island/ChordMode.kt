package com.chordfinder.island

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin

private const val GAP1 = 92f        // jarak tengah ke tetangga (dp)
private const val GAP2 = 160f       // jarak tengah ke akor yang keluar/masuk (dp)
private const val LEAD_SEC = 0.08   // akor berganti sedikit lebih awal supaya tidak terasa telat
private const val POLL_MS = 40L      // seberapa sering posisi lagu dibaca (dulu 100 ms)

private val Glide = CubicBezierEasing(.3f, 0f, .2f, 1f)   // langsung bergerak, melambat halus di ujung (responsif)
private const val GLIDE_MS = 260                          // gaya "Meluncur", batas atas (dulu 750 ms, terlalu lambat)
private const val MIN_GLIDE_MS = 90                       // batas bawah untuk akor yang sangat pendek

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t

/** Satu akor di carousel: mulai di [start] detik. */
private class ChordItem(val start: Double, val name: String, val shape: ChordShape?, val rgb: FloatArray)


// ================= Warna & cahaya ambient =================
// Warna dibatasi ke keluarga maskot (cyan -> indigo -> violet): nada akar menggeser warna sedikit (lingkar kuint),
// minor condong ke violet, sus/dim/aug lebih pucat. Teks & diagram akor tetap putih; yang berwarna hanya cahayanya.
private val CYAN = floatArrayOf(25f, 184f, 255f)
private val VIOLET = floatArrayOf(123f, 75f, 255f)
private val RE_MINOR = Regex("^(m(?!aj)|min)")
private val RE_PALE = Regex("^(sus|dim|aug)")

private fun hslToRgb(h0: Float, s0: Float, l0: Float): FloatArray {
    val h = ((h0 % 360f) + 360f) % 360f; val s = s0 / 100f; val l = l0 / 100f
    val a = s * minOf(l, 1f - l)
    fun f(n: Float): Float { val k = (n + h / 30f) % 12f; return (l - a * maxOf(-1f, minOf(k - 3f, 9f - k, 1f))) * 255f }
    return floatArrayOf(f(0f), f(8f), f(4f))
}

private fun chordRGB(name: String): FloatArray {
    var root = when (name.firstOrNull()) {
        'C' -> 0; 'D' -> 2; 'E' -> 4; 'F' -> 5; 'G' -> 7; 'A' -> 9; 'B' -> 11
        else -> return floatArrayOf(160f, 175f, 255f)
    }
    var i = 1
    if (i < name.length) {
        when (name[i]) { '#' -> { root++; i++ }; '\u266D', 'b' -> { root--; i++ } }
    }
    root = (root + 12) % 12
    val suf = name.substring(i).substringBefore('/')
    var hue = 195f + ((root * 7) % 12) * 6f; var sat = 90f; var lig = 62f
    when {
        RE_MINOR.containsMatchIn(suf) -> { hue += 28f; sat = 78f; lig = 66f }
        RE_PALE.containsMatchIn(suf) -> { sat = 58f; lig = 68f }
        suf.startsWith("7") -> hue += 8f
    }
    return hslToRgb(hue, sat, lig)
}

private fun mixF(a: FloatArray, b: FloatArray, u: Float) = FloatArray(3) { a[it] + (b[it] - a[it]) * u }
private fun col(c: FloatArray, a: Float) = Color(c[0] / 255f, c[1] / 255f, c[2] / 255f, a.coerceIn(0f, 1f))

/** Semburan lembut yang mengikuti tempo: naik pelan ~0,6 ketuk, surut ~2,4 ketuk, tanpa lonjakan mendadak. */
private fun burstEnv(tau: Float): Float = when {
    tau < 0f -> 0f
    tau < .6f -> .5f - .5f * cos(PI.toFloat() * tau / .6f)
    tau < 3f -> .5f + .5f * cos(PI.toFloat() * (tau - .6f) / 2.4f)
    else -> 0f
}

/** Satu akor yang tampil di carousel: posisi (dp dari tengah), skala, redup, tingkat "fokus" warna. */
private class Vis(val i: Int, val r: Float, val off: Float, val k: Float, val f: Float, val e: Boolean)

/** Digambar di koordinat dp (0..420 x 0..96). [ms] = waktu berjalan; [burst] 0..1 = semburan akor yang baru masuk. */
private fun DrawScope.drawAmbient(ms: Float, vis: List<Vis>, list: List<ChordItem>, cc: FloatArray, burst: Float, burstC: FloatArray) {
    val breath = .86f + .14f * sin(ms / 850f)
    val w = Tok.W; val h = Tok.H
    // kabut dasar island, warna akor yang sedang berbunyi
    drawRect(
        Brush.verticalGradient(0f to col(cc, 0f), 1f to col(cc, .34f * breath), startY = 40f, endY = h),
        topLeft = Offset(0f, 40f), size = Size(w, h - 40f),
    )
    // semburan: satu kali saat akor baru sampai di depan, hanya warna akor itu
    if (burst > .005f) drawRect(
        Brush.verticalGradient(0f to col(burstC, 0f), 1f to col(burstC, .26f * burst), startY = 40f, endY = h),
        topLeft = Offset(0f, 40f), size = Size(w, h - 40f),
    )
    // tiga bercak warna (cyan, warna akor, violet) yang melayang pelan ke kiri-kanan di dasar
    for (n in 0..2) {
        val px = w / 2f + 150f * sin(ms / 1000f * (if (n == 1) -.45f else .5f + n * .1f) + n * 2.1f)
        val pc = when (n) { 0 -> mixF(cc, CYAN, .35f); 1 -> cc; else -> mixF(cc, VIOLET, .35f) }
        val a = (if (n == 1) .42f else .32f) * breath
        withTransform({ translate(px, 98f); scale(2.3f, .6f, Offset.Zero) }) {
            drawCircle(
                Brush.radialGradient(0f to col(pc, a), 1f to col(pc, 0f), center = Offset.Zero, radius = 70f),
                radius = 70f, center = Offset.Zero,
            )
        }
    }
    // titik terang di garis bawah, berjalan bolak-balik
    val mc = .5f + .36f * sin(ms / 1500f)
    drawRect(
        Brush.horizontalGradient(0f to col(cc, 0f), mc to col(cc, .95f), 1f to col(cc, 0f), startX = 30f, endX = w - 30f),
        topLeft = Offset(30f, h - 2f), size = Size(w - 60f, 2f),
    )
    // bola cahaya di belakang tiap akor: melayang pelan, ukuran naik-turun, warna condong cyan/violet bergantian
    for (v in vis) {
        val ar = abs(v.r)
        val a = (if (ar <= 1f) 1f else maxOf(0f, 2f - ar)) * (.06f + .24f * v.f) * breath + (if (v.e) .26f * burst else 0f)
        if (a < .01f) continue
        val rb = 46f * v.k * (1f + .08f * sin(ms / 1100f + v.i))
        val sn = sin(ms / 2100f + v.i)
        val bc = mixF(list[v.i].rgb, if (sn > 0f) VIOLET else CYAN, .3f * abs(sn))
        withTransform({
            translate(w / 2f + v.off + 9f * sin(ms / 1300f + v.i), 50f + 3f * cos(ms / 1700f + v.i * 2f))
            scale(1.7f, 1f, Offset.Zero)
        }) {
            drawCircle(
                Brush.radialGradient(0f to col(bc, a), .55f to col(bc, a * .35f), 1f to col(bc, 0f), center = Offset.Zero, radius = rb),
                radius = rb, center = Offset.Zero,
            )
        }
    }
}

/** Segmen hasil mesin -> daftar tampil: tanpa "tidak ada akor", akor yang sama berturutan digabung. */
private fun displayList(segs: List<ChordHub.Seg>): List<ChordItem> {
    val out = ArrayList<ChordItem>()
    for (s in segs) {
        if (s.name == "–") continue
        if (out.isNotEmpty() && out.last().name == s.name) continue
        out.add(ChordItem(s.start, s.name, GuitarChords.pick(s.name), chordRGB(s.name)))
    }
    return out
}

/** Indeks akor yang sedang berbunyi di detik [t]: akor terakhir yang sudah mulai (sebelum akor pertama = akor pertama). */
private fun indexAt(list: List<ChordItem>, t: Double): Int {
    var lo = 0; var hi = list.size - 1; var ans = 0
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        if (list[mid].start <= t + LEAD_SEC) { ans = mid; lo = mid + 1 } else hi = mid - 1
    }
    return ans
}

/**
 * Mode 4: Akor. Tiga akor sekaligus (tengah skala 1, tetangga skala 0,72 dan redup 40%).
 * Akor tengah mengikuti posisi lagu: pindah satu akor = geser halus; lompat jauh (mis. lagu digeser) = langsung pindah.
 * Ketuk akor di kiri/kanan = akor sebelumnya/selanjutnya, lagu ikut lompat ke waktu mulai akor itu.
 * [result] = hasil analisis; null = belum ada.
 */
@Composable
fun ChordMode(player: PlayerController, result: ChordHub.St.Done?) {
    val list = remember(result) { result?.let { displayList(it.segs) } }
    if (list == null) {
        CText("Belum ada hasil akor", Tok.W / 2f, 44f, 12.5f, color = Color.White.copy(alpha = .55f))
        CText("Upload & analisis dulu di island pertama", Tok.W / 2f, 60f, 10.5f, color = Color.White.copy(alpha = .35f))
        return
    }
    if (list.isEmpty()) {
        CText("Tidak ada akor terdeteksi", Tok.W / 2f, 44f, 12.5f, color = Color.White.copy(alpha = .55f))
        CText("Audio ini mungkin kosong atau tanpa nada", Tok.W / 2f, 60f, 10.5f, color = Color.White.copy(alpha = .35f))
        return
    }

    // posisi lagu dibaca tiap POLL_MS selama mode ini tampil (pemutar sendiri hanya membaca tiap 250 ms di mode Preview)
    LaunchedEffect(player) {
        while (true) { player.tick(); delay(POLL_MS) }
    }

    val n = list.size
    val target = indexAt(list, player.t.toDouble())
    val slide = remember { Animatable(0f) }
    var idx by remember(list) { mutableIntStateOf(target) }
    // akor yang dianggap "sudah di depan": berubah saat akor baru hampir sampai di tengah (dikunci, tidak batal walau geseran masih jalan)
    var shownIdx by remember(list) { mutableIntStateOf(target) }
    val tgt by rememberUpdatedState(target)
    val shownNow by rememberUpdatedState(shownIdx)

    LaunchedEffect(list) {
        while (true) {
            val diff = snapshotFlow { tgt - idx }.first { it != 0 }
            if (abs(diff) == 1) {
                slide.snapTo(0f)
                var latched = false
                // lama geser disesuaikan dengan panjang akor yang masuk (maks. 45% darinya): saat akor berganti
                // cepat, geseran tidak menumpuk jadi antrean sehingga tampilan tidak makin tertinggal dari lagu
                val inc = (idx + diff).coerceIn(0, n - 1)
                val gapMs = if (inc + 1 < n) ((list[inc + 1].start - list[inc].start) * 1000.0).toInt() else GLIDE_MS
                val glideMs = (gapMs * 0.45).toInt().coerceIn(MIN_GLIDE_MS, GLIDE_MS)
                slide.animateTo(diff.toFloat(), tween(glideMs, easing = Glide)) {
                    if (!latched && abs(diff - value) < .1f) { latched = true; shownIdx = idx + diff }
                }
                idx += diff
                slide.snapTo(0f)
                shownIdx = idx
            } else {
                idx = tgt
                shownIdx = tgt
                slide.snapTo(0f)
            }
        }
    }

    // warna + cahaya: mengikuti akor yang "sudah di depan"; semburan tempo mengikuti jarak antar akor
    val beatSec = remember(list) {
        val gaps = list.zipWithNext { a, b -> b.start - a.start }.sorted()
        val med = if (gaps.isEmpty()) 3.0 else gaps[gaps.size / 2]
        (med / 4.0).coerceIn(.35, .75).toFloat()   // perkiraan satu ketuk (mesin belum memberi BPM)
    }
    val focus = remember(list) { FloatArray(n).also { it[target.coerceIn(0, n - 1)] = 1f } }
    val ccol = remember(list) { list[target.coerceIn(0, n - 1)].rgb.copyOf() }
    val t0 = remember { LongArray(1) }
    val clock = remember { LongArray(1) }
    val burstT0 = remember(list) { longArrayOf(Long.MIN_VALUE / 2) }
    val firstShown = remember(list) { booleanArrayOf(true) }
    var now by remember { mutableLongStateOf(0L) }

    LaunchedEffect(shownIdx) {
        if (firstShown[0]) firstShown[0] = false else burstT0[0] = clock[0]
    }
    LaunchedEffect(list) {
        var last = 0L
        while (true) withFrameNanos { ns ->
            if (t0[0] == 0L) t0[0] = ns
            val dt = if (last == 0L) 0f else ((ns - last) / 1e9f).coerceAtMost(.05f)
            last = ns
            val kc = 1f - exp(-dt / .04f)   // ~120 ms sampai tuntas (warna & cahaya ikut cepat)
            val sh = shownNow.coerceIn(0, n - 1)
            for (q in 0 until n) focus[q] += ((if (q == sh) 1f else 0f) - focus[q]) * kc
            val tc = list[sh].rgb
            for (c in 0..2) ccol[c] += (tc[c] - ccol[c]) * kc
            clock[0] = ns
            now = ns
        }
    }
    val clip = remember {
        Path().apply {
            addRoundRect(RoundRect(0f, 0f, Tok.W, Tok.H, CornerRadius.Zero, CornerRadius.Zero, CornerRadius(Tok.R), CornerRadius(Tok.R)))
        }
    }

    val painter = remember { ChordGlyphPainter(1f) }
    Canvas(Modifier.fillMaxSize()) {
        val d = density
        val p = painter.also { it.d = d }
        val cx = size.width / 2f; val cy = size.height / 2f
        val sl = slide.value; val ci = idx
        val ns = now
        val ms = if (t0[0] == 0L) 0f else (ns - t0[0]) / 1_000_000f
        val items = ArrayList<FloatArray>(4)
        for (j in -2..2) { val r = j - sl; if (abs(r) < 2f) items.add(floatArrayOf(j.toFloat(), r)) }
        items.sortByDescending { abs(it[1]) }   // paling jauh digambar dulu, tengah paling akhir
        val sh = shownIdx.coerceIn(0, n - 1)
        val vis = ArrayList<Vis>(4)
        val pos = ArrayList<FloatArray>(4)      // [indeks, offset, k, alfa]
        for (item in items) {
            val j = item[0].toInt(); val r = item[1]; val ar = abs(r)
            val i = ci + j
            if (i < 0 || i >= n) continue   // di ujung lagu tidak ada tetangga
            val off = (if (ar <= 1f) ar * GAP1 else GAP1 + (ar - 1f) * (GAP2 - GAP1)) * (if (r < 0) -1f else 1f)
            val k = if (ar <= 1f) lerpF(1f, .72f, ar) else lerpF(.72f, .6f, ar - 1f)
            val al = if (ar <= 1f) lerpF(1f, .4f, ar) else lerpF(.4f, 0f, ar - 1f)
            vis.add(Vis(i, r, off, k, focus[i], i == sh))
            pos.add(floatArrayOf(i.toFloat(), off, k, al))
        }
        val env = burstEnv((ns - burstT0[0]) / 1e9f / beatSec)
        // lapisan cahaya di bawah akor (dalam bentuk island)
        scale(d, d, Offset.Zero) {
            clipPath(clip) { drawAmbient(ms, vis, list, ccol, env, list[sh].rgb) }
        }
        // akor tetap putih polos
        drawIntoCanvas { c ->
            for (q in pos) {
                val i = q[0].toInt()
                p.draw(c.nativeCanvas, list[i].name, list[i].shape, cx + q[1] * d, cy, q[2], q[3])
            }
        }
    }

    // Ketuk akor tetangga = pindah ke akor itu: lagu ikut lompat ke waktu mulainya (carousel mengikuti posisi lagu).
    // Dasarnya akor yang sedang terpilih menurut posisi lagu (bukan yang sedang beranimasi), jadi ketukan beruntun
    // tetap maju satu akor tiap ketukan. Di ujung lagu tidak ada tetangga: ketukan hanya ditahan supaya tidak
    // tembus ke area kosong dan membuat island masuk Resting.
    val jump: (Int) -> Unit = { dir ->
        val j = tgt + dir
        if (j in 0 until n) player.seek(list[j].start.toFloat())
    }
    SideTap(Tok.W / 2f - GAP1) { jump(-1) }
    SideTap(Tok.W / 2f + GAP1) { jump(1) }
}

/** Area ketuk transparan di atas akor tetangga (juga mencegah ketukan itu masuk ke Resting). */
@Composable
private fun SideTap(cx: Float, onTap: () -> Unit) {
    Box(
        Modifier
            .placeAt(cx, Tok.H / 2f)
            .size(60.dp, 64.dp)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onTap),
    )
}
