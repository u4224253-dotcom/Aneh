package com.chordfinder.island

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlin.math.abs
import kotlin.math.pow

private const val GAP1 = 92f        // jarak tengah ke tetangga (dp)
private const val GAP2 = 160f       // jarak tengah ke akor yang keluar/masuk (dp)
private const val LEAD_SEC = 0.05   // akor berganti sedikit lebih awal supaya tidak terasa telat

private val Decel4 = Easing { f -> 1f - (1f - f).pow(4) }   // sama dengan DecelerateInterpolator(2f)

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t

/** Satu akor di carousel: mulai di [start] detik. */
private class ChordItem(val start: Double, val name: String, val shape: ChordShape?)

/** Segmen hasil mesin -> daftar tampil: tanpa "tidak ada akor", akor yang sama berturutan digabung. */
private fun displayList(segs: List<ChordHub.Seg>): List<ChordItem> {
    val out = ArrayList<ChordItem>()
    for (s in segs) {
        if (s.name == "–") continue
        if (out.isNotEmpty() && out.last().name == s.name) continue
        out.add(ChordItem(s.start, s.name, GuitarChords.pick(s.name)))
    }
    return out
}

/** Indeks akor yang sedang berbunyi di detik [t]: akor terakhir yang sudah mulai (sebelum akor pertama = akor pertama). */
private fun indexAt(list: List<ChordItem>, t: Double): Int {
    var lo = 0; var hi = list.size - 1; var ans = 0
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        if (list[mid].start <= t + LEAD_SEC) { ans = mid; lo = mid + 1 } else hi = mid - 1
    }
    return ans
}

/**
 * Mode 4: Akor. Tiga akor sekaligus (tengah skala 1, tetangga skala 0,72 dan redup 40%).
 * Akor tengah mengikuti posisi lagu: pindah satu akor = geser halus; lompat jauh (mis. lagu digeser) = langsung pindah.
 * Ketuk akor di kiri/kanan = akor sebelumnya/selanjutnya, lagu ikut lompat ke waktu mulai akor itu.
 * [result] = hasil analisis; null = belum ada.
 */
@Composable
fun ChordMode(player: PlayerController, result: ChordHub.St.Done?) {
    val list = remember(result) { result?.let { displayList(it.segs) } }
    if (list == null) {
        CText("Belum ada hasil akor", Tok.W / 2f, 44f, 12.5f, color = Color.White.copy(alpha = .55f))
        CText("Upload & analisis dulu di island pertama", Tok.W / 2f, 60f, 10.5f, color = Color.White.copy(alpha = .35f))
        return
    }
    if (list.isEmpty()) {
        CText("Tidak ada akor terdeteksi", Tok.W / 2f, 44f, 12.5f, color = Color.White.copy(alpha = .55f))
        CText("Audio ini mungkin kosong atau tanpa nada", Tok.W / 2f, 60f, 10.5f, color = Color.White.copy(alpha = .35f))
        return
    }

    // posisi lagu dibaca tiap 100 ms selama mode ini tampil (pemutar sendiri hanya membaca tiap 250 ms di mode Preview)
    LaunchedEffect(player) {
        while (true) { player.tick(); delay(100) }
    }

    val n = list.size
    val target = indexAt(list, player.t.toDouble())
    val slide = remember { Animatable(0f) }
    var idx by remember(list) { mutableIntStateOf(target) }
    val tgt by rememberUpdatedState(target)

    LaunchedEffect(list) {
        while (true) {
            val diff = snapshotFlow { tgt - idx }.first { it != 0 }
            if (abs(diff) == 1) {
                slide.snapTo(0f)
                slide.animateTo(diff.toFloat(), tween(320, easing = Decel4))
                idx += diff
                slide.snapTo(0f)
            } else {
                idx = tgt
                slide.snapTo(0f)
            }
        }
    }

    val painter = remember { ChordGlyphPainter(1f) }
    Canvas(Modifier.fillMaxSize()) {
        val d = density
        val p = painter.also { it.d = d }
        val cx = size.width / 2f; val cy = size.height / 2f
        val sl = slide.value; val ci = idx
        val items = ArrayList<FloatArray>(4)
        for (j in -2..2) { val r = j - sl; if (abs(r) < 2f) items.add(floatArrayOf(j.toFloat(), r)) }
        items.sortByDescending { abs(it[1]) }   // paling jauh digambar dulu, tengah paling akhir
        drawIntoCanvas { c ->
            for (item in items) {
                val j = item[0].toInt(); val r = item[1]; val ar = abs(r)
                val i = ci + j
                if (i < 0 || i >= n) continue   // di ujung lagu tidak ada tetangga
                val off = (if (ar <= 1f) ar * GAP1 else GAP1 + (ar - 1f) * (GAP2 - GAP1)) * (if (r < 0) -1f else 1f)
                val k = if (ar <= 1f) lerpF(1f, .72f, ar) else lerpF(.72f, .6f, ar - 1f)
                val al = if (ar <= 1f) lerpF(1f, .4f, ar) else lerpF(.4f, 0f, ar - 1f)
                p.draw(c.nativeCanvas, list[i].name, list[i].shape, cx + off * d, cy, k, al)
            }
        }
    }

    // Ketuk akor tetangga = pindah ke akor itu: lagu ikut lompat ke waktu mulainya (carousel mengikuti posisi lagu).
    // Dasarnya akor yang sedang terpilih menurut posisi lagu (bukan yang sedang beranimasi), jadi ketukan beruntun
    // tetap maju satu akor tiap ketukan. Di ujung lagu tidak ada tetangga: ketukan hanya ditahan supaya tidak
    // tembus ke area kosong dan membuat island masuk Resting.
    val jump: (Int) -> Unit = { dir ->
        val j = tgt + dir
        if (j in 0 until n) player.seek(list[j].start.toFloat())
    }
    SideTap(Tok.W / 2f - GAP1) { jump(-1) }
    SideTap(Tok.W / 2f + GAP1) { jump(1) }
}

/** Area ketuk transparan di atas akor tetangga (juga mencegah ketukan itu masuk ke Resting). */
@Composable
private fun SideTap(cx: Float, onTap: () -> Unit) {
    Box(
        Modifier
            .placeAt(cx, Tok.H / 2f)
            .size(60.dp, 64.dp)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onTap),
    )
}
