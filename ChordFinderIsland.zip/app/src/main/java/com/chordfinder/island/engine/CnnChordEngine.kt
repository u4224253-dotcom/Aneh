package com.chordfinder.island.engine

import java.io.InputStream

/**
 * Mesin chord finder kedua: CNN+BiLSTM ChordMini (default repo asli), 3 fold, Kotlin murni.
 * Alur: audio -> mono 22.050 Hz -> CQT 288 bin (sekali) -> bin 18..269 ->
 *       tiap fold (berurutan, hemat RAM): chunk 3000 frame overlap 400 -> ChordNet -> jumlahkan probabilitas ->
 *       rata-rata fold -> Viterbi 301 akor.
 * Bobot: assets/cnn.lkm (dibuat tools/export_lkm_cnn.py). Satu instance = satu pekerjaan pada satu waktu.
 */
class CnnChordEngine(private val lkm: LkmFile) {
    private val table = parseChordTable(String(lkm.blob("chord_table_json"), Charsets.UTF_8))
    private val cqt = CqtCnn(lkm)
    private val folds = lkm.ints("folds")
    private val decoder = FlatChordDecoder(table)

    /** @param pcm audio mono [-1,1] pada laju [sampleRate]; di-resample ke 22.050 Hz bila perlu. onProgress 0..1; boleh melempar untuk membatalkan. */
    fun analyze(pcm: FloatArray, sampleRate: Int, onProgress: ((Float) -> Unit)? = null): ChordAnalysis {
        val y = if (sampleRate == SAMPLE_RATE) pcm else Resampler.resample(pcm, sampleRate, SAMPLE_RATE)
        val dur = table.hop.toDouble() / table.sampleRate

        val c = cqt.compute(y) { onProgress?.invoke(it * 0.10f) }
        val frames = c.frames
        if (frames == 0) return ChordAnalysis(emptyList(), IntArray(0), dur)
        val x = CqtCnn.netInput(c)

        val plan = FlatChordDecoder.planChunks(frames)
        val acc = FlatChordDecoder.Accumulator(frames)
        val steps = folds.size * plan.size
        var done = 0
        for (fold in folds) {
            val net = ChordNetCnn(lkm, fold)
            for (ch in plan) {
                val n = ch.end - ch.start
                val part = x.copyOfRange(ch.start * CqtCnn.NET_BINS, ch.end * CqtCnn.NET_BINS)
                val base = 0.10f + 0.85f * done / steps
                val span = 0.85f / steps
                acc.add(net.forward(part, n) { onProgress?.invoke(base + span * it) }, ch)
                done++
            }
        }
        onProgress?.invoke(0.95f)
        val path = decoder.viterbi(acc, folds.size)
        val segs = decoder.toSegments(path)
        onProgress?.invoke(1f)
        return ChordAnalysis(segs, path, dur)
    }

    companion object {
        const val SAMPLE_RATE = 22050
        fun load(input: InputStream): CnnChordEngine = CnnChordEngine(LkmFile.read(input))
    }
}
