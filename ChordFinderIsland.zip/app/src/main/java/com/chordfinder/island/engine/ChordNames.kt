package com.chordfinder.island.engine

/** Interval bas ("b7", "5", ...) dari label CNN -> semitone. */
private fun bassSemis(iv: String): Int? = when (iv) {
    "1" -> 0; "b2" -> 1; "2" -> 2; "b3" -> 3; "3" -> 4; "4" -> 5; "b5" -> 6
    "5" -> 7; "b6" -> 8; "6" -> 9; "b7" -> 10; "7" -> 11; else -> null
}

private val NOTE_FLAT = arrayOf("C", "D♭", "D", "E♭", "E", "F", "G♭", "G", "A♭", "A", "B♭", "B")
private val NOTE_SHARP = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

private fun rootSemis(root: String): Int {
    val base = when (root.firstOrNull()) { 'C' -> 0; 'D' -> 2; 'E' -> 4; 'F' -> 5; 'G' -> 7; 'A' -> 9; 'B' -> 11; else -> 0 }
    return (base + (if (root.contains('#')) 1 else 0) - (if (root.length > 1 && root[1] == 'b') 1 else 0) + 12) % 12
}

/**
 * Label model ("A:min", "Db:maj7", "C:min/b7", "N") -> nama yang dibaca musisi ("Amin", "D♭maj7", "Cmin/B♭", "–").
 * Label mesin CNN punya bas sebagai interval ("/b7"); diubah jadi nama nada.
 */
fun chordName(label: String): String {
    if (label == "N" || label == "X") return "–"
    val i = label.indexOf(':')
    val rootRaw = if (i < 0) label else label.substring(0, i)
    val root = rootRaw.replace("b", "♭")
    if (i < 0) return root
    val rest = label.substring(i + 1)
    val qual = rest.substringBefore('/')
    val bassIv = rest.substringAfter('/', "")
    val q = when (qual) {
        "hdim7" -> "m7♭5"
        "maj6" -> "6"
        "sus4(b7)" -> "7sus4"
        else -> qual   // min, min6, min7, min9, minmaj7, maj, maj7, maj9, 7, 9, 11, 13, dim, dim7, aug, sus2, sus4 (ditulis apa adanya: Amin, Amaj)
    }
    val bass = bassSemis(bassIv)?.let { iv ->
        val n = (rootSemis(rootRaw) + iv) % 12
        "/" + (if (rootRaw.contains('#')) NOTE_SHARP[n] else NOTE_FLAT[n])
    } ?: ""
    return root + q + bass
}
