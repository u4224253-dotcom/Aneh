package com.chordfinder.island.engine

import kotlin.math.expm1
import kotlin.math.min
import kotlin.math.sqrt

/**
 * CNNFeatureExtractor dari ChordMini (chordnet_ismir_naive.py), satu fold.
 *
 *   |CQT| [T,252] -> 3x(conv3x3 pad(1,1)+InstanceNorm+SELU) -> MaxPool(1,3)
 *                 -> 3x(conv 32)                           -> MaxPool(1,3)
 *                 -> 2x(conv 64)                           -> MaxPool(1,4)
 *                 -> 2x(conv 80, pad(1,0))                 -> [T, 240]
 *
 * Keluaran per frame berurutan (channel dulu, lalu lebar): indeks = c*3 + w,
 * sama dengan x.transpose(1,2).view(B,T,240) di PyTorch.
 *
 * PENTING: InstanceNorm menghitung mean/varians per channel di SELURUH chunk yang diberikan
 * (waktu x frekuensi), jadi hasil bergantung pada ukuran chunk. Panggil [extract] dengan chunk
 * yang sama persis seperti saat inferensi (3000 frame di pipeline ini).
 *
 * Layout internal aktivasi: [waktu][lebar][channel] (NHWC), bobot disusun ulang menjadi
 * [kh][kw][cin][cout] supaya loop terdalam berjalan di channel keluaran yang berurutan di memori.
 *
 * Thread: instance ini tidak menyimpan state per panggilan, jadi aman dipanggil dari banyak thread,
 * tetapi tiap panggilan sendiri sudah memakai [threads] thread.
 */
internal class CnnFeatureExtractor(
    lkm: LkmFile,
    fold: Int,
    private val threads: Int = defaultThreads(),
) {

    private class Conv(
        val cin: Int,
        val cout: Int,
        val padW: Int,
        /** [kh][kw][cin][cout] */
        val w: FloatArray,
        val bias: FloatArray,
    )

    private class Stage(val conv: Conv, val poolAfter: Int)

    private val stages: List<Stage>

    init {
        require(threads >= 1) { "threads harus >= 1" }
        // (nama, cin, cout, padW, pool setelah layer ini [0 = tanpa])
        val spec = listOf(
            arrayOf("conv1a", 1, 16, 1, 0), arrayOf("conv1b", 16, 16, 1, 0), arrayOf("conv1c", 16, 16, 1, 3),
            arrayOf("conv2a", 16, 32, 1, 0), arrayOf("conv2b", 32, 32, 1, 0), arrayOf("conv2c", 32, 32, 1, 3),
            arrayOf("conv3a", 32, 64, 1, 0), arrayOf("conv3b", 64, 64, 1, 4),
            arrayOf("conv4a", 64, 80, 0, 0), arrayOf("conv4b", 80, 80, 0, 0),
        )
        stages = spec.map { s ->
            val name = s[0] as String
            val cin = s[1] as Int
            val cout = s[2] as Int
            val padW = s[3] as Int
            val pool = s[4] as Int
            val wRaw = lkm.tensor("f$fold.$name.weight").data // [cout][cin][3][3]
            val b = lkm.tensor("f$fold.$name.bias").data
            require(wRaw.size == cout * cin * 9) { "Bobot $name fold $fold ukurannya ${wRaw.size}, seharusnya ${cout * cin * 9}" }
            require(b.size == cout) { "Bias $name fold $fold ukurannya ${b.size}, seharusnya $cout" }
            val w = FloatArray(wRaw.size)
            for (co in 0 until cout) for (ci in 0 until cin) for (kh in 0 until 3) for (kw in 0 until 3) {
                w[((kh * 3 + kw) * cin + ci) * cout + co] = wRaw[((co * cin + ci) * 3 + kh) * 3 + kw]
            }
            Stage(Conv(cin, cout, padW, w, b.copyOf()), pool)
        }
    }

    /**
     * @param x |CQT| linear [frames * 252], urutan [frame][bin] (hasil [CqtCnn.netInput])
     * @return fitur [frames * 240], urutan [frame][c*3 + w]
     */
    fun extract(x: FloatArray, frames: Int, onProgress: ((Float) -> Unit)? = null): FloatArray {
        require(frames >= 1) { "frames harus >= 1" }
        require(x.size == frames * IN_BINS) { "Input ${x.size} != $frames * $IN_BINS" }

        // dua buffer ping-pong; terbesar = keluaran conv1b/1c: T * 252 * 16
        val cap = frames * IN_BINS * 16
        var cur = FloatArray(cap)
        var nxt = FloatArray(cap)
        System.arraycopy(x, 0, cur, 0, x.size) // [T][252][1]

        var width = IN_BINS
        var done = 0
        for (st in stages) {
            val c = st.conv
            val wOut = width + 2 * c.padW - 2
            val stats = Stats(c.cout)
            conv3x3(cur, nxt, frames, width, wOut, c, stats)
            val mean = FloatArray(c.cout)
            val inv = FloatArray(c.cout)
            stats.finish(frames.toLong() * wOut, mean, inv)
            // setelah blok ini hasilnya selalu ada di `cur`
            if (st.poolAfter > 0) {
                val k = st.poolAfter
                val wp = wOut / k
                poolNormSelu(nxt, cur, frames, wOut, wp, k, c.cout, mean, inv) // nxt -> cur
                width = wp
            } else {
                normSelu(nxt, frames * wOut * c.cout, c.cout, mean, inv) // di tempat di nxt
                val t = cur; cur = nxt; nxt = t
                width = wOut
            }
            onProgress?.invoke(++done / stages.size.toFloat())
        }
        check(width == 3) { "Lebar akhir $width, seharusnya 3" }

        val out = FloatArray(frames * OUT_SIZE)
        val ch = stages.last().conv.cout // 80
        parallelFor(frames) { t0, t1 ->
            for (t in t0 until t1) {
                val o = t * OUT_SIZE
                for (w in 0 until 3) {
                    val src = (t * 3 + w) * ch
                    for (c in 0 until ch) out[o + c * 3 + w] = cur[src + c]
                }
            }
        }
        return out
    }

    // ---------------------------------------------------------------------------------------

    /** Penjumlahan mean/kuadrat per channel (double) dari semua thread, urutan tetap -> deterministik. */
    private class Stats(val ch: Int) {
        val sum = DoubleArray(ch)
        val sq = DoubleArray(ch)
        @Synchronized
        fun add(s: DoubleArray, q: DoubleArray) {
            for (c in 0 until ch) { sum[c] += s[c]; sq[c] += q[c] }
        }

        fun finish(n: Long, mean: FloatArray, inv: FloatArray) {
            for (c in 0 until ch) {
                val m = sum[c] / n
                val v = (sq[c] / n - m * m).coerceAtLeast(0.0) // varians populasi (biased)
                mean[c] = m.toFloat()
                inv[c] = (1.0 / sqrt(v + EPS)).toFloat()
            }
        }
    }

    /**
     * Konvolusi 3x3 (kh = waktu pad 1, kw = frekuensi pad c.padW), plus bias, tulis ke [out],
     * dan kumpulkan jumlah / jumlah-kuadrat per channel untuk InstanceNorm.
     */
    private fun conv3x3(inp: FloatArray, out: FloatArray, tN: Int, wIn: Int, wOut: Int, c: Conv, stats: Stats) {
        val cin = c.cin
        val cout = c.cout
        val padW = c.padW
        val w = c.w
        val bias = c.bias
        val unroll = cin % 4 == 0
        parallelFor(tN) { t0, t1 ->
            val acc = FloatArray(cout)
            val s = DoubleArray(cout)
            val q = DoubleArray(cout)
            for (t in t0 until t1) {
                for (x in 0 until wOut) {
                    System.arraycopy(bias, 0, acc, 0, cout)
                    for (kh in 0 until 3) {
                        val tt = t + kh - 1
                        if (tt < 0 || tt >= tN) continue
                        for (kw in 0 until 3) {
                            val xx = x + kw - padW
                            if (xx < 0 || xx >= wIn) continue
                            val ib = (tt * wIn + xx) * cin
                            val wb = (kh * 3 + kw) * cin * cout
                            if (unroll) {
                                var ci = 0
                                while (ci < cin) {
                                    val v0 = inp[ib + ci]
                                    val v1 = inp[ib + ci + 1]
                                    val v2 = inp[ib + ci + 2]
                                    val v3 = inp[ib + ci + 3]
                                    val w0 = wb + ci * cout
                                    val w1 = w0 + cout
                                    val w2 = w1 + cout
                                    val w3 = w2 + cout
                                    for (co in 0 until cout) {
                                        acc[co] += v0 * w[w0 + co] + v1 * w[w1 + co] + v2 * w[w2 + co] + v3 * w[w3 + co]
                                    }
                                    ci += 4
                                }
                            } else {
                                for (ci in 0 until cin) {
                                    val v = inp[ib + ci]
                                    val w0 = wb + ci * cout
                                    for (co in 0 until cout) acc[co] += v * w[w0 + co]
                                }
                            }
                        }
                    }
                    val ob = (t * wOut + x) * cout
                    for (co in 0 until cout) {
                        val a = acc[co]
                        out[ob + co] = a
                        s[co] += a
                        q[co] += a.toDouble() * a
                    }
                }
            }
            stats.add(s, q)
        }
    }

    /** (x - mean) * inv lalu SELU, di tempat. Layout [..][cout]. */
    private fun normSelu(buf: FloatArray, count: Int, cout: Int, mean: FloatArray, inv: FloatArray) {
        val rows = count / cout
        parallelFor(rows) { r0, r1 ->
            for (r in r0 until r1) {
                val b = r * cout
                for (co in 0 until cout) buf[b + co] = selu((buf[b + co] - mean[co]) * inv[co])
            }
        }
    }

    /**
     * MaxPool(1,k) di sumbu frekuensi, digabung dengan norm+SELU. Norm (inv > 0) dan SELU sama-sama
     * monoton naik, jadi max dicari pada nilai mentah lalu cukup satu kali norm+SELU per keluaran.
     */
    private fun poolNormSelu(
        inp: FloatArray, out: FloatArray, tN: Int, wIn: Int, wOut: Int, k: Int,
        cout: Int, mean: FloatArray, inv: FloatArray,
    ) {
        parallelFor(tN) { t0, t1 ->
            for (t in t0 until t1) {
                for (x in 0 until wOut) {
                    val ob = (t * wOut + x) * cout
                    val ib = (t * wIn + x * k) * cout
                    for (co in 0 until cout) {
                        var m = inp[ib + co]
                        for (j in 1 until k) {
                            val v = inp[ib + j * cout + co]
                            if (v > m) m = v
                        }
                        out[ob + co] = selu((m - mean[co]) * inv[co])
                    }
                }
            }
        }
    }

    /** Bagi [0,n) menjadi blok kontigu, satu per thread; thread pemanggil ikut bekerja. */
    private fun parallelFor(n: Int, body: (Int, Int) -> Unit) {
        val nt = min(threads, maxOf(1, n / MIN_ROWS_PER_THREAD))
        if (nt <= 1) {
            body(0, n)
            return
        }
        val per = (n + nt - 1) / nt
        var failure: Throwable? = null
        val workers = ArrayList<Thread>(nt - 1)
        for (i in 1 until nt) {
            val a = i * per
            val b = min(n, a + per)
            if (a >= b) break
            workers += Thread {
                try { body(a, b) } catch (e: Throwable) { synchronized(workers) { failure = failure ?: e } }
            }.also { it.start() }
        }
        try { body(0, min(n, per)) } catch (e: Throwable) { synchronized(workers) { failure = failure ?: e } }
        for (t in workers) t.join()
        failure?.let { throw it }
    }

    companion object {
        const val IN_BINS = 252
        const val OUT_SIZE = 240
        private const val EPS = 1e-5
        private const val MIN_ROWS_PER_THREAD = 16
        private const val LAMBDA = 1.0507009873554805
        private const val ALPHA = 1.6732632423543772
        private const val LA = (LAMBDA * ALPHA).toFloat()
        private const val L = LAMBDA.toFloat()

        fun defaultThreads(): Int = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)

        @JvmStatic
        private fun selu(x: Float): Float = if (x > 0f) L * x else LA * expm1(x.toDouble()).toFloat()
    }
}
