package com.chordfinder.island

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp

private val BACK = listOf(-76f, 76f, -48f, 48f, -22f, 22f)
private val FRONT = listOf(-60f, 60f, -36f, 36f, -14f, 14f, 0f)

private fun petalPath(w: Float, h: Float): Path = Path().apply {
    moveTo(.5f * w, 0f)
    arcTo(Rect(0f, 0f, w, 1.28f * h), -90f, 90f, false)
    arcTo(Rect(.08f * w, .28f * h, w, h), 0f, 90f, false)
    lineTo(.46f * w, h)
    arcTo(Rect(0f, .28f * h, .92f * w, h), 90f, 90f, false)
    arcTo(Rect(0f, 0f, w, 1.28f * h), 180f, 90f, false)
    close()
}

private fun DrawScope.petal(r: Float, wu: Float, hu: Float, alpha: Float, k: Float) {
    val w = wu * k; val h = hu * k
    val cx = size.width / 2f; val py = 430f * k
    withTransform({
        rotate(r + 180f, Offset(cx, py))
        translate(cx - w / 2f, py)
    }) {
        drawPath(
            petalPath(w, h),
            Brush.linearGradient(
                0f to rgba(123, 75, 255, .95f), .38f to rgba(45, 91, 255, .92f),
                .72f to rgba(25, 184, 255, .88f), 1f to rgba(210, 240, 255, .95f),
                start = Offset(0f, h), end = Offset(0f, 0f),
            ),
            alpha = alpha,
        )
    }
}

/** Wallpaper "bunga cahaya". Catatan: bayangan inset/outer pada kelopak belum di-port (pendekatan). */
@Composable
fun Wallpaper(u: Float) {
    val k = u * LocalDensity.current.density
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                Brush.verticalGradient(
                    0f to Color(0xFFDBE7FF), .30f to Color(0xFFB7CDFF),
                    .62f to Color(0xFF7E95FF), 1f to Color(0xFF4B3FD0),
                ),
            )
            val cx = size.width * .5f; val cy = -.12f * size.height
            val rx = .7f * size.width; val ry = .6f * size.height
            withTransform({ scale(1f, ry / rx, Offset(cx, cy)) }) {
                drawRect(
                    Brush.radialGradient(
                        0f to Color.White, .30f to Color.White.copy(alpha = .65f), .62f to Color.White.copy(alpha = 0f),
                        center = Offset(cx, cy), radius = rx,
                    ),
                    topLeft = Offset(cx - rx, cy - rx), size = Size(2f * rx, 2f * rx),
                )
            }
        }
        Canvas(Modifier.fillMaxSize().blur((3f * u).dp, BlurredEdgeTreatment.Unbounded)) {
            BACK.forEach { petal(it, 260f, 380f, .5f, k) }
        }
        Canvas(Modifier.fillMaxSize()) {
            FRONT.forEach { petal(it, 175f, 420f, .9f, k) }
            val sx = size.width * .5f; val sy = size.height * .3f
            val rx = .45f * size.width; val ry = .4f * size.height
            withTransform({ scale(1f, ry / rx, Offset(sx, sy)) }) {
                drawRect(
                    Brush.radialGradient(
                        0f to Color.White.copy(alpha = .35f), .70f to Color.White.copy(alpha = 0f),
                        center = Offset(sx, sy), radius = rx,
                    ),
                    topLeft = Offset(sx - rx, sy - rx), size = Size(2f * rx, 2f * rx),
                    blendMode = BlendMode.Softlight,
                )
            }
        }
    }
}
