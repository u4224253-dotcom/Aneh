package com.chordfinder.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Apakah layar aplikasi sedang tampil (diatur MainActivity). Dipakai untuk memutuskan perlu notifikasi "selesai" atau tidak. */
object AppVisibility {
    @Volatile var foreground = false
}

/**
 * Menjaga analisis akor tetap hidup saat aplikasi dipindah ke latar (tanpa ini sistem boleh mematikan prosesnya).
 * Hanya dijalankan oleh [ChordHub] saat island overlay tidak aktif: service overlay sudah foreground sendiri.
 *
 * Service ini tidak menganalisis apa pun; pekerjaannya tetap di [ChordHub]. Di sini hanya notifikasi progres
 * (dengan tombol Batalkan) dan notifikasi hasil kalau selesai saat aplikasi tidak tampil. Berhenti sendiri
 * begitu tidak ada lagi pekerjaan yang berjalan.
 */
class AnalysisService : Service() {

    companion object {
        const val ACTION_CANCEL = "com.chordfinder.island.CANCEL_ANALYSIS"
        private const val CH_PROGRESS = "chordfinder_analysis"
        private const val CH_RESULT = "chordfinder_result"
        private const val NOTIF_ID = 2
        private const val RESULT_ID = 3

        /** Gagal memulai (mis. sistem menolak service foreground dari latar) tidak apa-apa: analisis tetap jalan. */
        fun start(ctx: Context) {
            runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, AnalysisService::class.java)) }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watch: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            ChordHub.cancelCurrent()
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_PROGRESS, "Analisis akor", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_RESULT, "Hasil analisis", NotificationManager.IMPORTANCE_DEFAULT))
        val first = ChordHub.state as? ChordHub.St.Working
        val notif = progressNotification(first?.name ?: "audio", first?.stage ?: ChordHub.STAGE_READ, first?.p ?: 0f)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        watch?.cancel()
        watch = scope.launch {
            while (true) {
                when (val s = ChordHub.state) {
                    is ChordHub.St.Working -> nm.notify(NOTIF_ID, progressNotification(s.name, s.stage, s.p))
                    is ChordHub.St.Done -> { finish(nm, "Analisis akor selesai", s.name, s.segs.size.toString() + " akor ditemukan"); break }
                    is ChordHub.St.Fail -> { finish(nm, "Analisis gagal", s.name, s.msg); break }
                    ChordHub.St.Idle -> break      // dibatalkan
                }
                delay(1000)
            }
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    /** Selesai saat aplikasi tidak tampil: beri tahu lewat notifikasi biasa. Kalau sedang tampil, layarnya sudah cukup. */
    private fun finish(nm: NotificationManager, title: String, name: String, text: String) {
        if (AppVisibility.foreground) return
        val n = NotificationCompat.Builder(this, CH_RESULT)
            .setSmallIcon(R.drawable.ic_stat_island)
            .setContentTitle(title)
            .setContentText("$name · $text")
            .setContentIntent(openApp())
            .setAutoCancel(true)
            .build()
        nm.notify(RESULT_ID, n)
    }

    private fun openApp() = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun progressNotification(name: String, stage: String, p: Float): Notification {
        val cancel = PendingIntent.getService(
            this, 2, Intent(this, AnalysisService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat_island)
            .setContentTitle("Menganalisis akor")
            .setContentText("$name · $stage")
            .setProgress(100, (p * 100f).roundToInt().coerceIn(0, 100), false)
            .setContentIntent(openApp())
            .addAction(0, "Batalkan", cancel)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
