package com.chordfinder.island

import android.graphics.BlurMaskFilter
import android.graphics.RectF
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/** Taruh elemen di titik (x, y) dp dalam parent; (ax, ay) = titik jangkar elemen (0.5 = tengah). */
fun Modifier.placeAt(x: Float, y: Float, ax: Float = .5f, ay: Float = .5f): Modifier =
    this.layout { measurable, c ->
        val p = measurable.measure(Constraints())
        layout(c.maxWidth, c.maxHeight) {
            p.place((x * density - ax * p.width).roundToInt(), (y * density - ay * p.height).roundToInt())
        }
    }

/** Teks island: font sistem (sama dengan system-ui di HTML), ukuran dalam dp tanpa ikut fontScale. */
@Composable
fun CText(
    text: String, x: Float, y: Float, size: Float,
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    weight: FontWeight = FontWeight.Normal,
    ax: Float = .5f, ay: Float = .5f,
    maxW: Float? = null,
) {
    val fs = with(LocalDensity.current) { size.dp.toSp() }
    BasicText(
        text = text,
        modifier = modifier.placeAt(x, y, ax, ay).then(if (maxW != null) Modifier.widthIn(max = maxW.dp) else Modifier),
        style = TextStyle(
            color = color, fontSize = fs, fontWeight = weight, lineHeight = fs * 1.3f,
            lineHeightStyle = LineHeightStyle(
                alignment = LineHeightStyle.Alignment.Center,
                trim = LineHeightStyle.Trim.None,
            ),
        ),
        maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis,
    )
}

/** Panah kiri/kanan (.arw): lingkaran 22 dp, ikon 9 dp. */
@Composable
fun NavArrow(cx: Float, cy: Float, next: Boolean, visible: Boolean, onClick: () -> Unit) {
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(250, easing = Tok.Ease), label = "nav")
    Box(
        Modifier
            .placeAt(cx, cy)
            .size(36.dp)
            .graphicsLayer { alpha = a }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null, enabled = visible, onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(22.dp)) {
            val dn = density
            drawCircle(Color.White.copy(alpha = .28f))
            val p = Path().apply {
                if (next) { moveTo(3.5f, 1.5f); lineTo(7f, 5f); lineTo(3.5f, 8.5f) }
                else { moveTo(6.5f, 1.5f); lineTo(3f, 5f); lineTo(6.5f, 8.5f) }
            }
            withTransform({
                scale(dn, dn, Offset.Zero)
                translate(6.5f, 6.5f)
                scale(.9f, .9f, Offset.Zero)
            }) {
                drawPath(p, Color.White, style = Stroke(width = 2.4f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

/**
 * Cangkang island: bentuk notch + telinga + bayangan, animasi jatuh saat dibuka,
 * dan skala "tegukan" dari GlowController. Ukuran sama untuk semua mode (420 x 96).
 */
@Composable
fun IslandShell(u: Float, glow: GlowController, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val drop = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(200)
        drop.animateTo(1f, tween(900, easing = Tok.Spring))
    }
    val shape = remember { RoundedCornerShape(topStart = 0.dp, topEnd = 0.dp, bottomEnd = Tok.R.dp, bottomStart = Tok.R.dp) }

    Box(
        modifier
            .requiredSize(Tok.W.dp, Tok.H.dp)
            .graphicsLayer {
                glow.frame
                scaleX = u * (1f + .018f * glow.hov + .035f * glow.g)
                scaleY = u * (1f + .035f * glow.hov - .06f * glow.g)
                transformOrigin = TransformOrigin(.5f, 0f)
                translationY = -1.1f * Tok.H * density * u * (1f - drop.value)
            }
            .drawBehind {
                val d = density
                val w = Tok.W * d; val h = Tok.H * d; val e = Tok.E * d; val r = Tok.R * d

                // box-shadow: 0 14px 34px -16px rgba(0,0,0,.95)
                drawIntoCanvas { c ->
                    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = android.graphics.Color.argb(242, 0, 0, 0)
                        maskFilter = BlurMaskFilter(28.6f * d, BlurMaskFilter.Blur.NORMAL)
                    }
                    c.nativeCanvas.drawRoundRect(RectF(16f * d, 30f * d, w - 16f * d, h - 2f * d), 12f * d, 12f * d, paint)
                }

                // telinga kiri & kanan (fillet cekung ke tepi atas layar)
                val left = Path().apply {
                    moveTo(0f, 0f); lineTo(0f, e)
                    arcTo(Rect(-2f * e, 0f, 0f, 2f * e), 0f, -90f, false)
                    close()
                }
                val right = Path().apply {
                    moveTo(w, 0f); lineTo(w, e)
                    arcTo(Rect(w, 0f, w + 2f * e, 2f * e), 180f, 90f, false)
                    close()
                }
                drawPath(left, Color.Black)
                drawPath(right, Color.Black)

                // badan island: sudut atas lurus, sudut bawah membulat
                val body = Path().apply {
                    addRoundRect(
                        RoundRect(
                            left = 0f, top = 0f, right = w, bottom = h,
                            topLeftCornerRadius = CornerRadius.Zero, topRightCornerRadius = CornerRadius.Zero,
                            bottomRightCornerRadius = CornerRadius(r), bottomLeftCornerRadius = CornerRadius(r),
                        ),
                    )
                }
                drawPath(body, Color.Black)
            },
    ) {
        Box(Modifier.fillMaxSize().clip(shape), content = content)
    }
}
