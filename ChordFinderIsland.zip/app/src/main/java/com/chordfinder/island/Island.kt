package com.chordfinder.island

import android.graphics.BlurMaskFilter
import android.graphics.RectF
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.constrainHeight
import androidx.compose.ui.unit.constrainWidth
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Taruh elemen di titik (x, y) dp dalam parent; (ax, ay) = titik jangkar elemen (0.5 = tengah). */
fun Modifier.placeAt(x: Float, y: Float, ax: Float = .5f, ay: Float = .5f): Modifier =
    this.layout { measurable, c ->
        val p = measurable.measure(Constraints())
        layout(c.maxWidth, c.maxHeight) {
            p.place((x * density - ax * p.width).roundToInt(), (y * density - ay * p.height).roundToInt())
        }
    }

/** Teks island: font sistem (sama dengan system-ui di HTML), ukuran dalam dp tanpa ikut fontScale. */
@Composable
fun CText(
    text: String, x: Float, y: Float, size: Float,
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    weight: FontWeight = FontWeight.Normal,
    ax: Float = .5f, ay: Float = .5f,
    maxW: Float? = null,
) {
    val fs = with(LocalDensity.current) { size.dp.toSp() }
    BasicText(
        text = text,
        modifier = modifier.placeAt(x, y, ax, ay).then(if (maxW != null) Modifier.widthIn(max = maxW.dp) else Modifier),
        style = TextStyle(
            color = color, fontSize = fs, fontWeight = weight, lineHeight = fs * 1.3f,
            lineHeightStyle = LineHeightStyle(
                alignment = LineHeightStyle.Alignment.Center,
                trim = LineHeightStyle.Trim.None,
            ),
        ),
        maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis,
    )
}

/** Panah kiri/kanan (.arw): lingkaran 22 dp, ikon 9 dp. */
@Composable
fun NavArrow(cx: Float, cy: Float, next: Boolean, visible: Boolean, onClick: () -> Unit) {
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(250, easing = Tok.Ease), label = "nav")
    Box(
        Modifier
            .placeAt(cx, cy)
            .size(36.dp)
            .graphicsLayer { alpha = a }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null, enabled = visible, onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(22.dp)) {
            val dn = density
            drawCircle(Color.White.copy(alpha = .28f))
            val p = Path().apply {
                if (next) { moveTo(3.5f, 1.5f); lineTo(7f, 5f); lineTo(3.5f, 8.5f) }
                else { moveTo(6.5f, 1.5f); lineTo(3f, 5f); lineTo(6.5f, 8.5f) }
            }
            withTransform({
                scale(dn, dn, Offset.Zero)
                translate(6.5f, 6.5f)
                scale(.9f, .9f, Offset.Zero)
            }) {
                drawPath(p, Color.White, style = Stroke(width = 2.4f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

/** Ukuran dinamis (dp): dipakai supaya perubahan ukuran island hanya menyentuh fase layout, bukan komposisi. */
private fun Modifier.dynSize(w: () -> Float, h: () -> Float): Modifier = this.layout { measurable, c ->
    // Dibulatkan ke genap: pusat island selalu jatuh di piksel yang sama, jadi tidak geter saat ukuran beranimasi.
    val wp = evenPx((w() * density).roundToInt())
    val hp = evenPx((h() * density).roundToInt())
    val p = measurable.measure(Constraints.fixed(wp, hp))
    val rw = c.constrainWidth(wp); val rh = c.constrainHeight(hp)
    // Rata ATAS (y = 0), bukan tengah: kalau jendela overlay lebih pendek dari kotak island, island tidak terdorong ke atas layar.
    layout(rw, rh) { p.place((rw - wp) / 2, 0) }
}

private fun evenPx(v: Int): Int = ((v + 1) / 2) * 2

/**
 * Siluet island lengkap (badan + dua telinga cekung di atas), satu kontur. [left] = x tepi kiri badan,
 * jadi telinga kiri mulai di left - e. Satuan bebas (dp atau px) asal semua argumen sama.
 */
fun islandPath(left: Float, w: Float, h: Float, e: Float, r: Float): Path {
    val bl = left; val br = left + w
    return Path().apply {
        moveTo(bl - e, 0f)
        arcTo(androidx.compose.ui.geometry.Rect(bl - 2f * e, 0f, bl, 2f * e), -90f, 90f, false)
        lineTo(bl, h - r)
        arcTo(androidx.compose.ui.geometry.Rect(bl, h - 2f * r, bl + 2f * r, h), 180f, -90f, false)
        lineTo(br - r, h)
        arcTo(androidx.compose.ui.geometry.Rect(br - 2f * r, h - 2f * r, br, h), 90f, -90f, false)
        lineTo(br, e)
        arcTo(androidx.compose.ui.geometry.Rect(br, 0f, br + 2f * e, 2f * e), 180f, 90f, false)
        close()
    }
}

/** Kotak yang melebar E di kiri dan kanan (area telinga) tanpa mengubah ukuran yang dilaporkan ke parent. */
fun Modifier.bleedEars(): Modifier = this.layout { measurable, c ->
    val ep = (Tok.E * density).roundToInt()
    val p = measurable.measure(Constraints.fixed(c.maxWidth + 2 * ep, c.maxHeight))
    layout(c.maxWidth, c.maxHeight) { p.place(-ep, 0) }
}

private fun lerpF(a: Float, b: Float, t: Float): Float = a + (b - a) * t

/**
 * Cangkang island: bentuk notch + telinga + bayangan, animasi jatuh saat dibuka,
 * dan skala "tegukan" dari GlowController.
 *
 * Ukuran normal 420 x 96. Saat [rest] = true cangkang menciut jadi pil 150 x 30 (mode Resting),
 * lebar/tinggi memakai spring .62 dtk, radius dan telinga .45 dtk (sama dengan transisi .mn di HTML).
 * [content] selalu disusun di kanvas tetap 420 x 96 (rata atas-tengah) dan ikut terpotong cangkang,
 * sedangkan [restContent] mengisi cangkang apa pun ukurannya.
 */
@Composable
fun IslandShell(
    u: Float, glow: GlowController,
    modifier: Modifier = Modifier,
    contentModifier: Modifier = Modifier,   // dipasang di area isi island (gestur geser antar mode, ketuk area kosong)
    shadow: Boolean = true,                 // false di overlay: jendela overlay dipotong rapat, bayangan tidak muat
    rest: Boolean = false,
    restContent: (@Composable BoxScope.() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val drop = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(200)
        drop.animateTo(1f, tween(900, easing = Tok.Spring))
    }

    // 1 = resting, 0 = terbuka penuh
    val sizeAnim = remember { Animatable(if (rest) 1f else 0f) }
    val round = remember { Animatable(if (rest) 1f else 0f) }
    LaunchedEffect(rest) {
        val to = if (rest) 1f else 0f
        launch { sizeAnim.animateTo(to, tween(620, easing = Tok.Spring)) }
        launch { round.animateTo(to, tween(450, easing = Tok.Ease)) }
    }
    // Ukuran kustom (IslandSettings) berlaku di semua mode kecuali Resting: hilang pelan saat menciut ke Resting.
    fun kS() = lerpF(IslandSettings.scale, 1f, sizeAnim.value)
    fun curW() = maxOf(40f, lerpF(Tok.W, Tok.RW, sizeAnim.value))
    fun curH() = maxOf(12f, lerpF(Tok.H, Tok.RH, sizeAnim.value))
    fun curR() = lerpF(Tok.R, Tok.RR, round.value)
    fun curE() = lerpF(Tok.E, Tok.RE, round.value)

    Box(
        modifier
            .dynSize(::curW, ::curH)
            .graphicsLayer {
                glow.frame
                scaleX = u * kS() * (1f + .018f * glow.hov + .035f * glow.g)
                scaleY = u * kS() * (1f + .035f * glow.hov - .06f * glow.g)
                transformOrigin = TransformOrigin(.5f, 0f)
                translationY = -1.1f * curH() * density * u * kS() * (1f - drop.value)
            }
            .drawBehind {
                val d = density
                val w = curW() * d; val h = curH() * d; val e = curE() * d; val r = curR() * d
                translate(left = (size.width - w) / 2f) {   // ukuran layout dibulatkan genap; gambar tetap persis di tengah

                // box-shadow: 0 14px 34px -16px rgba(0,0,0,.95) (hilang sendiri saat island menciut)
                if (shadow && h - 2f * d > 30f * d) drawIntoCanvas { c ->
                    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = android.graphics.Color.argb(242, 0, 0, 0)
                        maskFilter = BlurMaskFilter(28.6f * d, BlurMaskFilter.Blur.NORMAL)
                    }
                    c.nativeCanvas.drawRoundRect(RectF(16f * d, 30f * d, w - 16f * d, h - 2f * d), 12f * d, 12f * d, paint)
                }

                // telinga kiri & kanan (fillet cekung ke tepi atas layar)
                val left = Path().apply {
                    moveTo(0f, 0f); lineTo(0f, e)
                    arcTo(Rect(-2f * e, 0f, 0f, 2f * e), 0f, -90f, false)
                    close()
                }
                val right = Path().apply {
                    moveTo(w, 0f); lineTo(w, e)
                    arcTo(Rect(w, 0f, w + 2f * e, 2f * e), 180f, 90f, false)
                    close()
                }
                drawPath(left, Color.Black)
                drawPath(right, Color.Black)

                // badan island: sudut atas lurus, sudut bawah membulat
                val body = Path().apply {
                    addRoundRect(
                        RoundRect(
                            left = 0f, top = 0f, right = w, bottom = h,
                            topLeftCornerRadius = CornerRadius.Zero, topRightCornerRadius = CornerRadius.Zero,
                            bottomRightCornerRadius = CornerRadius(r), bottomLeftCornerRadius = CornerRadius(r),
                        ),
                    )
                }
                drawPath(body, Color.Black)
                }
            },
    ) {
        Box(
            Modifier
                // Kotak potong selebar siluet (badan + telinga), supaya cahaya dan cincin warna sampai ke lengkungan atas.
                .layout { measurable, c ->
                    val ep = (curE() * density).roundToInt()
                    val wp = evenPx((curW() * density).roundToInt())
                    val hp = evenPx((curH() * density).roundToInt())
                    val p = measurable.measure(Constraints.fixed(wp + 2 * ep, hp))
                    layout(c.constrainWidth(wp), c.constrainHeight(hp)) { p.place(-ep, 0) }
                }
                .graphicsLayer {
                    clip = true
                    val eNow = curE(); val rNow = curR()   // dibaca di sini supaya animasi memicu pembaruan lapisan
                    shape = object : androidx.compose.ui.graphics.Shape {
                        override fun createOutline(
                            size: androidx.compose.ui.geometry.Size,
                            layoutDirection: androidx.compose.ui.unit.LayoutDirection,
                            density: androidx.compose.ui.unit.Density,
                        ): androidx.compose.ui.graphics.Outline {
                            val d = density.density
                            val ep = (eNow * d).roundToInt().toFloat()
                            return androidx.compose.ui.graphics.Outline.Generic(
                                islandPath(ep, size.width - 2f * ep, size.height, ep, rNow * d),
                            )
                        }
                    }
                }
                .then(contentModifier),
        ) {
            Box(Modifier.requiredSize(Tok.W.dp, Tok.H.dp).align(Alignment.TopCenter), content = content)
            restContent?.invoke(this)
        }
    }
}
