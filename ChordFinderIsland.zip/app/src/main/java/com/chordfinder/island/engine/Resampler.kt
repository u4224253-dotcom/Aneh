package com.chordfinder.island.engine

import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Resampler windowed-sinc (jendela Kaiser) fase linear, tanpa delay.
 *
 * Dipakai untuk (1) mengubah sample rate audio ke 22.050 Hz dan (2) membagi dua laju
 * di dalam CQT. Konten musik yang dibutuhkan model ada di bawah ~2,1 kHz, jauh dari tepi
 * Nyquist tiap tahap, jadi filter dirancang datar sampai 80% Nyquist keluaran dengan
 * redaman besar (>100 dB) mulai 100% Nyquist; tidak perlu meniru soxr_hq sampai ke tepi.
 */
object Resampler {
    private const val BETA = 10.0
    private const val PHASES = 512
    private const val PASSBAND_END = 0.8

    private class Kernel(val halfLen: Int, val taps: Int, val table: FloatArray)

    private val cache = HashMap<Long, Kernel>()

    private fun bessel0(x: Double): Double {
        var sum = 1.0
        var term = 1.0
        val q = x * x / 4.0
        var k = 1
        while (term > 1e-14 * sum) {
            term *= q / (k.toDouble() * k)
            sum += term
            k++
        }
        return sum
    }

    private fun kernel(srcRate: Int, dstRate: Int): Kernel = synchronized(cache) {
        val key = (srcRate.toLong() shl 32) or dstRate.toLong()
        cache.getOrPut(key) {
            val ratio = dstRate.toDouble() / srcRate
            val lp = min(1.0, ratio)
            // cutoff (siklus per sampel masukan): tepat di tengah zona transisi 0.8..1.0 Nyquist keluaran
            val fc = 0.5 * lp * (PASSBAND_END + 1.0) / 2.0
            val halfLen = ceil(31.0 / lp).toInt()
            val taps = 2 * halfLen
            val table = FloatArray((PHASES + 1) * taps)
            val i0Beta = bessel0(BETA)
            for (p in 0..PHASES) {
                val frac = p.toDouble() / PHASES
                var sum = 0.0
                val row = DoubleArray(taps)
                for (j in 0 until taps) {
                    val d = (j - halfLen + 1) - frac
                    val u = d / halfLen
                    val win = if (u <= -1.0 || u >= 1.0) 0.0 else bessel0(BETA * sqrt(1.0 - u * u)) / i0Beta
                    val x = 2.0 * fc * d
                    val s = if (x == 0.0) 1.0 else sin(PI * x) / (PI * x)
                    row[j] = 2.0 * fc * s * win
                    sum += row[j]
                }
                for (j in 0 until taps) table[p * taps + j] = (row[j] / sum).toFloat()
            }
            Kernel(halfLen, taps, table)
        }
    }

    /**
     * @param energyScale true = kalikan sqrt(srcRate/dstRate) agar energi sinyal terjaga
     *                    (sama dengan librosa.resample(scale=True)).
     */
    fun resample(x: FloatArray, srcRate: Int, dstRate: Int, energyScale: Boolean = false): FloatArray {
        if (srcRate == dstRate) return x.copyOf()
        val k = kernel(srcRate, dstRate)
        val taps = k.taps
        val halfLen = k.halfLen
        val table = k.table
        val nOut = ceil(x.size.toDouble() * dstRate / srcRate).toInt()
        val out = FloatArray(nOut)
        val gain = if (energyScale) sqrt(srcRate.toDouble() / dstRate).toFloat() else 1f
        val n = x.size
        for (o in 0 until nOut) {
            // posisi keluaran o di sumbu masukan; interpolasi linear antar-fase tabel
            val pos = o.toDouble() * srcRate / dstRate
            val i0 = floor(pos).toInt()
            val pf = (pos - i0) * PHASES
            val p = pf.toInt()
            val w1 = (pf - p).toFloat()
            val w0 = 1f - w1
            val r0 = p * taps
            val r1 = r0 + taps
            val base = i0 - halfLen + 1
            var acc = 0f
            if (base >= 0 && base + taps <= n) {
                for (j in 0 until taps) acc += x[base + j] * (table[r0 + j] * w0 + table[r1 + j] * w1)
            } else {
                for (j in 0 until taps) {
                    val idx = base + j
                    if (idx in 0 until n) acc += x[idx] * (table[r0 + j] * w0 + table[r1 + j] * w1)
                }
            }
            out[o] = acc * gain
        }
        return out
    }

    /** Bagi dua laju sampel, skala energi seperti librosa.resample(orig_sr=2, target_sr=1, scale=True). */
    fun halve(x: FloatArray): FloatArray = resample(x, 2, 1, energyScale = true)
}
