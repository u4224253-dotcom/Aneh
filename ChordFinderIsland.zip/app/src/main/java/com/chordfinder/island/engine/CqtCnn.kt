package com.chordfinder.island.engine

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sqrt

/**
 * CQT untuk model CNN+LSTM ChordMini: tiruan librosa.hybrid_cqt
 * (22.050 Hz, hop 512, 36 bin/oktaf, fmin F#0, 288 bin, tuning tetap).
 * Semua basis sparse dibaca dari cnn.lkm (dibangun tools/cqt_cnn_plan.py).
 *
 *  - Bagian PENUH (bin 0 sampai nFull-1): resample bagi-dua (awal + antar-oktaf), per oktaf STFT
 *    jendela kotak -> proyeksi basis kompleks sparse -> magnitudo.
 *  - Bagian PSEUDO (bin nFull sampai 287): satu STFT jendela Hann di laju penuh, |D| diproyeksikan
 *    ke basis real sparse.
 *  - Keluaran LINEAR |CQT| (BUKAN log). Jaringan hanya memakai bin 18..269 -> [netInput].
 */
internal class CqtCnn(lkm: LkmFile) {

    /** data[t * nBins + bin], bin 0..287. */
    class Result(val data: FloatArray, val frames: Int, val nBins: Int)

    private class Octave(
        val hop: Int,
        val nFft: Int,
        val firstBin: Int,
        val nBins: Int,
        val halveAfter: Boolean,
        val indptr: IntArray,
        val indices: IntArray,
        val re: FloatArray,
        val im: FloatArray,
    )

    private class Pseudo(
        val nFft: Int,
        val nBins: Int,
        val firstBin: Int,
        val indptr: IntArray,
        val indices: IntArray,
        val w: FloatArray,
    )

    val sampleRate: Int
    val hop: Int
    val nBins: Int
    val tuning: Float
    private val earlyDown: Int
    private val octaves: List<Octave>
    private val pseudo: Pseudo?
    private val ffts = HashMap<Int, Fft>() // diisi di init saja -> aman dibaca banyak thread
    private val hann: FloatArray

    init {
        // [early_down, n_oktaf, n_bin, n_penuh, n_pseudo, hop, sr, bin/oktaf]
        val m = lkm.ints("cqt.meta")
        earlyDown = m[0]
        val nOct = m[1]
        nBins = m[2]
        val nFull = m[3]
        val nPseudo = m[4]
        hop = m[5]
        sampleRate = m[6]
        tuning = lkm.tensor("cqt.tuning").data[0]
        require(nFull + nPseudo == nBins) { "Meta CQT tidak konsisten" }

        octaves = List(nOct) { i ->
            val om = lkm.ints("cqt.o$i.meta") // [hop, n_fft, first_bin, n_bin, halve_after]
            val o = Octave(
                hop = om[0], nFft = om[1], firstBin = om[2], nBins = om[3], halveAfter = om[4] != 0,
                indptr = lkm.ints("cqt.o$i.indptr"), indices = lkm.ints("cqt.o$i.indices"),
                re = lkm.tensor("cqt.o$i.re").data, im = lkm.tensor("cqt.o$i.im").data,
            )
            require(o.indptr.size == o.nBins + 1) { "Plan CQT rusak (indptr oktaf $i)" }
            require(o.re.size == o.indices.size && o.im.size == o.indices.size) { "Plan CQT rusak (data oktaf $i)" }
            for (c in o.indices) require(c in 0..o.nFft / 2) { "Plan CQT rusak (kolom oktaf $i)" }
            o
        }
        // oktaf harus menutup bin 0 sampai nFull-1 tanpa celah (urut dari atas ke bawah)
        var covered = 0
        for (o in octaves) covered += o.nBins
        require(covered == nFull) { "Oktaf CQT tidak menutup $nFull bin (hanya $covered)" }

        pseudo = if (nPseudo > 0) {
            val pm = lkm.ints("cqt.p.meta") // [n_fft, n_bin, first_bin]
            val p = Pseudo(
                nFft = pm[0], nBins = pm[1], firstBin = pm[2],
                indptr = lkm.ints("cqt.p.indptr"), indices = lkm.ints("cqt.p.indices"),
                w = lkm.tensor("cqt.p.w").data,
            )
            require(p.nBins == nPseudo && p.firstBin == nFull) { "Plan pseudo-CQT tidak cocok" }
            require(p.indptr.size == p.nBins + 1 && p.w.size == p.indices.size) { "Plan pseudo-CQT rusak" }
            for (c in p.indices) require(c in 0..p.nFft / 2) { "Plan pseudo-CQT rusak (kolom)" }
            p
        } else null

        for (o in octaves) ffts.getOrPut(o.nFft) { Fft(o.nFft) }
        pseudo?.let { p -> ffts.getOrPut(p.nFft) { Fft(p.nFft) } }
        val nh = pseudo?.nFft ?: 2
        // Hann periodik (seperti scipy.signal.get_window('hann', N, fftbins=True))
        hann = FloatArray(nh) { (0.5 - 0.5 * cos(2.0 * PI * it / nh)).toFloat() }
    }

    /**
     * @param y audio mono 22.050 Hz
     * @param onProgress 0..1
     */
    fun compute(y: FloatArray, onProgress: ((Float) -> Unit)? = null): Result {
        require(y.isNotEmpty()) { "Audio kosong" }

        // jumlah frame tiap bagian dihitung dulu (tanpa memproses sinyal), lalu diambil yang terkecil
        var len = if (earlyDown > 1) ceilDiv(y.size, earlyDown) else y.size
        var frames = Int.MAX_VALUE
        for (o in octaves) {
            frames = min(frames, 1 + len / o.hop)
            if (o.halveAfter) len = ceilDiv(len, 2)
        }
        if (pseudo != null) frames = min(frames, 1 + y.size / hop)

        val out = FloatArray(frames * nBins)
        val steps = octaves.size + (if (pseudo != null) 1 else 0)
        var done = 0

        var cur = if (earlyDown > 1) Resampler.resample(y, earlyDown, 1, energyScale = true) else y
        for (o in octaves) {
            fillOctave(cur, o, frames, out)
            onProgress?.invoke(++done / steps.toFloat())
            if (o.halveAfter) cur = Resampler.halve(cur)
        }
        if (pseudo != null) {
            fillPseudo(y, pseudo, frames, out)
            onProgress?.invoke(++done / steps.toFloat())
        }
        return Result(out, frames, nBins)
    }

    /** STFT kotak (center, pad nol) + proyeksi basis kompleks sparse -> |respon|. */
    private fun fillOctave(sig: FloatArray, o: Octave, frames: Int, out: FloatArray) {
        val fft = ffts.getValue(o.nFft)
        val half = o.nFft / 2
        val re = FloatArray(o.nFft)
        val im = FloatArray(o.nFft)
        val n = sig.size
        for (t in 0 until frames) {
            val start = t * o.hop - half
            if (start >= 0 && start + o.nFft <= n) {
                System.arraycopy(sig, start, re, 0, o.nFft)
            } else {
                for (i in 0 until o.nFft) {
                    val idx = start + i
                    re[i] = if (idx in 0 until n) sig[idx] else 0f
                }
            }
            im.fill(0f)
            fft.transform(re, im)
            val base = t * nBins + o.firstBin
            for (r in 0 until o.nBins) {
                var ar = 0f
                var ai = 0f
                for (k in o.indptr[r] until o.indptr[r + 1]) {
                    val c = o.indices[k]
                    ar += o.re[k] * re[c] - o.im[k] * im[c]
                    ai += o.re[k] * im[c] + o.im[k] * re[c]
                }
                out[base + r] = sqrt(ar * ar + ai * ai)
            }
        }
    }

    /** STFT jendela Hann di laju penuh, |D| diproyeksikan ke basis real sparse. */
    private fun fillPseudo(y: FloatArray, p: Pseudo, frames: Int, out: FloatArray) {
        val fft = ffts.getValue(p.nFft)
        val half = p.nFft / 2
        val re = FloatArray(p.nFft)
        val im = FloatArray(p.nFft)
        val mag = FloatArray(half + 1)
        val n = y.size
        for (t in 0 until frames) {
            val start = t * hop - half
            for (i in 0 until p.nFft) {
                val idx = start + i
                re[i] = if (idx in 0 until n) y[idx] * hann[i] else 0f
            }
            im.fill(0f)
            fft.transform(re, im)
            for (c in 0..half) mag[c] = sqrt(re[c] * re[c] + im[c] * im[c])
            val base = t * nBins + p.firstBin
            for (r in 0 until p.nBins) {
                var acc = 0f
                for (k in p.indptr[r] until p.indptr[r + 1]) acc += p.w[k] * mag[p.indices[k]]
                out[base + r] = acc
            }
        }
    }

    private fun ceilDiv(a: Int, b: Int) = (a + b - 1) / b

    companion object {
        /** Jaringan memakai bin 18..269 dari 288 (slice 18:270 di source asli). */
        const val FIRST_BIN = 18
        const val NET_BINS = 252

        /** Ambil 252 bin yang dipakai jaringan: [frame * 252 + bin]. */
        fun netInput(r: Result): FloatArray {
            val out = FloatArray(r.frames * NET_BINS)
            for (t in 0 until r.frames) {
                System.arraycopy(r.data, t * r.nBins + FIRST_BIN, out, t * NET_BINS, NET_BINS)
            }
            return out
        }
    }
}
