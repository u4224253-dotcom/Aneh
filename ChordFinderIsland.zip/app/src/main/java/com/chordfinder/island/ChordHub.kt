package com.chordfinder.island

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.chordfinder.island.engine.AudioDecoder
import com.chordfinder.island.engine.BeatThisEngine
import com.chordfinder.island.engine.CnnChordEngine
import com.chordfinder.island.engine.NativeCnn
import com.chordfinder.island.engine.Resampler
import com.chordfinder.island.engine.chordName
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch

/**
 * Pusat hasil analisis akor. Satu untuk seluruh proses, bukan per island: island di dalam app dan island
 * overlay punya [IslandState] sendiri-sendiri, tapi mesin dan hasilnya cukup satu.
 *
 * Satu pekerjaan pada satu waktu (mesin tidak aman dipakai paralel). Pekerjaan baru membatalkan yang lama
 * dan menunggunya benar-benar berhenti dulu. Setiap pekerjaan punya nomor tiket supaya island hanya
 * bereaksi pada hasil miliknya sendiri.
 */
object ChordHub {
    /** Satu akor: dimulai di [start] detik, berakhir di [end]; [label] mentah dari model, [name] siap tampil. */
    class Seg(val start: Double, val end: Double, val label: String, val name: String)

    sealed class St(val id: Int) {
        object Idle : St(0)
        class Working(id: Int, val name: String, val stage: String, val p: Float, val etaSec: Float?) : St(id)
        /** [bpm] null kalau model tempo tidak ada, gagal, atau beat terlalu sedikit. */
        class Done(id: Int, val name: String, val segs: List<Seg>, val dur: Double, val bpm: Double? = null) : St(id)
        class Fail(id: Int, val name: String, val msg: String) : St(id)
    }

    /** State Compose: boleh dibaca langsung dari UI, boleh ditulis dari thread latar. */
    var state: St by mutableStateOf<St>(St.Idle)
        private set

    const val STAGE_READ = "Membaca audio…"
    const val STAGE_MODEL = "Memuat model…"
    const val STAGE_FIND = "Mencari akor…"
    const val STAGE_TIDY = "Merapikan hasil…"
    const val STAGE_TEMPO = "Menghitung tempo…"

    /** "128" bila hampir bulat, selain itu satu desimal berkoma ("115,4"). */
    fun bpmText(b: Double): String {
        val r = Math.round(b)
        return if (kotlin.math.abs(b - r) < 0.05) r.toString() else String.format(java.util.Locale.US, "%.1f", b).replace('.', ',')
    }

    /** File milik pekerjaan terakhir (selama belum dibatalkan). Dipakai island baru untuk menyambung ke pekerjaan yang masih hidup. */
    @Volatile var current: PickedAudio? = null
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var ticket = 0
    private var engine: CnnChordEngine? = null
    private var beat: BeatThisEngine? = null
    private var beatTried = false

    /** Model tempo opsional (assets/beat_this.onnx); null kalau tidak ada. Dicoba sekali per proses. */
    @Synchronized
    private fun beatEngine(app: Context): BeatThisEngine? {
        if (!beatTried) { beat = BeatThisEngine.load(app.assets); beatTried = true }
        return beat
    }

    /** Mulai menganalisis [info]; mengembalikan nomor tiket pekerjaan ini. */
    @Synchronized
    fun start(ctx: Context, info: PickedAudio): Int {
        val app = ctx.applicationContext
        val my = ++ticket
        val prev = job
        current = info
        state = St.Working(my, info.name, STAGE_READ, 0f, null)
        // Island overlay (service foreground) sudah menjaga proses tetap hidup; selain itu butuh penjaga sendiri.
        if (!IslandService.active) AnalysisService.start(app)
        job = scope.launch {
            prev?.cancelAndJoin()
            work(app, info, my)
        }
        return my
    }

    /** Batalkan pekerjaan [id] (dan hapus hasilnya). Tiket lain tidak disentuh. */
    @Synchronized
    fun cancel(id: Int) {
        if (id == 0 || id != ticket) return
        ticket++                       // tiket berikutnya: callback pekerjaan lama tahu dirinya sudah dibatalkan
        job?.cancel()
        current = null
        state = St.Idle
    }

    /** Batalkan pekerjaan yang sedang berjalan, siapa pun pemiliknya (mis. dari tombol di notifikasi). */
    fun cancelCurrent() = cancel(ticket)

    private fun alive(my: Int) = my == ticket

    private suspend fun work(app: Context, info: PickedAudio, my: Int) {
        val cur = currentCoroutineContext()[Job]
        val cancelled = { !alive(my) || cur?.isActive == false }
        val t0 = System.nanoTime()
        var tFind = 0L
        var lastP = -1f

        fun report(stage: String, p: Float) {
            if (!alive(my)) return
            if (p - lastP < 0.005f && p < 1f) return
            lastP = p
            var eta: Float? = null
            if (p >= 0.25f) {
                if (tFind == 0L) tFind = System.nanoTime()
                val el = (System.nanoTime() - tFind) / 1e9f
                if (el > 1.5f) eta = el * (1f - p) / (p - 0.2f)
            }
            state = St.Working(my, info.name, stage, p, eta)
        }

        val result: St = try {
            val pcm = AudioDecoder.decodeMono(app, info.uri, cancelled) { report(STAGE_READ, it * 0.2f) }
            report(STAGE_MODEL, 0.2f)
            val eng = engine ?: app.assets.open("cnn.lkm").use { CnnChordEngine.load(it) }.also { engine = it }
            val beatEng = beatEngine(app)
            val dur = pcm.samples.size.toDouble() / pcm.sampleRate.coerceAtLeast(1)
            // satu kali resample ke 22.050 Hz dipakai bersama oleh mesin akor dan mesin tempo
            val y = if (pcm.sampleRate == CnnChordEngine.SAMPLE_RATE) pcm.samples
            else Resampler.resample(pcm.samples, pcm.sampleRate, CnnChordEngine.SAMPLE_RATE)
            val chordShare = if (beatEng != null) 0.65f else 0.8f      // sisanya untuk tempo
            val res = eng.analyze(y, CnnChordEngine.SAMPLE_RATE) { p ->
                if (cancelled()) throw CancellationException("dibatalkan")
                report(if (p >= 0.95f) STAGE_TIDY else STAGE_FIND, 0.2f + chordShare * p)
            }
            android.util.Log.i("ChordHub", "analisis selesai ${(System.nanoTime() - t0) / 1_000_000} ms, CNN native=${NativeCnn.available}")
            var bpm: Double? = null
            if (beatEng != null) {
                val t1 = System.nanoTime()
                bpm = try {
                    val base = 0.2f + chordShare
                    beatEng.analyze(y, CnnChordEngine.SAMPLE_RATE) { p ->
                        if (cancelled()) throw CancellationException("dibatalkan")
                        report(STAGE_TEMPO, base + (1f - base) * p)
                    }.bpm
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    android.util.Log.w("ChordHub", "tempo gagal (hasil akor tetap dipakai)", e)
                    null
                }
                android.util.Log.i("ChordHub", "tempo ${(System.nanoTime() - t1) / 1_000_000} ms, bpm=$bpm")
            }
            // model selalu menyisakan satu segmen kosong (0 detik) di awal: dibuang
            val segs = res.segments
                .filter { it.end - it.start > 1e-6 }
                .map { Seg(it.start, it.end, it.label, chordName(it.label)) }
            St.Done(my, info.name, segs, dur, bpm)
        } catch (e: CancellationException) {
            currentCoroutineContext().ensureActive()   // coroutine-nya yang dibatalkan: teruskan
            return                                     // dibatalkan lewat tiket: state sudah diurus cancel()
        } catch (e: OutOfMemoryError) {
            St.Fail(my, info.name, "Memori HP tidak cukup untuk audio ini")
        } catch (e: Throwable) {
            St.Fail(my, info.name, friendly(e))
        }
        synchronized(this) { if (alive(my)) state = result }
    }

    /** Pesan singkat (muat di zona upload island). */
    private fun friendly(e: Throwable): String {
        val m = e.message.orEmpty()
        return when {
            m.contains("terlalu panjang", true) -> "Audio terlalu panjang (maks 20 menit)"
            m.contains("trek audio", true) -> "File ini tidak punya trek audio"
            else -> "Gagal menganalisis audio"
        }
    }
}
