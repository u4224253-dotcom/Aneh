package com.chordfinder.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

/**
 * Island di luar aplikasi: jendela overlay (TYPE_APPLICATION_OVERLAY) yang menempel di tepi atas layar,
 * dijalankan service foreground sehingga tetap ada walau aplikasi ditutup / di-swipe dari recent.
 */
class IslandService : Service() {

    companion object {
        /** true selama island overlay tampil (dibaca layar aplikasi untuk menyembunyikan island di dalamnya). */
        var active by mutableStateOf(false); private set

        const val ACTION_STOP = "com.chordfinder.island.STOP"
        private const val CHANNEL_ID = "chordfinder_island"
        private const val NOTIF_ID = 1

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, IslandService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, IslandService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var view: ComposeView? = null
    private var owner: OverlayOwner? = null

    /** Skala island (sama seperti fit() di HTML), dihitung dari sisi layar yang pendek. */
    private var u by mutableFloatStateOf(1f)
    private var density = 1f

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) { relayout() }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
            .registerDisplayListener(displayListener, handler)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        showIsland()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
            .unregisterDisplayListener(displayListener)
        removeIsland()
        super.onDestroy()
    }

    // ---- Jendela overlay --------------------------------------------------------------------

    private fun showIsland() {
        if (view != null) return
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }

        measureScreen()
        val o = OverlayOwner()
        o.create()
        val cv = ComposeView(this)
        o.attachTo(cv)
        cv.setContent {
            OverlayIsland(
                u = u,
                onPick = {
                    startActivity(
                        Intent(this, PickerActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION),
                    )
                },
            )
        }
        o.resume()
        val ok = runCatching { wm.addView(cv, layoutParams()) }.isSuccess
        if (!ok) {
            o.destroy()
            stopSelf()
            return
        }
        owner = o
        view = cv
        active = true
    }

    private fun removeIsland() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        owner?.destroy()
        owner = null
        active = false
    }

    /** Layar berputar atau ukuran berubah: hitung ulang skala dan ukuran jendela. */
    private fun relayout() {
        val v = view ?: return
        measureScreen()
        runCatching { wm.updateViewLayout(v, layoutParams()) }
    }

    @Suppress("DEPRECATION")
    private fun measureScreen() {
        val dm = DisplayMetrics()
        val display = (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        display.getRealMetrics(dm)
        density = dm.density
        val shortDp = minOf(dm.widthPixels, dm.heightPixels) / dm.density
        u = ((shortDp - 12f) / 470f).coerceIn(.55f, 1.3f)
    }

    private fun layoutParams(): WindowManager.LayoutParams {
        // lebar = island 420 dp + telinga 20 dp kiri-kanan; tinggi = island + sedikit ruang untuk efek "tegukan"
        val w = ((Tok.W + 2f * Tok.E) * u * density).roundToInt() + 2
        val h = (Tok.H * u * 1.06f * density).roundToInt() + 2
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // bisa disentuh, tapi tidak mengambil fokus keyboard dan tidak menghalangi sentuhan di luar jendela
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.x = 0
        lp.y = 0   // menempel di tepi atas layar
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    // ---- Notifikasi foreground ---------------------------------------------------------------

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, IslandService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_island)
            .setContentTitle("Chord Finder aktif")
            .setContentText("Island tampil di atas aplikasi lain")
            .setContentIntent(open)
            .addAction(0, "Tutup island", stop)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Chord Finder", NotificationManager.IMPORTANCE_MIN),
        )
        val notif = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }
}

/** Isi jendela overlay: island dengan state sendiri, menempel di tengah-atas jendela. */
@Composable
private fun OverlayIsland(u: Float, onPick: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val st = remember { IslandState(ctx.applicationContext, scope) }
    DisposableEffect(st) {
        IslandBridge.state = st
        onDispose {
            if (IslandBridge.state === st) IslandBridge.state = null
            st.release()
        }
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        IslandBody(st, u, onPick = onPick, shadow = false)
    }
}
