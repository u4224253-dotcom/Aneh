package com.chordfinder.island.engine

/** Satu segmen akor: [start, end) dalam detik. [label] = label mentah model, mis. "Db:maj7" atau "N". */
class ChordSegment(val start: Double, val end: Double, val label: String) {
    override fun toString() = "%.3f %.3f %s".format(start, end, label)
}

/** Hasil analisis: timeline akor + indeks kelas per frame + lama satu frame (detik). */
class ChordAnalysis(val segments: List<ChordSegment>, val frameIndices: IntArray, val frameDuration: Double)
