package com.chordfinder.island

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Fisika cahaya "Island gulp" — port dari makeGlow() di versi HTML. */
class GlowController {
    var hov = 0f; var hv = 0f
    var dropT = -1f
    var dx = Tok.W / 2f; var cx = Tok.W / 2f
    var g = 0f; var gv = 0f
    var hot = false
    var t = 0f                                   // waktu animasi air
    var wl = 0f; var wt = 0f                     // tinggi air (sekarang / target)
    var wOn = false; var wA = 0f                 // air menyala / opasitas air
    var frame by mutableIntStateOf(0)
    var wake by mutableIntStateOf(0)

    fun hot(on: Boolean) { hot = on; wake++ }
    fun move(x: Float) { cx = shCl(x, 0f, Tok.W) }
    fun drop() { hot = false; dx = cx; dropT = 0f; gv = 7.7f; wake++ }

    fun waterStart() { wl = 0f; wt = 0f; wOn = true; wake++ }
    fun waterLevel(p: Float) { wt = p }
    fun waterStop() { wOn = false; wake++ }
    fun reset() {
        hot = false; hov = 0f; hv = 0f; dropT = -1f; g = 0f; gv = 0f
        wl = 0f; wt = 0f; wOn = false; wA = 0f
        frame++
    }

    fun busy(): Boolean = hot || hov > .002f || dropT >= 0f || abs(g) > .001f || abs(gv) > .01f || wOn || wA > .004f

    fun step(dt: Float) {
        hv += (50f * ((if (hot) 1f else 0f) - hov) - 14f * hv) * dt
        hov = shCl(hov + hv * dt, 0f, 1.04f)
        gv += (-60f * g - 6f * gv) * dt
        g += gv * dt
        if (dropT >= 0f) { dropT += dt * 0.7f; if (dropT >= 2f) dropT = -1f }
        t += dt
        wl += (wt - wl) * min(1f, dt * 6f)
        wA += ((if (wOn) 1f else 0f) - wA) * min(1f, dt * (if (wOn) 4f else 1.5f))
    }

    fun settle() { hov = 0f; hv = 0f; g = 0f; gv = 0f }
}

@Composable
fun GlowLoop(glow: GlowController) {
    LaunchedEffect(glow.wake) {
        var last = withFrameNanos { it }
        while (glow.busy()) {
            val now = withFrameNanos { it }
            val dt = min(0.05f, (now - last) / 1_000_000_000f)
            last = now
            glow.step(dt)
            glow.frame++
        }
        glow.settle()
        glow.frame++
    }
}

/** Gambar dalam satuan 420 x 96 (sama seperti canvas HTML). Wajib dipakai di layer Offscreen. */
fun DrawScope.drawIslandGlow(s: GlowController) {
    val w = Tok.W; val h = Tok.H
    scale(density, density, Offset.Zero) {
        val full = Size(w, h)
        val d = s.dropT
        val rise = if (d >= 0f && d < 1.1f) sin(shSm(d / 1.1f) * PI).toFloat() else 0f
        val fade = if (d >= 0f) (if (d < .9f) 1f else 1f - shSm((d - .9f) / 1.1f)) else 1f
        val base = (.26f * s.hov + .34f * rise) * fade
        val pool = (.42f * s.hov + .28f * rise) * fade

        if (base > .004f) {
            drawRect(
                brush = Brush.horizontalGradient(
                    0f to rgba(Tok.Pal[0], base), .5f to rgba(Tok.Pal[1], base), 1f to rgba(Tok.Pal[2], base),
                    startX = 0f, endX = w,
                ),
                size = full,
            )
        }

        val px = if (d >= 0f) s.dx else s.cx
        if (pool > .004f) {
            val col = shMix(px / w)
            val light = IntArray(3) { min(255, col[it] + 51) }
            val r = 170f + 60f * rise
            drawRect(
                brush = Brush.radialGradient(
                    0f to rgba(light, pool), .55f to rgba(col, pool * .45f), 1f to rgba(col, 0f),
                    center = Offset(px, h + 18f), radius = r,
                ),
                size = full,
            )
        }

        if (d >= 0f && d < 1.4f) {
            val q = 1f - (1f - d / 1.4f).pow(3)
            val r = 24f + 430f * q
            val ww = 30f
            val a = .22f * (1f - q)
            val outer = r + ww
            val t0 = max(0f, r - ww) / outer
            val mid = t0 + (1f - t0) * .5f
            val c0 = rgba(200, 236, 255, 0f)
            drawRect(
                brush = Brush.radialGradient(
                    0f to c0, t0 to c0, mid to rgba(200, 236, 255, a), 1f to c0,
                    center = Offset(px, h - 14f), radius = outer,
                ),
                size = full,
            )
        }

        // cahaya memudar ke atas (destination-in)
        drawRect(
            brush = Brush.verticalGradient(
                0f to Color.Black.copy(alpha = 0f), .22f to Color.Black.copy(alpha = .08f),
                .58f to Color.Black.copy(alpha = .55f), 1f to Color.Black,
                startY = 0f, endY = h,
            ),
            size = full,
            blendMode = BlendMode.DstIn,
        )

        // air naik (mode analisis): dua gelombang + kilap permukaan
        if (s.wA > .004f) drawWater(s)
    }
}

/** Satu gelombang air (satuan 420 x 96). close = true untuk isian, false untuk garis permukaan. */
private fun waterWave(s: GlowController, len: Float, ph: Float, amp: Float, off: Float, close: Boolean): Path {
    val w = Tok.W; val h = Tok.H
    val base = (h + 8f) - s.wl * (h + 16f) + off
    val k = (2.0 * PI / (w * len)).toFloat()
    val p = Path()
    if (close) p.moveTo(0f, h + 2f)
    var x = 0f
    while (x <= w) {
        val y = base + sin(x * k + ph) * amp + sin(x * k * 2.3f - ph * .7f) * amp * .35f
        if (!close && x == 0f) p.moveTo(x, y) else p.lineTo(x, y)
        x += 5f
    }
    if (close) { p.lineTo(w, h + 2f); p.close() }
    return p
}

private fun DrawScope.drawWater(s: GlowController) {
    val w = Tok.W; val h = Tok.H
    val a = s.wA; val t = s.t
    val top = (h + 8f) - s.wl * (h + 16f)
    for (i in 0..1) {
        val la = if (i == 0) .34f else .46f
        val len = if (i == 0) .55f else .36f
        val ph = if (i == 0) t * 1.1f else -t * 1.7f + 1.3f
        val amp = if (i == 0) 4.4f else 3.4f
        val off = if (i == 0) 0f else 2.5f
        val fill = waterWave(s, len, ph, amp, off, true)
        drawPath(
            fill,
            Brush.horizontalGradient(
                0f to rgba(Tok.Pal[0], la * a), .5f to rgba(Tok.Pal[1], la * a), 1f to rgba(Tok.Pal[2], la * a),
                startX = 0f, endX = w,
            ),
        )
        if (i == 1) {
            drawPath(
                fill,
                Brush.verticalGradient(
                    0f to rgba(210, 240, 255, .30f * a), 1f to rgba(210, 240, 255, 0f),
                    startY = top - 6f, endY = min(h, top + 46f),
                ),
            )
            drawPath(waterWave(s, len, ph, amp, off, false), rgba(200, 236, 255, .55f * a), style = Stroke(width = 1.2f))
        }
    }
}
