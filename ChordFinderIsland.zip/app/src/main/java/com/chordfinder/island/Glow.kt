package com.chordfinder.island

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.scale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Fisika cahaya "Island gulp" — port dari makeGlow() di versi HTML. */
class GlowController {
    var hov = 0f; var hv = 0f
    var dropT = -1f
    var dx = Tok.W / 2f; var cx = Tok.W / 2f
    var g = 0f; var gv = 0f
    var hot = false
    var frame by mutableIntStateOf(0)
    var wake by mutableIntStateOf(0)

    fun hot(on: Boolean) { hot = on; wake++ }
    fun move(x: Float) { cx = shCl(x, 0f, Tok.W) }
    fun drop() { hot = false; dx = cx; dropT = 0f; gv = 7.7f; wake++ }

    fun busy(): Boolean = hot || hov > .002f || dropT >= 0f || abs(g) > .001f || abs(gv) > .01f

    fun step(dt: Float) {
        hv += (50f * ((if (hot) 1f else 0f) - hov) - 14f * hv) * dt
        hov = shCl(hov + hv * dt, 0f, 1.04f)
        gv += (-60f * g - 6f * gv) * dt
        g += gv * dt
        if (dropT >= 0f) { dropT += dt * 0.7f; if (dropT >= 2f) dropT = -1f }
    }

    fun settle() { hov = 0f; hv = 0f; g = 0f; gv = 0f }
}

@Composable
fun GlowLoop(glow: GlowController) {
    LaunchedEffect(glow.wake) {
        var last = withFrameNanos { it }
        while (glow.busy()) {
            val now = withFrameNanos { it }
            val dt = min(0.05f, (now - last) / 1_000_000_000f)
            last = now
            glow.step(dt)
            glow.frame++
        }
        glow.settle()
        glow.frame++
    }
}

/** Gambar dalam satuan 420 x 96 (sama seperti canvas HTML). Wajib dipakai di layer Offscreen. */
fun DrawScope.drawIslandGlow(s: GlowController) {
    val w = Tok.W; val h = Tok.H
    scale(density, density, Offset.Zero) {
        val full = Size(w, h)
        val d = s.dropT
        val rise = if (d >= 0f && d < 1.1f) sin(shSm(d / 1.1f) * PI).toFloat() else 0f
        val fade = if (d >= 0f) (if (d < .9f) 1f else 1f - shSm((d - .9f) / 1.1f)) else 1f
        val base = (.26f * s.hov + .34f * rise) * fade
        val pool = (.42f * s.hov + .28f * rise) * fade

        if (base > .004f) {
            drawRect(
                brush = Brush.horizontalGradient(
                    0f to rgba(Tok.Pal[0], base), .5f to rgba(Tok.Pal[1], base), 1f to rgba(Tok.Pal[2], base),
                    startX = 0f, endX = w,
                ),
                size = full,
            )
        }

        val px = if (d >= 0f) s.dx else s.cx
        if (pool > .004f) {
            val col = shMix(px / w)
            val light = IntArray(3) { min(255, col[it] + 51) }
            val r = 170f + 60f * rise
            drawRect(
                brush = Brush.radialGradient(
                    0f to rgba(light, pool), .55f to rgba(col, pool * .45f), 1f to rgba(col, 0f),
                    center = Offset(px, h + 18f), radius = r,
                ),
                size = full,
            )
        }

        if (d >= 0f && d < 1.4f) {
            val q = 1f - (1f - d / 1.4f).pow(3)
            val r = 24f + 430f * q
            val ww = 30f
            val a = .22f * (1f - q)
            val outer = r + ww
            val t0 = max(0f, r - ww) / outer
            val mid = t0 + (1f - t0) * .5f
            val c0 = rgba(200, 236, 255, 0f)
            drawRect(
                brush = Brush.radialGradient(
                    0f to c0, t0 to c0, mid to rgba(200, 236, 255, a), 1f to c0,
                    center = Offset(px, h - 14f), radius = outer,
                ),
                size = full,
            )
        }

        // cahaya memudar ke atas (destination-in)
        drawRect(
            brush = Brush.verticalGradient(
                0f to Color.Black.copy(alpha = 0f), .22f to Color.Black.copy(alpha = .08f),
                .58f to Color.Black.copy(alpha = .55f), 1f to Color.Black,
                startY = 0f, endY = h,
            ),
            size = full,
            blendMode = BlendMode.DstIn,
        )
    }
}
