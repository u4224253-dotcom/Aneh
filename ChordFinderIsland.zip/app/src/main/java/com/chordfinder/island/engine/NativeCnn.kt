package com.chordfinder.island.engine

/**
 * Jembatan JNI ke libcfcnn.so (app/src/main/cpp/cnn_core.cpp): bagian CNN dari ChordNet dalam C++.
 * CNN memakai ±94% waktu analisis; versi C++ ±5x lebih cepat daripada loop Kotlin di [CnnFeatureExtractor]
 * dan hasilnya sama (selisih ~1e-6 relatif, diuji terhadap referensi float64).
 *
 * Sengaja `public`: fungsi `internal` Kotlin diberi akhiran nama modul sehingga JNI tidak menemukannya.
 * Bila library tidak bisa dimuat (ABI tidak ada, dll.) [available] false dan Kotlin memakai jalur lama.
 */
object NativeCnn {
    /** Callback progres 0..1 per stage. Kembalikan true untuk lanjut; batalkan dengan melempar exception. */
    fun interface Progress {
        fun onProgress(p: Float): Boolean
    }

    @JvmField
    val available: Boolean = try {
        System.loadLibrary("cfcnn")
        true
    } catch (_: Throwable) {
        false
    }

    /**
     * @param x  |CQT| linear [frames * 252]
     * @param w  bobot 10 stage, tiap elemen [kh][kw][cin][cout]
     * @param b  bias 10 stage
     * @return fitur [frames * 240] (indeks c*3 + w), atau null bila gagal (pakai jalur Kotlin)
     */
    @JvmStatic
    external fun extract(
        x: FloatArray,
        frames: Int,
        w: Array<FloatArray>,
        b: Array<FloatArray>,
        threads: Int,
        progress: Progress?,
    ): FloatArray?
}
