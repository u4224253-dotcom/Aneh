package com.chordfinder.island

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalViewConfiguration
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Island lengkap (cangkang + semua mode + navigasi). Sama persis dipakai di layar aplikasi dan di overlay.
 * [onPick] = buka pemilih file (di aplikasi: pemilih langsung; di overlay: lewat PickerActivity).
 */
@Composable
fun IslandBody(st: IslandState, u: Float, onPick: () -> Unit, shadow: Boolean = true) {
    val dens = LocalDensity.current.density
    GlowLoop(st.glow)

    // Satu gestur untuk seluruh island:
    //  - Resting: ketuk di mana saja = buka lagi mode yang tadi.
    //  - Mode lain: geser ke samping > 50 px layar (dan lebih mendatar daripada menurun) = ganti mode;
    //    ketuk area kosong = masuk Resting. Sentuhan yang sudah dipakai kontrol lain (tombol, panah,
    //    progres lagu, zona upload) tidak dihitung, jadi hanya ruang kosong yang memicu Resting.
    val slop = LocalViewConfiguration.current.touchSlop
    val ue = u * IslandSettings.scale   // ukuran kustom ikut mengubah skala sentuhan
    val swipe = Modifier.pointerInput(u, st, ue) {
        val threshold = 50f * dens / ue
        val tapSlop = slop / ue
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = true)
            var last = down.position
            var used = false
            do {
                val ev = awaitPointerEvent()
                ev.changes.firstOrNull { it.id == down.id }?.let { last = it.position }
                if (ev.changes.any { it.isConsumed }) used = true
            } while (ev.changes.any { it.pressed })
            val dx = last.x - down.position.x
            val dy = last.y - down.position.y
            val tap = !used && hypot(dx, dy) < tapSlop
            when {
                st.resting -> if (tap) st.wake()
                abs(dx) > threshold && abs(dx) > abs(dy) * 1.5f -> st.go(st.page + if (dx < 0f) 1 else -1)
                tap -> st.rest()
                else -> {}
            }
        }
    }

    IslandShell(
        u, st.glow,
        contentModifier = swipe, shadow = shadow,
        rest = st.resting,
        restContent = { Layer(st.resting) { RestingMode() } },
    ) {
        // Mode 1 (default): Pilih tools — Chord Finder dan BPM Finder
        Layer(!st.resting && st.page == 1) {
            ToolsMode(onChord = { st.go(2) })
        }
        // lapisan cahaya (l-gup): hanya di mode 2, di bawah konten, tidak menangkap sentuhan
        Layer(st.page == 2 && !st.resting, bleed = true) {
            Canvas(Modifier.fillMaxSize().graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }) {
                st.glow.frame
                drawIslandGlow(st.glow)
            }
        }
        // hiasan tepi: komet tipis sesekali lewat di semua mode (saat analisis sudah ada cincin warna sendiri)
        Layer(!st.resting && !(st.page == 2 && st.flow.phase == Phase.AN), bleed = true) { AmbientEdge() }
        // Mode 2: Upload, Analisis, Selesai (crossfade antar fase seperti di mock-up)
        Layer(!st.resting && st.page == 2 && st.flow.phase == Phase.UP) {
            UploadMode(hover = st.hover, msg = st.msg, onPick = onPick)
        }
        // cincin warna berputar saat analisis: selebar siluet (sampai lengkungan telinga atas)
        Layer(!st.resting && st.page == 2 && st.flow.phase == Phase.AN, bleed = true) { SpinEdge() }
        Layer(!st.resting && st.page == 2 && st.flow.phase == Phase.AN) {
            AnalyzeMode(progress = st.flow.progress, name = st.flow.name, onCancel = { st.resetAll() })
        }
        Layer(!st.resting && st.page == 2 && st.flow.phase == Phase.DONE) {
            DoneMode(
                name = st.flow.name,
                onAgain = { st.flow.again() },
                onChange = { st.resetAll(); onPick() },
            )
        }
        // Mode 3: Preview audio
        Layer(!st.resting && st.page == 3) {
            PreviewMode(st.player)
        }
        // Mode 4: Akor (carousel tiga akor, sama seperti CfWan)
        Layer(!st.resting && st.page == 4) {
            ChordMode(ready = st.flow.phase == Phase.DONE)
        }

        // Navigasi antar mode (.l-nav): kiri hilang di mode pertama, kanan hilang di mode terakhir
        Layer(!st.resting) {
            NavArrow(22f, 44f, next = false, visible = st.page != 1, onClick = { st.go(st.page - 1) })
            NavArrow(Tok.W - 25f, 44f, next = true, visible = st.page != 4, onClick = { st.go(st.page + 1) })
        }
    }
}
