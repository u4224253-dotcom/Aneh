package com.chordfinder.island

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.abs

/**
 * Island lengkap (cangkang + semua mode + navigasi). Sama persis dipakai di layar aplikasi dan di overlay.
 * [onPick] = buka pemilih file (di aplikasi: pemilih langsung; di overlay: lewat PickerActivity).
 */
@Composable
fun IslandBody(st: IslandState, u: Float, onPick: () -> Unit, shadow: Boolean = true) {
    val dens = LocalDensity.current.density
    GlowLoop(st.glow)

    // geser ke samping di island untuk ganti mode (pointerdown/pointerup di HTML):
    // geseran > 50 px layar dan lebih mendatar daripada menurun. Sentuhan yang sudah dipakai
    // kontrol lain (mis. progres lagu) tidak dihitung.
    val swipe = Modifier.pointerInput(u) {
        val threshold = 50f * dens / u
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = true)
            var last = down.position
            do {
                val ev = awaitPointerEvent()
                ev.changes.firstOrNull { it.id == down.id }?.let { last = it.position }
            } while (ev.changes.any { it.pressed })
            val dx = last.x - down.position.x
            val dy = last.y - down.position.y
            if (abs(dx) > threshold && abs(dx) > abs(dy) * 1.5f) st.go(st.page + if (dx < 0f) 1 else -1)
        }
    }

    IslandShell(u, st.glow, contentModifier = swipe, shadow = shadow) {
        // lapisan cahaya (l-gup): hanya di mode 1, di bawah konten, tidak menangkap sentuhan
        Layer(st.page == 1) {
            Canvas(Modifier.fillMaxSize().graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }) {
                st.glow.frame
                drawIslandGlow(st.glow)
            }
        }
        // Mode 1: Upload, Analisis, Selesai (crossfade antar fase seperti di mock-up)
        Layer(st.page == 1 && st.flow.phase == Phase.UP) {
            UploadMode(hover = st.hover, msg = st.msg, onPick = onPick)
        }
        Layer(st.page == 1 && st.flow.phase == Phase.AN) {
            AnalyzeMode(progress = st.flow.progress, name = st.flow.name, onCancel = { st.resetAll() })
        }
        Layer(st.page == 1 && st.flow.phase == Phase.DONE) {
            DoneMode(
                name = st.flow.name,
                onAgain = { st.flow.again() },
                onChange = { st.resetAll(); onPick() },
            )
        }
        // Mode 2: Preview audio
        Layer(st.page == 2) {
            PreviewMode(st.player)
        }
        // Mode 3: Akor, sengaja kosong dulu (sama seperti mock-up)

        // Navigasi antar mode (.l-nav): kiri hilang di mode pertama, kanan hilang di mode terakhir
        Layer(true) {
            NavArrow(22f, 44f, next = false, visible = st.page != 1, onClick = { st.go(st.page - 1) })
            NavArrow(Tok.W - 25f, 44f, next = true, visible = st.page != 3, onClick = { st.go(st.page + 1) })
        }
    }
}
