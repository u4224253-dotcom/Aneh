package com.chordfinder.island

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

private fun poly(vararg v: Float): Path = Path().apply {
    moveTo(v[0], v[1])
    var i = 2
    while (i < v.size) { lineTo(v[i], v[i + 1]); i += 2 }
    close()
}

private val TRAY_BACK = poly(-10.2f, -8f, 10.2f, -8f, 13.4f, -.2f, -13.4f, -.2f)
private val ARROW = poly(-1.7f, -21f, 1.7f, -21f, 1.7f, -14.5f, 5.2f, -14.5f, 0f, -8.5f, -5.2f, -14.5f, -1.7f, -14.5f)
private val TRAY_FRONT = poly(-14f, 1f, -5.2f, 1f, -3.6f, 4.2f, 3.6f, 4.2f, 5.2f, 1f, 14f, 1f, 14f, 9f, -14f, 9f)

/**
 * MODE 1 — Upload (420 x 96). Zona drop dari Shelf: ikon di kiri, teks di kanan.
 * [hover] = ada file yang melayang di atas island (animasi sama seperti .l-shelf.hover di HTML).
 */
@Composable
fun UploadMode(hover: Boolean, msg: String, onPick: () -> Unit, onNext: () -> Unit) {
    val zoneScale by animateFloatAsState(if (hover) 1.02f else 1f, tween(400, easing = Tok.Spring), label = "zs")
    val border by animateColorAsState(Color.White.copy(alpha = if (hover) .8f else .3f), tween(300, easing = Tok.Ease), label = "bd")
    val fill by animateColorAsState(Color.White.copy(alpha = if (hover) .08f else .03f), tween(300, easing = Tok.Ease), label = "fl")
    val aT by animateFloatAsState(if (hover) 1f else 0f, tween(300, easing = Tok.Ease), label = "a")
    val xT by animateFloatAsState(if (hover) 1f else 0f, tween(350, easing = Tok.Ease), label = "x")
    val arrowT by animateFloatAsState(if (hover) 1f else 0f, tween(450, easing = Tok.Spring), label = "ar")

    // bob: panah turun-naik 6 -> 9 setelah jeda .45s, bolak-balik .7s ease-in-out
    val bob = remember { Animatable(0f) }
    var bobOn by remember { mutableStateOf(false) }
    LaunchedEffect(hover) {
        if (hover) {
            delay(450)
            bobOn = true
            while (true) {
                bob.animateTo(1f, tween(700, easing = Tok.EaseInOut))
                bob.animateTo(0f, tween(700, easing = Tok.EaseInOut))
            }
        } else {
            bobOn = false
            bob.snapTo(0f)
        }
    }
    val arrowDy = if (bobOn) 6f + 3f * bob.value else 6f * arrowT

    // .sh-zone: left 44, top 10, 332 x 70
    Box(
        Modifier
            .offset(44.dp, 10.dp)
            .size(332.dp, 70.dp)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onPick),
    ) {
        // .zone: kotak putus-putus, radius 16, border 1.4, ikut membesar 1.02 saat hover
        Canvas(Modifier.fillMaxSize().graphicsLayer { scaleX = zoneScale; scaleY = zoneScale }) {
            val d = density
            val sw = 1.4f * d
            drawRoundRect(fill, cornerRadius = CornerRadius(16f * d), size = size)
            drawRoundRect(
                color = border,
                topLeft = Offset(sw / 2f, sw / 2f),
                size = Size(size.width - sw, size.height - sw),
                cornerRadius = CornerRadius(16f * d - sw / 2f),
                style = Stroke(width = sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(3.2f * d, 2.0f * d))),
            )
        }

        // ikon tray + panah (viewBox -15 -22 30 32 di kotak 30 x 30)
        Canvas(Modifier.placeAt(46f, 35f).size(30.dp)) {
            val s = 30f / 32f
            withTransform({
                scale(density, density, Offset.Zero)
                translate((30f - 30f * s) / 2f, 0f)
                scale(s, s, Offset.Zero)
                translate(15f, 22f)
            }) {
                drawPath(TRAY_BACK, Color.White.copy(alpha = .28f))
                withTransform({ translate(0f, arrowDy) }) { drawPath(ARROW, Color.White.copy(alpha = .5f)) }
                drawPath(TRAY_FRONT, Color.White.copy(alpha = .85f))
            }
        }

        // teks utama bertukar saat hover
        CText(msg, 200f, 27f, 13f, Modifier.graphicsLayer { alpha = 1f - aT; translationY = -5f * xT * density })
        CText("Lepas untuk mulai analisis", 200f, 27f, 13f, Modifier.graphicsLayer { alpha = aT; translationY = 5f * (1f - xT) * density })
        CText(
            "MP3 · WAV · M4A · FLAC · klik untuk memilih", 200f, 46f, 9.5f,
            Modifier.graphicsLayer { alpha = 1f - aT }, color = Color.White.copy(alpha = .5f),
        )
    }

    // panah mode: kiri disembunyikan (mode pertama), kanan tampil
    NavArrow(22f, 44f, next = false, visible = false, onClick = {})
    NavArrow(Tok.W - 25f, 44f, next = true, visible = true, onClick = onNext)
}
