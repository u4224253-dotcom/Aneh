package com.chordfinder.island.engine

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Bagian Beat This! di luar jaringan: pemotongan spektrogram jadi chunk, penyatuan prediksi,
 * pemilihan puncak (post-processing minimal tanpa DBN) dan penghitungan BPM.
 * Tanpa ketergantungan ke ONNX Runtime supaya bisa diuji di JVM biasa.
 */
internal object BeatPost {
    const val CHUNK = 1500      // frame per pemanggilan model
    const val BORDER = 6        // frame tepi yang dibuang dari tiap chunk

    /** Chunk yang sudah diberi padding nol; [data] berukuran rows * N_MELS. */
    class Chunk(val rows: Int, val data: FloatArray)

    /** Awal tiap chunk (bisa negatif). Sama dengan split_piece di beat_this/inference.py (avoid_short_end). */
    fun starts(len: Int, chunk: Int = CHUNK, border: Int = BORDER): IntArray {
        if (len <= 0) return IntArray(0)
        val step = chunk - 2 * border
        val list = ArrayList<Int>()
        var s = -border
        while (s < len - border) { list.add(s); s += step }
        val arr = list.toIntArray()
        if (len > step) arr[arr.size - 1] = len - (chunk - border)
        return arr
    }

    fun chunk(spect: FloatArray, len: Int, start: Int, chunk: Int = CHUNK, border: Int = BORDER): Chunk {
        val m = BeatMel.N_MELS
        val a = max(0, start)
        val b = min(start + chunk, len)
        val left = max(0, -start)
        val right = max(0, min(border, start + chunk - len))
        val core = max(0, b - a)
        val rows = core + left + right
        val data = FloatArray(rows * m)
        if (core > 0) System.arraycopy(spect, a * m, data, left * m, core * m)
        return Chunk(rows, data)
    }

    /**
     * Menyatukan logit tiap chunk. Frame yang tercakup beberapa chunk diambil dari chunk paling awal
     * (overlap_mode "keep_first" di versi Python). Tambahkan chunk berurutan dari yang pertama.
     */
    class Aggregator(private val full: Int, private val border: Int = BORDER) {
        val logits = FloatArray(full) { -1000f }
        private val written = BooleanArray(full)

        fun add(start: Int, chunkLogits: FloatArray) {
            val n = chunkLogits.size
            val from = if (n < 2 * border) 0 else border
            val to = if (n < 2 * border) n else n - border
            for (j in from until to) {
                val t = start + j
                if (t in 0 until full && !written[t]) { logits[t] = chunkLogits[j]; written[t] = true }
            }
        }
    }

    /** Waktu beat (detik) dari logit per frame: puncak lokal (jendela 7 frame) yang > 0, puncak berdekatan digabung (rata-rata, tidak dibulatkan, seperti versi Python). */
    fun pickBeats(logits: FloatArray, fps: Float = BeatMel.FPS): FloatArray {
        val n = logits.size
        val peaks = ArrayList<Int>()
        for (i in 0 until n) {
            val v = logits[i]
            if (v <= 0f) continue
            var isMax = true
            for (k in max(0, i - 3)..min(n - 1, i + 3)) if (logits[k] > v) { isMax = false; break }
            if (isMax) peaks.add(i)
        }
        // deduplicate_peaks(width = 1): rata-rata puncak yang jaraknya <= 1 frame
        val out = ArrayList<Float>()
        if (peaks.isEmpty()) return FloatArray(0)
        var p = peaks[0].toDouble()
        var c = 1
        for (i in 1 until peaks.size) {
            val p2 = peaks[i]
            if (p2 - p <= 1) { c++; p += (p2 - p) / c }
            else { out.add((p / fps).toFloat()); p = p2.toDouble(); c = 1 }
        }
        out.add((p / fps).toFloat())
        return out.toFloatArray()
    }

    class Tempo(val bpm: Double, val steady: Float)

    /**
     * BPM dari waktu beat. Interval median memberi perkiraan awal; kalau lagunya cukup stabil, nilainya
     * dihaluskan dengan regresi linear waktu terhadap nomor beat (lebih teliti dari resolusi 20 ms per frame).
     * [steady] = porsi interval yang berada dalam 3% (minimal 40 ms) dari median (0..1).
     * Null kalau beat terlalu sedikit.
     */
    fun tempo(beats: FloatArray): Tempo? {
        if (beats.size < 4) return null
        val iv = ArrayList<Double>()
        for (i in 1 until beats.size) {
            val d = (beats[i] - beats[i - 1]).toDouble()
            if (d > 0.2 && d < 3.0) iv.add(d)
        }
        if (iv.size < 3) return null
        val sorted = iv.sorted()
        val med = if (sorted.size % 2 == 0) (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0 else sorted[sorted.size / 2]
        val tol = max(0.03 * med, 0.04)        // 3% atau 2 frame (puncak model bergeser +-1 frame)
        val steady = iv.count { abs(it - med) <= tol }.toFloat() / iv.size
        var bpm = 60.0 / med
        if (steady >= 0.6f && beats.size >= 8) {
            // regresi: t_i ~ a + b * k_i, k_i = nomor beat (beat yang terlewat ikut dihitung)
            val t0 = beats[0].toDouble()
            var sk = 0.0; var st = 0.0; var skk = 0.0; var skt = 0.0; var cnt = 0
            for (t in beats) {
                val k = ((t - t0) / med).roundToInt()
                if (abs((t - t0) - k * med) > 0.15 * med) continue     // beat yang menyimpang jauh dari grid dilewati
                sk += k; st += t; skk += k.toDouble() * k; skt += k * t.toDouble(); cnt++
            }
            val den = cnt * skk - sk * sk
            if (cnt >= 8 && den > 0) {
                val b = (cnt * skt - sk * st) / den
                if (b > 0 && abs(b - med) <= 0.05 * med) bpm = 60.0 / b
            }
        }
        return Tempo(bpm, steady)
    }
}
