package com.chordfinder.island

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.draganddrop.dragAndDropTarget
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draganddrop.DragAndDropEvent
import androidx.compose.ui.draganddrop.DragAndDropTarget
import androidx.compose.ui.draganddrop.mimeTypes
import androidx.compose.ui.draganddrop.toAndroidDragEvent
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

data class PickedAudio(val uri: Uri, val name: String, val size: Long)

private val AUDIO_EXT = Regex("\\.(mp3|wav|m4a|flac|ogg|aac|opus|wma)$", RegexOption.IGNORE_CASE)

/** Sama seperti isAudio() di HTML: tipe audio (audio/ apa saja) atau ekstensi audio. */
fun readAudio(ctx: Context, uri: Uri): PickedAudio? {
    var name = "audio"
    var size = 0L
    runCatching {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (n >= 0) name = c.getString(n) ?: name
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (s >= 0 && !c.isNull(s)) size = c.getLong(s)
            }
        }
    }
    val mime = ctx.contentResolver.getType(uri) ?: ""
    return if (mime.startsWith("audio/") || AUDIO_EXT.containsMatchIn(name)) PickedAudio(uri, name, size) else null
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChordFinderApp(activity: Activity) {
    val glow = remember { GlowController() }
    var hover by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf(MSG_DEFAULT) }
    val scope = rememberCoroutineScope()
    val flow = remember { AnalyzeFlow(scope, glow) }
    val player = remember { PlayerController(activity) }
    // page = mode yang tampil (1 = Upload/Analisis/Selesai, 2 = Preview, 3 = Akor)
    var page by remember { mutableIntStateOf(1) }
    val go: (Int) -> Unit = { n -> page = n.coerceIn(1, 3) }
    // reset() di HTML: batalkan analisis, hentikan pemutar, kembali ke mode Upload
    val resetAll: () -> Unit = { flow.reset(); player.clear(); page = 1 }

    // pemutar: jeda saat app ke latar, lepas saat ditutup
    DisposableEffect(player) {
        val lc = (activity as? ComponentActivity)?.lifecycle
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) player.pause() }
        lc?.addObserver(obs)
        onDispose { lc?.removeObserver(obs); player.release() }
    }

    GlowLoop(glow)

    val notAudio: () -> Unit = {
        scope.launch { msg = MSG_BAD; delay(1800); msg = MSG_DEFAULT }
    }
    val accept: (Uri) -> Boolean = { uri ->
        val info = readAudio(activity, uri)
        if (info == null) false else { player.load(info); flow.accept(info); true }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && !accept(uri)) notAudio()
    }
    val pickAudio: () -> Unit = { picker.launch(arrayOf("audio/*", "application/octet-stream")) }

    val dens = LocalDensity.current.density
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    BoxWithConstraints(Modifier.fillMaxSize()) {
        // fit(): skala island mengikuti lebar layar (lebar 420 + telinga 20 di kiri-kanan)
        val u = ((maxWidth.value - 12f) / 470f).coerceIn(.55f, 1.3f)
        val widthPx = constraints.maxWidth.toFloat()

        // geser ke samping di island untuk ganti mode (pointerdown/pointerup di HTML):
        // geseran > 50 px layar dan lebih mendatar daripada menurun. Sentuhan yang sudah dipakai
        // kontrol lain (mis. progres lagu) tidak dihitung.
        val swipe = Modifier.pointerInput(u) {
            val threshold = 50f * dens / u
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = true)
                var last = down.position
                do {
                    val ev = awaitPointerEvent()
                    ev.changes.firstOrNull { it.id == down.id }?.let { last = it.position }
                } while (ev.changes.any { it.pressed })
                val dx = last.x - down.position.x
                val dy = last.y - down.position.y
                if (abs(dx) > threshold && abs(dx) > abs(dy) * 1.5f) go(page + if (dx < 0f) 1 else -1)
            }
        }

        val target = remember(u, widthPx) {
            object : DragAndDropTarget {
                override fun onEntered(event: DragAndDropEvent) {
                    if (page == 1 && flow.phase == Phase.UP) { hover = true; glow.hot(true) }
                }
                override fun onMoved(event: DragAndDropEvent) {
                    if (page != 1 || flow.phase != Phase.UP) return
                    val x = event.toAndroidDragEvent().x
                    val left = (widthPx - Tok.W * u * dens) / 2f
                    glow.move((x - left) / (u * dens))
                }
                override fun onExited(event: DragAndDropEvent) { hover = false; glow.hot(false) }
                override fun onEnded(event: DragAndDropEvent) { hover = false; glow.hot(false) }
                override fun onDrop(event: DragAndDropEvent): Boolean {
                    hover = false; glow.hot(false)
                    if (page != 1 || flow.phase != Phase.UP) return false
                    val de = event.toAndroidDragEvent()
                    val clip = de.clipData ?: return false
                    runCatching { activity.requestDragAndDropPermissions(de) }
                    for (i in 0 until clip.itemCount) {
                        val uri = clip.getItemAt(i).uri ?: continue
                        if (accept(uri)) return true
                    }
                    notAudio()
                    return true
                }
            }
        }

        Box(
            Modifier
                .fillMaxSize()
                .dragAndDropTarget(
                    shouldStartDragAndDrop = { e ->
                        page == 1 && flow.phase == Phase.UP && e.mimeTypes().none { it.startsWith("text/") }
                    },
                    target = target,
                ),
        ) {
            Wallpaper(u)
            Box(Modifier.align(Alignment.TopCenter).padding(top = topInset)) {
                IslandShell(u, glow, contentModifier = swipe) {
                    // lapisan cahaya (l-gup): hanya di mode 1, di bawah konten, tidak menangkap sentuhan
                    Layer(page == 1) {
                        androidx.compose.foundation.Canvas(
                            Modifier.fillMaxSize().graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen },
                        ) {
                            glow.frame
                            drawIslandGlow(glow)
                        }
                    }
                    // Mode 1: Upload, Analisis, Selesai (crossfade antar fase seperti di mock-up)
                    Layer(page == 1 && flow.phase == Phase.UP) {
                        UploadMode(hover = hover, msg = msg, onPick = pickAudio)
                    }
                    Layer(page == 1 && flow.phase == Phase.AN) {
                        AnalyzeMode(progress = flow.progress, name = flow.name, onCancel = resetAll)
                    }
                    Layer(page == 1 && flow.phase == Phase.DONE) {
                        DoneMode(
                            name = flow.name,
                            onAgain = { flow.again() },
                            onChange = { resetAll(); pickAudio() },
                        )
                    }
                    // Mode 2: Preview audio
                    Layer(page == 2) {
                        PreviewMode(player)
                    }
                    // Mode 3: Akor, sengaja kosong dulu (sama seperti mock-up)

                    // Navigasi antar mode (.l-nav): kiri hilang di mode pertama, kanan hilang di mode terakhir
                    Layer(true) {
                        NavArrow(22f, 44f, next = false, visible = page != 1, onClick = { go(page - 1) })
                        NavArrow(Tok.W - 25f, 44f, next = true, visible = page != 3, onClick = { go(page + 1) })
                    }
                }
            }
        }
    }
}
