package com.chordfinder.island

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.draganddrop.dragAndDropTarget
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draganddrop.DragAndDropEvent
import androidx.compose.ui.draganddrop.DragAndDropTarget
import androidx.compose.ui.draganddrop.mimeTypes
import androidx.compose.ui.draganddrop.toAndroidDragEvent
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

data class PickedAudio(val uri: Uri, val name: String, val size: Long)

private val AUDIO_EXT = Regex("\\.(mp3|wav|m4a|flac|ogg|aac|opus|wma)$", RegexOption.IGNORE_CASE)

/** Sama seperti isAudio() di HTML: tipe audio (audio/ apa saja) atau ekstensi audio. */
fun readAudio(ctx: Context, uri: Uri): PickedAudio? {
    var name = "audio"
    var size = 0L
    runCatching {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (n >= 0) name = c.getString(n) ?: name
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (s >= 0 && !c.isNull(s)) size = c.getLong(s)
            }
        }
    }
    val mime = ctx.contentResolver.getType(uri) ?: ""
    return if (mime.startsWith("audio/") || AUDIO_EXT.containsMatchIn(name)) PickedAudio(uri, name, size) else null
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChordFinderApp(activity: Activity) {
    val scope = rememberCoroutineScope()
    val st = remember { IslandState(activity, scope) }

    // wantOverlay = pengguna sudah minta "bawa keluar" tapi masih menunggu izin overlay diberikan
    var wantOverlay by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }   // naik tiap kembali ke layar ini, untuk cek ulang izin

    val startOverlay: () -> Unit = {
        st.resetAll()                // hentikan pemutar di dalam aplikasi; island overlay mulai dari awal
        wantOverlay = false
        IslandService.start(activity)
    }

    // pemutar: jeda saat app ke latar; sepulang dari layar izin, lanjutkan bila izin sudah diberikan
    DisposableEffect(st) {
        val lc = (activity as? ComponentActivity)?.lifecycle
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_STOP -> st.player.pause()
                Lifecycle.Event.ON_RESUME -> {
                    tick++
                    if (wantOverlay && Settings.canDrawOverlays(activity) && !IslandService.active) startOverlay()
                }
                else -> {}
            }
        }
        lc?.addObserver(obs)
        onDispose { lc?.removeObserver(obs); st.release(keepWork = true) }
    }

    // app dibuka lagi (atau dibuat ulang): kalau ada analisis di latar milik island dalam app, sambung ke sana
    LaunchedEffect(st) {
        if (!IslandService.active) st.adoptRunning()
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && !st.accept(uri)) st.notAudio()
    }
    val pickAudio: () -> Unit = { picker.launch(arrayOf("audio/*", "application/octet-stream")) }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        startOverlay()   // izin notifikasi hanya menentukan notifikasi terlihat atau tidak; island tetap jalan
    }

    val onToggleOverlay: () -> Unit = {
        if (IslandService.active) {
            IslandService.stop(activity)
        } else if (!Settings.canDrawOverlays(activity)) {
            wantOverlay = true
            activity.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + activity.packageName)),
            )
        } else if (Build.VERSION.SDK_INT >= 33 &&
            activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startOverlay()
        }
    }

    val dens = LocalDensity.current.density
    val overlayOn = IslandService.active
    val needPermission = remember(tick, wantOverlay) { wantOverlay && !Settings.canDrawOverlays(activity) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        // fit(): skala island mengikuti lebar layar (lebar 420 + telinga 20 di kiri-kanan)
        val u = ((maxWidth.value - 12f) / 470f).coerceIn(.55f, 1.3f)
        val widthPx = constraints.maxWidth.toFloat()

        val target = remember(u, widthPx) {
            object : DragAndDropTarget {
                override fun onEntered(event: DragAndDropEvent) {
                    if (st.page == 2 && st.flow.phase == Phase.UP) { st.hover = true; st.glow.hot(true) }
                }
                override fun onMoved(event: DragAndDropEvent) {
                    if (st.page != 2 || st.flow.phase != Phase.UP) return
                    val x = event.toAndroidDragEvent().x
                    val ux = u * IslandSettings.scale
                    val left = (widthPx - Tok.W * ux * dens) / 2f
                    st.glow.move((x - left) / (ux * dens))
                }
                override fun onExited(event: DragAndDropEvent) { st.hover = false; st.glow.hot(false) }
                override fun onEnded(event: DragAndDropEvent) { st.hover = false; st.glow.hot(false) }
                override fun onDrop(event: DragAndDropEvent): Boolean {
                    st.hover = false; st.glow.hot(false)
                    if (st.page != 2 || st.flow.phase != Phase.UP) return false
                    val de = event.toAndroidDragEvent()
                    val clip = de.clipData ?: return false
                    runCatching { activity.requestDragAndDropPermissions(de) }
                    for (i in 0 until clip.itemCount) {
                        val uri = clip.getItemAt(i).uri ?: continue
                        if (st.accept(uri)) return true
                    }
                    st.notAudio()
                    return true
                }
            }
        }

        Box(
            Modifier
                .fillMaxSize()
                .dragAndDropTarget(
                    shouldStartDragAndDrop = { e ->
                        !overlayOn && !st.resting && st.page == 2 && st.flow.phase == Phase.UP &&
                            e.mimeTypes().none { it.startsWith("text/") }
                    },
                    target = target,
                ),
        ) {
            Wallpaper(u)

            // Island di dalam aplikasi: menempel di tepi atas layar (y = 0), menimpa status bar seperti notch.
            // Saat island overlay aktif, island itu yang tampil di tempat yang sama, jadi yang ini disembunyikan.
            if (!overlayOn) {
                Box(Modifier.align(Alignment.TopCenter)) {
                    IslandBody(st, u, onPick = pickAudio)
                }
            }

            // Tombol bawa island keluar + panel ukuran island. Posisi tidak ikut ukuran kustom, supaya slider tidak bergeser saat ditarik.
            Column(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = (Tok.H * u + 90f).dp, start = 16.dp, end = 16.dp, bottom = 24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                OverlayToggle(on = overlayOn, hint = needPermission, onClick = onToggleOverlay)
                Spacer(Modifier.height(18.dp))
                SizePanel(Modifier.widthIn(max = 360.dp).fillMaxWidth())
            }
        }
    }
}

/** Tombol pil di bawah island: "Bawa island keluar" / "Tutup island di luar app" (aria-pressed seperti .try button). */
@Composable
private fun OverlayToggle(on: Boolean, hint: Boolean, onClick: () -> Unit) {
    val fs = with(LocalDensity.current) { 15.dp.toSp() }
    val pill = RoundedCornerShape(50)
    androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .clip(pill)
                .background(if (on) Color(0xFFECEFF7) else Color(0x6105060C))
                .border(1.dp, if (on) Color(0xFFECEFF7) else Color.White.copy(alpha = .22f), pill)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null, role = Role.Button, onClick = onClick,
                )
                .padding(horizontal = 16.dp, vertical = 8.dp),
        ) {
            BasicText(
                if (on) "Tutup island di luar app" else "Bawa island keluar",
                style = TextStyle(color = if (on) Color(0xFF05060C) else Color.White, fontSize = fs),
            )
        }
        if (hint) {
            BasicText(
                "Izinkan \"tampil di atas aplikasi lain\", lalu kembali ke sini.",
                modifier = Modifier.padding(top = 12.dp, start = 8.dp, end = 8.dp),
                style = TextStyle(color = Color.White.copy(alpha = .9f), fontSize = with(LocalDensity.current) { 14.dp.toSp() }),
            )
        }
    }
}
