package com.chordfinder.island

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.draganddrop.dragAndDropTarget
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draganddrop.DragAndDropEvent
import androidx.compose.ui.draganddrop.DragAndDropTarget
import androidx.compose.ui.draganddrop.mimeTypes
import androidx.compose.ui.draganddrop.toAndroidDragEvent
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class PickedAudio(val uri: Uri, val name: String, val size: Long)

private val AUDIO_EXT = Regex("\\.(mp3|wav|m4a|flac|ogg|aac|opus|wma)$", RegexOption.IGNORE_CASE)

/** Sama seperti isAudio() di HTML: tipe audio/* atau ekstensi audio. */
fun readAudio(ctx: Context, uri: Uri): PickedAudio? {
    var name = "audio"
    var size = 0L
    runCatching {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (n >= 0) name = c.getString(n) ?: name
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (s >= 0 && !c.isNull(s)) size = c.getLong(s)
            }
        }
    }
    val mime = ctx.contentResolver.getType(uri) ?: ""
    return if (mime.startsWith("audio/") || AUDIO_EXT.containsMatchIn(name)) PickedAudio(uri, name, size) else null
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChordFinderApp(activity: Activity) {
    val glow = remember { GlowController() }
    var hover by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf(MSG_DEFAULT) }
    var picked by remember { mutableStateOf<PickedAudio?>(null) }   // dipakai mode berikutnya (analisis)
    val scope = rememberCoroutineScope()

    GlowLoop(glow)

    val notAudio: () -> Unit = {
        scope.launch { msg = MSG_BAD; delay(1800); msg = MSG_DEFAULT }
    }
    val accept: (Uri) -> Boolean = { uri ->
        val info = readAudio(activity, uri)
        if (info == null) false else { picked = info; glow.drop(); true }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && !accept(uri)) notAudio()
    }

    val dens = LocalDensity.current.density
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    BoxWithConstraints(Modifier.fillMaxSize()) {
        // fit(): skala island mengikuti lebar layar (lebar 420 + telinga 20 di kiri-kanan)
        val u = ((maxWidth.value - 12f) / 470f).coerceIn(.55f, 1.3f)
        val widthPx = constraints.maxWidth.toFloat()

        val target = remember(u, widthPx) {
            object : DragAndDropTarget {
                override fun onEntered(event: DragAndDropEvent) { hover = true; glow.hot(true) }
                override fun onMoved(event: DragAndDropEvent) {
                    val x = event.toAndroidDragEvent().x
                    val left = (widthPx - Tok.W * u * dens) / 2f
                    glow.move((x - left) / (u * dens))
                }
                override fun onExited(event: DragAndDropEvent) { hover = false; glow.hot(false) }
                override fun onEnded(event: DragAndDropEvent) { hover = false; glow.hot(false) }
                override fun onDrop(event: DragAndDropEvent): Boolean {
                    hover = false; glow.hot(false)
                    val de = event.toAndroidDragEvent()
                    val clip = de.clipData ?: return false
                    runCatching { activity.requestDragAndDropPermissions(de) }
                    for (i in 0 until clip.itemCount) {
                        val uri = clip.getItemAt(i).uri ?: continue
                        if (accept(uri)) return true
                    }
                    notAudio()
                    return true
                }
            }
        }

        Box(
            Modifier
                .fillMaxSize()
                .dragAndDropTarget(
                    shouldStartDragAndDrop = { e -> e.mimeTypes().none { it.startsWith("text/") } },
                    target = target,
                ),
        ) {
            Wallpaper(u)
            Box(Modifier.align(Alignment.TopCenter).padding(top = topInset)) {
                IslandShell(u, glow) {
                    // lapisan cahaya (l-gup): di bawah konten, tidak menangkap sentuhan
                    androidx.compose.foundation.Canvas(
                        Modifier.fillMaxSize().graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen },
                    ) {
                        glow.frame
                        drawIslandGlow(glow)
                    }
                    UploadMode(
                        hover = hover, msg = msg,
                        onPick = { picker.launch(arrayOf("audio/*", "application/octet-stream")) },
                        onNext = { /* mode berikutnya (Analisis) menyusul */ },
                    )
                }
            }
        }
    }
}
