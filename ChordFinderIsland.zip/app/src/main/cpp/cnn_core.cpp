// Port C++ dari CnnFeatureExtractor.kt (ChordMini chordnet_ismir_naive, satu fold).
//
//   |CQT| [T,252] -> 3x(conv3x3 pad(1,1)+InstanceNorm+SELU) -> MaxPool(1,3)
//                 -> 3x(conv 32)                           -> MaxPool(1,3)
//                 -> 2x(conv 64)                           -> MaxPool(1,4)
//                 -> 2x(conv 80, pad(1,0))                 -> [T, 240]
//
// Layout aktivasi [waktu][lebar][channel] (NHWC); bobot [kh][kw][cin][cout].
// InstanceNorm: mean/varians per channel di seluruh chunk (waktu x lebar), sama dengan Kotlin.
//
// Kecepatan: konvolusi dikerjakan per ubin 4 posisi lebar x 16 channel keluaran, supaya satu kali
// baca bobot dipakai 4 kali dan akumulator tinggal di register. Loop sengaja polos (tanpa intrinsik)
// supaya clang NDK mengubahnya jadi NEON sendiri (-O3).

#include "cnn_core.h"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstring>
#include <memory>
#include <mutex>
#include <new>
#include <thread>
#include <vector>

namespace {

struct Stage {
    int cin, cout, padW, pool;
};

constexpr int kStages = 10;
constexpr Stage kSpec[kStages] = {
    {1, 16, 1, 0},  {16, 16, 1, 0}, {16, 16, 1, 3},
    {16, 32, 1, 0}, {32, 32, 1, 0}, {32, 32, 1, 3},
    {32, 64, 1, 0}, {64, 64, 1, 4},
    {64, 80, 0, 0}, {80, 80, 0, 0},
};

constexpr int kInBins = 252;
constexpr int kOutSize = 240;
constexpr int kCB = 16;  // blok channel keluaran
constexpr int kMinRowsPerThread = 16;
constexpr double kEps = 1e-5;
constexpr float kLambda = 1.0507009873554805f;
constexpr float kLA = 1.0507009873554805f * 1.6732632423543772f;

inline float selu(float x) {
    return x > 0.f ? kLambda * x : kLA * std::expm1(x);
}

// Bagi [0,n) jadi blok kontigu, satu per thread; thread pemanggil ikut bekerja.
template <class F>
void parallel_for(int n, int threads, F&& body) {
    int nt = std::min(threads, std::max(1, n / kMinRowsPerThread));
    if (nt <= 1) {
        body(0, n);
        return;
    }
    int per = (n + nt - 1) / nt;
    std::vector<std::thread> workers;
    workers.reserve(nt - 1);
    for (int i = 1; i < nt; i++) {
        int a = i * per;
        int b = std::min(n, a + per);
        if (a >= b) break;
        workers.emplace_back([&body, a, b] { body(a, b); });
    }
    body(0, std::min(n, per));
    for (auto& t : workers) t.join();
}

// Vektor 4 float (GCC/clang vector extension, bukan intrinsik): jadi NEON di arm64 dan SSE di x86.
typedef float v4f __attribute__((vector_size(16)));

inline v4f load4(const float* p) {
    v4f v;
    std::memcpy(&v, p, sizeof(v));  // aman untuk alamat tak sejajar
    return v;
}
inline void store4(float* p, v4f v) { std::memcpy(p, &v, sizeof(v)); }
inline v4f splat(float s) { return v4f{s, s, s, s}; }

constexpr int kVecPerBlock = kCB / 4;  // 4 vektor = 16 channel

// Satu ubin: XB posisi lebar berurutan mulai x0, kCB channel keluaran mulai co0, pada baris waktu t.
// Akumulator XB x 4 vektor dipertahankan di register (XB=4 -> 16 register dari 32 di arm64).
template <int XB>
inline void conv_tile(const float* __restrict in, const float* __restrict w,
                      const float* __restrict bias, float* __restrict out,
                      const float* __restrict zeros, int tN, int wIn, int wOut,
                      int cin, int cout, int padW, int t, int x0, int co0,
                      double* __restrict s, double* __restrict q) {
    v4f acc[XB][kVecPerBlock];
    for (int xi = 0; xi < XB; xi++)
        for (int k = 0; k < kVecPerBlock; k++) acc[xi][k] = load4(bias + co0 + 4 * k);

    for (int kh = 0; kh < 3; kh++) {
        int tt = t + kh - 1;
        if (tt < 0 || tt >= tN) continue;
        for (int kw = 0; kw < 3; kw++) {
            const float* p[XB];
            for (int xi = 0; xi < XB; xi++) {
                int xx = x0 + xi + kw - padW;
                p[xi] = (xx >= 0 && xx < wIn) ? in + ((size_t)tt * wIn + xx) * cin : zeros;
            }
            const float* wk = w + (size_t)(kh * 3 + kw) * cin * cout + co0;
            for (int ci = 0; ci < cin; ci++) {
                const float* wr = wk + (size_t)ci * cout;
                const v4f w0 = load4(wr), w1 = load4(wr + 4), w2 = load4(wr + 8), w3 = load4(wr + 12);
                for (int xi = 0; xi < XB; xi++) {
                    const v4f v = splat(p[xi][ci]);
                    acc[xi][0] += v * w0;
                    acc[xi][1] += v * w1;
                    acc[xi][2] += v * w2;
                    acc[xi][3] += v * w3;
                }
            }
        }
    }

    for (int xi = 0; xi < XB; xi++) {
        float* o = out + ((size_t)t * wOut + x0 + xi) * cout + co0;
        for (int k = 0; k < kVecPerBlock; k++) {
            store4(o + 4 * k, acc[xi][k]);
            float a[4];
            store4(a, acc[xi][k]);
            for (int j = 0; j < 4; j++) {
                s[co0 + 4 * k + j] += a[j];
                q[co0 + 4 * k + j] += (double)a[j] * a[j];
            }
        }
    }
}

// Konvolusi 3x3 (kh = waktu pad 1, kw = frekuensi pad padW) + bias; kumpulkan jumlah dan
// jumlah-kuadrat per channel untuk InstanceNorm.
void conv_layer(const float* in, float* out, int tN, int wIn, int wOut, const Stage& st,
                const float* w, const float* bias, int threads, std::vector<double>& sum,
                std::vector<double>& sq) {
    const int cin = st.cin, cout = st.cout;
    std::mutex mu;
    parallel_for(tN, threads, [&](int t0, int t1) {
        std::vector<float> zeros(cin, 0.f);
        std::vector<double> s(cout, 0.0), q(cout, 0.0);
        for (int t = t0; t < t1; t++) {
            for (int co0 = 0; co0 < cout; co0 += kCB) {
                int x = 0;
                for (; x + 4 <= wOut; x += 4)
                    conv_tile<4>(in, w, bias, out, zeros.data(), tN, wIn, wOut, cin, cout, st.padW,
                                 t, x, co0, s.data(), q.data());
                for (; x < wOut; x++)
                    conv_tile<1>(in, w, bias, out, zeros.data(), tN, wIn, wOut, cin, cout, st.padW,
                                 t, x, co0, s.data(), q.data());
            }
        }
        std::lock_guard<std::mutex> g(mu);
        for (int c = 0; c < cout; c++) {
            sum[c] += s[c];
            sq[c] += q[c];
        }
    });
}

// (x - mean) * inv lalu SELU, di tempat. Layout [..][cout].
void norm_selu(float* buf, long rows, int cout, const float* mean, const float* inv, int threads) {
    parallel_for((int)rows, threads, [&](int r0, int r1) {
        for (int r = r0; r < r1; r++) {
            float* b = buf + (size_t)r * cout;
            for (int c = 0; c < cout; c++) b[c] = selu((b[c] - mean[c]) * inv[c]);
        }
    });
}

// MaxPool(1,k) di sumbu frekuensi digabung norm+SELU. Norm (inv > 0) dan SELU sama-sama monoton
// naik, jadi max dicari pada nilai mentah lalu cukup satu norm+SELU per keluaran.
void pool_norm_selu(const float* in, float* out, int tN, int wIn, int wOut, int k, int cout,
                    const float* mean, const float* inv, int threads) {
    parallel_for(tN, threads, [&](int t0, int t1) {
        for (int t = t0; t < t1; t++) {
            for (int x = 0; x < wOut; x++) {
                float* o = out + ((size_t)t * wOut + x) * cout;
                const float* ip = in + ((size_t)t * wIn + (size_t)x * k) * cout;
                for (int c = 0; c < cout; c++) {
                    float m = ip[c];
                    for (int j = 1; j < k; j++) {
                        float v = ip[(size_t)j * cout + c];
                        if (v > m) m = v;
                    }
                    o[c] = selu((m - mean[c]) * inv[c]);
                }
            }
        }
    });
}

}  // namespace

extern "C" {

int cf_cnn_stage_count(void) { return kStages; }

int cf_cnn_extract(const float* x, int frames, const float* const* w, const float* const* b,
                   float* out, int threads, cf_progress_fn progress, void* user) {
    if (frames < 1 || !x || !w || !b || !out) return 3;
    if (threads < 1) threads = 1;
    try {
        const size_t cap = (size_t)frames * kInBins * 16;
        std::unique_ptr<float[]> bufA(new float[cap]);
        std::unique_ptr<float[]> bufB(new float[cap]);
        float* cur = bufA.get();
        float* nxt = bufB.get();
        std::memcpy(cur, x, (size_t)frames * kInBins * sizeof(float));

        int width = kInBins;
        for (int i = 0; i < kStages; i++) {
            const Stage& st = kSpec[i];
            const int wOut = width + 2 * st.padW - 2;
            std::vector<double> sum(st.cout, 0.0), sq(st.cout, 0.0);
            conv_layer(cur, nxt, frames, width, wOut, st, w[i], b[i], threads, sum, sq);

            const double n = (double)frames * wOut;
            std::vector<float> mean(st.cout), inv(st.cout);
            for (int c = 0; c < st.cout; c++) {
                double m = sum[c] / n;
                double v = std::max(sq[c] / n - m * m, 0.0);  // varians populasi (biased)
                mean[c] = (float)m;
                inv[c] = (float)(1.0 / std::sqrt(v + kEps));
            }
            if (st.pool > 0) {
                const int wp = wOut / st.pool;
                pool_norm_selu(nxt, cur, frames, wOut, wp, st.pool, st.cout, mean.data(), inv.data(),
                               threads);  // nxt -> cur
                width = wp;
            } else {
                norm_selu(nxt, (long)frames * wOut, st.cout, mean.data(), inv.data(), threads);
                std::swap(cur, nxt);
                width = wOut;
            }
            if (progress && !progress(user, (float)(i + 1) / kStages)) return 1;
        }
        if (width != 3) return 3;

        const int ch = kSpec[kStages - 1].cout;  // 80
        for (int t = 0; t < frames; t++) {
            float* o = out + (size_t)t * kOutSize;
            for (int wd = 0; wd < 3; wd++) {
                const float* src = cur + ((size_t)t * 3 + wd) * ch;
                for (int c = 0; c < ch; c++) o[c * 3 + wd] = src[c];
            }
        }
        return 0;
    } catch (const std::bad_alloc&) {
        return 2;
    }
}

}  // extern "C"
