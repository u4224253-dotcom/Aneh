#pragma once

// Inti CNN ChordMini (CnnFeatureExtractor.kt) dalam C++ portabel, tanpa JNI.
// Dipakai oleh cnn_jni.cpp (aplikasi) dan oleh tes di luar Android.

extern "C" {

/// Panggilan balik progres. Mengembalikan 0 bila pekerjaan harus dibatalkan.
typedef int (*cf_progress_fn)(void* user, float progress);

/// Jumlah stage konvolusi (tetap).
int cf_cnn_stage_count(void);

/// Ekstraksi fitur satu chunk.
///   x      : |CQT| linear [frames][252]
///   w[i]   : bobot stage i, disusun [kh][kw][cin][cout]
///   b[i]   : bias stage i, [cout]
///   out    : keluaran [frames][240], indeks [c*3 + w]
///   threads: jumlah thread (>= 1)
/// Mengembalikan 0 bila berhasil, 1 dibatalkan, 2 kehabisan memori, 3 argumen salah.
int cf_cnn_extract(const float* x, int frames,
                   const float* const* w, const float* const* b,
                   float* out, int threads,
                   cf_progress_fn progress, void* user);

}  // extern "C"
