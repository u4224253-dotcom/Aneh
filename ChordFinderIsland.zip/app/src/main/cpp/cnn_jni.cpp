// Jembatan JNI untuk com.chordfinder.island.engine.NativeCnn.extract (lihat NativeCnn.kt).
//
// Mengembalikan null bila gagal (argumen salah, memori habis) supaya Kotlin memakai jalur lamanya.
// Pembatalan: callback Kotlin melempar exception (CancellationException); begitu terdeteksi kita
// berhenti, melepas semua array, dan kembali dengan exception masih tertunda sehingga JVM
// meneruskannya ke pemanggil.

#include <jni.h>

#include <vector>

#include "cnn_core.h"

namespace {

constexpr jlong kInBins = 252;
constexpr jlong kOutSize = 240;

struct CallbackCtx {
    JNIEnv* env;
    jobject cb;
    jmethodID mid;
};

// Dipanggil dari thread pemanggil saja (di antara bagian paralel), jadi JNIEnv ini sah dipakai.
int progress_trampoline(void* user, float p) {
    auto* c = static_cast<CallbackCtx*>(user);
    jboolean keepGoing = c->env->CallBooleanMethod(c->cb, c->mid, p);
    if (c->env->ExceptionCheck()) return 0;
    return keepGoing ? 1 : 0;
}

}  // namespace

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_chordfinder_island_engine_NativeCnn_extract(JNIEnv* env, jclass /*clazz*/, jfloatArray jx,
                                                     jint frames, jobjectArray jw, jobjectArray jb,
                                                     jint threads, jobject jprog) {
    const int n = cf_cnn_stage_count();
    if (!jx || !jw || !jb || frames < 1) return nullptr;
    if (env->GetArrayLength(jw) != n || env->GetArrayLength(jb) != n) return nullptr;
    if ((jlong)env->GetArrayLength(jx) != (jlong)frames * kInBins) return nullptr;

    std::vector<jfloatArray> wa(n, nullptr), ba(n, nullptr);
    std::vector<jfloat*> wp(n, nullptr), bp(n, nullptr);
    jfloat* x = env->GetFloatArrayElements(jx, nullptr);
    bool ok = x != nullptr;
    for (int i = 0; ok && i < n; i++) {
        wa[i] = static_cast<jfloatArray>(env->GetObjectArrayElement(jw, i));
        ba[i] = static_cast<jfloatArray>(env->GetObjectArrayElement(jb, i));
        if (!wa[i] || !ba[i]) { ok = false; break; }
        wp[i] = env->GetFloatArrayElements(wa[i], nullptr);
        bp[i] = env->GetFloatArrayElements(ba[i], nullptr);
        if (!wp[i] || !bp[i]) ok = false;
    }

    CallbackCtx ctx{env, jprog, nullptr};
    if (ok && jprog) {
        jclass pc = env->GetObjectClass(jprog);
        ctx.mid = pc ? env->GetMethodID(pc, "onProgress", "(F)Z") : nullptr;
        if (pc) env->DeleteLocalRef(pc);
        if (!ctx.mid) ok = false;  // NoSuchMethodError tertunda
    }

    int rc = 3;
    std::vector<float> out;
    if (ok) {
        try {
            out.resize((size_t)frames * kOutSize);
            rc = cf_cnn_extract(x, frames, wp.data(), bp.data(), out.data(), threads,
                                jprog ? progress_trampoline : nullptr, &ctx);
        } catch (...) {
            rc = 2;
        }
    }

    // Semua Release di bawah boleh dipanggil walau ada exception tertunda.
    for (int i = 0; i < n; i++) {
        if (wp[i]) env->ReleaseFloatArrayElements(wa[i], wp[i], JNI_ABORT);
        if (bp[i]) env->ReleaseFloatArrayElements(ba[i], bp[i], JNI_ABORT);
        if (wa[i]) env->DeleteLocalRef(wa[i]);
        if (ba[i]) env->DeleteLocalRef(ba[i]);
    }
    if (x) env->ReleaseFloatArrayElements(jx, x, JNI_ABORT);

    if (rc != 0 || env->ExceptionCheck()) return nullptr;

    jfloatArray res = env->NewFloatArray((jsize)out.size());
    if (!res) return nullptr;  // OutOfMemoryError tertunda
    env->SetFloatArrayRegion(res, 0, (jsize)out.size(), out.data());
    return res;
}
