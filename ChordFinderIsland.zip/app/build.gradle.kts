plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.chordfinder.island"
    compileSdk = 35
    ndkVersion = "27.0.12077973"

    defaultConfig {
        applicationId = "com.chordfinder.island"
        minSdk = 26
        targetSdk = 35
        versionCode = 10
        versionName = "0.10"

        // CNN dalam C++ (app/src/main/cpp). Bila library gagal dimuat, Kotlin memakai jalur lama.
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
        externalNativeBuild {
            cmake { arguments += listOf("-DANDROID_ARM_NEON=TRUE", "-DANDROID_STL=c++_static") }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    // cnn.lkm (5,6 MB, float32) nyaris tidak bisa dikompres; simpan apa adanya supaya dibuka cepat
    androidResources { noCompress += listOf("lkm", "onnx") }
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // Mesin tempo (Beat This!): ONNX Runtime untuk Android. Rilis baru memakai alignment 16 KB.
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.27.0")
}
