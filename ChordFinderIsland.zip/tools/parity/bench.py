import ctypes, struct, sys, time
import numpy as np
LKM, SO, FRAMES = sys.argv[1], sys.argv[2], int(sys.argv[3])
b = open(LKM, "rb").read()
ver, count = struct.unpack_from("<II", b, 4); pos = 12; F = {}
for _ in range(count):
    (nl,) = struct.unpack_from("<H", b, pos); pos += 2
    name = b[pos:pos+nl].decode(); pos += nl
    dtype, rank = b[pos], b[pos+1]; pos += 2
    dims = struct.unpack_from("<" + "I"*rank, b, pos); pos += 4*rank
    n = int(np.prod(dims)) if rank else 1
    if dtype == 0: F[name] = np.frombuffer(b, "<f4", n, pos).reshape(dims).copy(); pos += 4*n
    elif dtype == 1: pos += 4*n
    else: pos += dims[0]
names = ["conv1a","conv1b","conv1c","conv2a","conv2b","conv2c","conv3a","conv3b","conv4a","conv4b"]
ws = [np.ascontiguousarray(F[f"f0.{n}.weight"].transpose(2,3,1,0)).astype(np.float32).ravel().copy() for n in names]
bs = [F[f"f0.{n}.bias"].astype(np.float32).copy() for n in names]
lib = ctypes.CDLL(SO)
PROG = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_float)
lib.cf_cnn_extract.restype = ctypes.c_int
lib.cf_cnn_extract.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p, ctypes.c_int, PROG, ctypes.c_void_p]
wp = (ctypes.c_void_p*10)(*[w.ctypes.data for w in ws]); bp = (ctypes.c_void_p*10)(*[x.ctypes.data for x in bs])
rng = np.random.default_rng(1)
x = (np.abs(rng.normal(size=(FRAMES,252)))**2).astype(np.float32)
out = np.zeros((FRAMES,240), np.float32)
macs = 13.1e9 * FRAMES / 2584
for th in (1, 2):
    best = 1e9
    for _ in range(3):
        t0 = time.perf_counter()
        rc = lib.cf_cnn_extract(x.ctypes.data, FRAMES, wp, bp, out.ctypes.data, th, PROG(0), None)
        best = min(best, time.perf_counter() - t0)
    print(f"threads={th}: rc={rc} {best:.2f}s per fold  ->  {macs/best/1e9:.2f} GMAC/s")

# waktu per stage (thread tunggal)
names_s = ["1a","1b","1c","2a","2b","2c","3a","3b","4a","4b"]
macs_s = [0.09,1.5,1.5,1.0,2.0,2.0,1.33,2.67,0.6,0.45]
marks = []
@PROG
def cb(user, p):
    marks.append(time.perf_counter()); return 1
marks.append(time.perf_counter())
lib.cf_cnn_extract(x.ctypes.data, FRAMES, wp, bp, out.ctypes.data, 1, cb, None)
print("stage   detik   GMAC/s(perkiraan)")
for i in range(10):
    dt = marks[i+1]-marks[i]
    print(f"  {names_s[i]}   {dt:5.2f}   {macs_s[i]*FRAMES/2584/dt:5.2f}")
