"""Bandingkan kernel C++ (cnn_core.cpp) dengan referensi numpy CNN ChordMini dari bobot cnn.lkm.

Pemakaian: python3 -I cnn_ref_test.py <cnn.lkm> <libcfcnn_test.so> [frames] [threads]
"""
import ctypes
import struct
import sys
import time

import numpy as np

LKM, SO = sys.argv[1], sys.argv[2]
FRAMES = int(sys.argv[3]) if len(sys.argv) > 3 else 600
THREADS = int(sys.argv[4]) if len(sys.argv) > 4 else 2


def read_lkm(path):
    b = open(path, "rb").read()
    ver, count = struct.unpack_from("<II", b, 4)
    pos = 12
    f, i = {}, {}
    for _ in range(count):
        (nl,) = struct.unpack_from("<H", b, pos); pos += 2
        name = b[pos:pos + nl].decode(); pos += nl
        dtype, rank = b[pos], b[pos + 1]; pos += 2
        dims = struct.unpack_from("<" + "I" * rank, b, pos); pos += 4 * rank
        n = int(np.prod(dims)) if rank else 1
        if dtype == 0:
            f[name] = np.frombuffer(b, "<f4", n, pos).reshape(dims).copy(); pos += 4 * n
        elif dtype == 1:
            i[name] = np.frombuffer(b, "<i4", n, pos).copy(); pos += 4 * n
        else:
            pos += dims[0]
    return f, i


F, I = read_lkm(LKM)
folds = [int(v) for v in I["folds"]]
print("folds di model:", folds)

SPEC = [("conv1a", 1, 16, 1, 0), ("conv1b", 16, 16, 1, 0), ("conv1c", 16, 16, 1, 3),
        ("conv2a", 16, 32, 1, 0), ("conv2b", 32, 32, 1, 0), ("conv2c", 32, 32, 1, 3),
        ("conv3a", 32, 64, 1, 0), ("conv3b", 64, 64, 1, 4),
        ("conv4a", 64, 80, 0, 0), ("conv4b", 80, 80, 0, 0)]


def selu(x):
    return 1.0507009873554805 * np.where(x > 0, x, 1.6732632423543772 * np.expm1(np.minimum(x, 0)))


def ref_extract(fold, x, dt=np.float32):
    """Referensi lurus: conv -> InstanceNorm -> SELU -> MaxPool (urutan PyTorch asli)."""
    T = x.shape[0]
    a = x.astype(dt)[:, :, None]  # [T, W, C]
    for name, cin, cout, pad, pool in SPEC:
        W = F[f"f{fold}.{name}.weight"].astype(dt)  # [cout][cin][3][3]
        bias = F[f"f{fold}.{name}.bias"].astype(dt)
        Wd = a.shape[1]
        wo = Wd + 2 * pad - 2
        ap = np.pad(a, ((1, 1), (pad, pad), (0, 0)))
        out = np.zeros((T, wo, cout), dt)
        for kh in range(3):
            for kw in range(3):
                patch = ap[kh:kh + T, kw:kw + wo, :]  # [T, wo, cin]
                out += (patch.reshape(-1, cin) @ W[:, :, kh, kw].T).reshape(T, wo, cout)
        out += bias
        m = out.mean(axis=(0, 1), keepdims=True)
        v = out.var(axis=(0, 1), keepdims=True)  # biased
        out = (out - m) / np.sqrt(v + 1e-5)
        out = selu(out).astype(dt)
        if pool:
            wp = wo // pool
            out = out[:, :wp * pool, :].reshape(T, wp, pool, cout).max(axis=2)
        a = out
    assert a.shape[1] == 3, a.shape
    # [T,3,80] -> index c*3 + w
    return a.transpose(0, 2, 1).reshape(T, 240)


def pack_weights(fold):
    ws, bs = [], []
    for name, cin, cout, pad, pool in SPEC:
        raw = F[f"f{fold}.{name}.weight"]  # [cout][cin][3][3]
        w = np.ascontiguousarray(raw.transpose(2, 3, 1, 0)).astype(np.float32)  # [kh][kw][cin][cout]
        ws.append(w.ravel().copy())
        bs.append(F[f"f{fold}.{name}.bias"].astype(np.float32).copy())
    return ws, bs


lib = ctypes.CDLL(SO)
PROG = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_float)
lib.cf_cnn_extract.restype = ctypes.c_int
lib.cf_cnn_extract.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_void_p),
                              ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p, ctypes.c_int, PROG, ctypes.c_void_p]


def native_extract(fold, x, threads, cancel_at=None):
    ws, bs = pack_weights(fold)
    wp = (ctypes.c_void_p * 10)(*[w.ctypes.data for w in ws])
    bp = (ctypes.c_void_p * 10)(*[b.ctypes.data for b in bs])
    out = np.zeros((x.shape[0], 240), np.float32)
    xs = np.ascontiguousarray(x, np.float32)
    seen = []

    @PROG
    def cb(user, p):
        seen.append(p)
        return 0 if (cancel_at is not None and len(seen) >= cancel_at) else 1

    t0 = time.perf_counter()
    rc = lib.cf_cnn_extract(xs.ctypes.data, x.shape[0], wp, bp, out.ctypes.data, threads, cb, None)
    return rc, out, time.perf_counter() - t0, seen


# masukan uji: CQT sintetis dari tes sebelumnya bila ada, jika tidak derau berekor panjang
rng = np.random.default_rng(3)
try:
    cq = np.load(sys.argv[5])[:, 18:270]
    reps = int(np.ceil(FRAMES / len(cq)))
    x = np.tile(cq, (reps, 1))[:FRAMES].astype(np.float32)
    print("masukan: CQT sintetis", x.shape)
except Exception:
    x = (np.abs(rng.normal(size=(FRAMES, 252))) ** 2).astype(np.float32)
    print("masukan: derau", x.shape)

import os
ok = True
for fold in folds:
    ref = ref_extract(fold, x)
    ref64 = ref_extract(fold, x, np.float64)
    rc, got, dt, seen = native_extract(fold, x, THREADS)
    if os.environ.get("DUMP_DIR") and fold == folds[0]:
        d = os.environ["DUMP_DIR"]
        x.astype('<f4').tofile(f"{d}/x.bin"); ref64.astype('<f4').tofile(f"{d}/ref64.bin")
        print("   dump ke", d, x.shape, ref64.shape)
    e_np32 = np.linalg.norm(ref - ref64) / np.linalg.norm(ref64)
    e_cpp = np.linalg.norm(got - ref64) / np.linalg.norm(ref64)
    print(f"   vs float64: numpy-float32 rel={e_np32:.3e} | C++ rel={e_cpp:.3e}")
    rel = np.linalg.norm(got - ref) / np.linalg.norm(ref)
    mx = np.abs(got - ref).max()
    print(f"fold {fold}: rc={rc} rel L2={rel:.3e} max|d|={mx:.3e} (skala ref max={np.abs(ref).max():.2f}) progres={len(seen)} langkah, {dt:.2f}s")
    ok &= rc == 0 and e_cpp < max(3e-3, 3 * e_np32)

# pembatalan
rc, _, _, seen = native_extract(folds[0], x, THREADS, cancel_at=3)
print(f"pembatalan: rc={rc} (harus 1), langkah sebelum berhenti={len(seen)} (harus 3)")
ok &= rc == 1 and len(seen) == 3

# argumen salah
print("argumen salah ->", lib.cf_cnn_extract(None, 0, None, None, None, 1, PROG(0), None), "(harus 3)")
print("\nHASIL:", "LULUS" if ok else "GAGAL")
sys.exit(0 if ok else 1)
