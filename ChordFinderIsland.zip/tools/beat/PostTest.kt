package com.chordfinder.island.engine
import kotlin.math.abs
import kotlin.random.Random

/** model palsu: logit per frame ditentukan oleh nomor frame mutlak yang ditanam di kanal mel 0 (nilai = frame+1; 0 = padding). */
internal fun fakeModel(c: BeatPost.Chunk, truth: (Int) -> Float): FloatArray =
    FloatArray(c.rows) { r -> val v = c.data[r * 128]; if (v == 0f) -5f else truth(v.toInt() - 1) }

fun check(name: String, ok: Boolean) { println((if (ok) "PASS " else "FAIL ") + name); if (!ok) System.exit(1) }

fun main() {
    val rnd = Random(3)
    for (len in intArrayOf(1, 5, 100, 1488, 1489, 1500, 1501, 2976, 2977, 3000, 9000, 18123)) {
        // kebenaran dasar: beat tiap 26 frame (dengan jitter +-1 pada beberapa), logit +4 di puncak, -4 selain itu
        val peak = BooleanArray(len)
        var f = 10
        while (f < len) { peak[f] = true; f += 26 }
        val truth = { i: Int -> if (peak[i]) 4f else -4f }
        val spect = FloatArray(len * 128)
        for (i in 0 until len) spect[i * 128] = (i + 1).toFloat()
        val starts = BeatPost.starts(len)
        val agg = BeatPost.Aggregator(len)
        for (s in starts) {
            val c = BeatPost.chunk(spect, len, s)
            check("len=$len chunk rows<=1500 (start=$s rows=${c.rows})", c.rows <= 1500)
            agg.add(s, fakeModel(c, truth))
        }
        var bad = 0
        for (i in 0 until len) if (agg.logits[i] != truth(i)) bad++
        check("len=$len agregasi sama dengan kebenaran dasar (salah=$bad, chunk=${starts.size})", bad == 0)
    }
    // peak-picking + BPM: 115,385 BPM = 26 frame; jitter acak +-1 frame pada logit
    val len = 18000
    val lg = FloatArray(len) { -4f }
    var t = 12.0; val iv = 26.0
    while (t < len - 5) { val j = (t + rnd.nextInt(-1, 2)).toInt(); lg[j] = 3f; if (rnd.nextInt(5) == 0 && j + 1 < len) lg[j + 1] = 2f; t += iv }
    val beats = BeatPost.pickBeats(lg)
    val tp = BeatPost.tempo(beats)!!
    println("beat=${beats.size} bpm=${"%.3f".format(tp.bpm)} steady=${tp.steady} (benar 115.385)")
    check("BPM sintetis dalam 0,15 BPM", abs(tp.bpm - 115.3846) < 0.15)
    // beat terlewat 1 dari tiap 10: BPM tetap sama
    val kept = beats.filterIndexed { i, _ -> i % 10 != 4 }.toFloatArray()
    val tp2 = BeatPost.tempo(kept)!!
    println("dengan beat hilang: bpm=${"%.3f".format(tp2.bpm)} steady=${tp2.steady}")
    check("BPM dengan beat hilang dalam 0,3 BPM", abs(tp2.bpm - 115.3846) < 0.3)
    check("beat < 4 -> null", BeatPost.tempo(floatArrayOf(0.5f, 1f, 1.5f)) == null)
    check("tanpa puncak -> kosong", BeatPost.pickBeats(FloatArray(500) { -3f }).isEmpty())
}
